SET NOCOUNT ON;
SET XACT_ABORT ON;

IF OBJECT_ID(N'dbo.di_flpFileConfiguration', N'U') IS NULL
    THROW 52240, 'Required table dbo.di_flpFileConfiguration was not found.', 1;

IF COL_LENGTH(N'dbo.di_flpFileConfiguration', N'structuredParentSelection') IS NULL
    THROW 52241, 'Required column dbo.di_flpFileConfiguration.structuredParentSelection was not found.', 1;

BEGIN TRANSACTION;

ALTER TABLE dbo.di_flpFileConfiguration
    ALTER COLUMN structuredParentSelection NVARCHAR(MAX) NULL;

IF OBJECT_ID(N'dbo.di_flpFileConfigurationHistory', N'U') IS NOT NULL
   AND COL_LENGTH(N'dbo.di_flpFileConfigurationHistory', N'structuredParentSelection') IS NOT NULL
BEGIN
    ALTER TABLE dbo.di_flpFileConfigurationHistory
        ALTER COLUMN structuredParentSelection NVARCHAR(MAX) NULL;
END;

COMMIT TRANSACTION;
GO

CREATE OR ALTER PROCEDURE dbo.commit_structuredParentSelection
    @flpConfigurationId NVARCHAR(100),
    @tabName VARCHAR(100),
    @structuredParentSelection NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    IF @tabName IS NULL
       OR NOT (@tabName LIKE 'json:$%' OR @tabName LIKE 'xml:/%')
        THROW 52210, 'A valid JSON/XML table is required for ancestor context columns.', 1;

    IF @structuredParentSelection IS NOT NULL
    BEGIN
        IF LEN(@structuredParentSelection) = 0
           OR LEN(@structuredParentSelection) > 16000
           OR ISJSON(@structuredParentSelection) <> 1
            THROW 52211, 'Structured ancestor selections must be valid JSON and cannot exceed 16000 characters.', 1;

        DECLARE @Selections NVARCHAR(MAX) = CASE
            WHEN LEFT(LTRIM(@structuredParentSelection), 1) = '[' THEN @structuredParentSelection
            ELSE N'[' + @structuredParentSelection + N']'
        END;

        DECLARE @SelectionCount INT = (SELECT COUNT(*) FROM OPENJSON(@Selections));
        IF @SelectionCount > 64
            THROW 52216, 'A maximum of 64 ancestor context columns can be selected.', 1;

        IF EXISTS (
            SELECT 1
            FROM OPENJSON(@Selections)
            WITH (
                ParentPath NVARCHAR(100) '$.parentPath',
                SourceField NVARCHAR(255) '$.sourceField',
                OutputColumn NVARCHAR(255) '$.outputColumn'
            ) selection
            WHERE NULLIF(LTRIM(RTRIM(selection.ParentPath)), N'') IS NULL
               OR NULLIF(LTRIM(RTRIM(selection.SourceField)), N'') IS NULL
               OR NULLIF(LTRIM(RTRIM(selection.OutputColumn)), N'') IS NULL
        )
            THROW 52212, 'A structured ancestor selection is incomplete.', 1;

        IF EXISTS (
            SELECT 1
            FROM OPENJSON(@Selections)
            WITH (ParentPath NVARCHAR(100) '$.parentPath') selection
            WHERE (@tabName LIKE 'json:%' AND selection.ParentPath NOT LIKE 'json:$%')
               OR (@tabName LIKE 'xml:%' AND selection.ParentPath NOT LIKE 'xml:/%')
               OR LEFT(@tabName, LEN(selection.ParentPath)) <> selection.ParentPath
               OR @tabName = selection.ParentPath
        )
            THROW 52213, 'An ancestor field does not belong to the selected JSON/XML table.', 1;

        IF EXISTS (
            SELECT 1
            FROM OPENJSON(@Selections)
            WITH (OutputColumn NVARCHAR(255) '$.outputColumn') selection
            GROUP BY LOWER(OutputColumn)
            HAVING COUNT(*) > 1
        )
            THROW 52215, 'Each structured context column must have a unique output column name.', 1;
    END;

    UPDATE dbo.di_flpFileConfiguration
    SET structuredParentSelection = @structuredParentSelection
    WHERE flpConfigurationId = @flpConfigurationId
      AND active = 1
      AND tabName = @tabName;

    IF @@ROWCOUNT <> 1
        THROW 52214, 'The ancestor selections could not be assigned to exactly one active file configuration.', 1;
END;
GO

SELECT N'DEPLOYMENT_OK' AS deployment_status;
