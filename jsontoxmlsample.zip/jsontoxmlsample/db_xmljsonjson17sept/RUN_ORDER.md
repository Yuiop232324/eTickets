# JSON/XML ancestor context database deployment

Run these files against the intended Data Ingestion database in this order:

1. `00_pre_deployment_checks.sql`
2. `01_deploy_structured_ancestor_context.sql`
3. `02_post_deployment_verification.sql`

Expected final statuses are `PRECHECK_OK`, `DEPLOYMENT_OK`, `LEGACY_OK`, `ARRAY_OK`, `LIMIT_OK`, and `VERIFICATION_OK`.

The verification script inserts a temporary configuration inside a transaction and always rolls it back. It does not retain test data.

This deployment stores only JSON/XML table paths and selected ancestor-column instructions. It does not store uploaded JSON/XML document content.

The scripts are idempotent for UAT and production deployment. Take the normal environment backup before running any production schema change.
