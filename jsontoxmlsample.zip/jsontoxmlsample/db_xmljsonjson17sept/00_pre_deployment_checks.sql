SET NOCOUNT ON;
SET XACT_ABORT ON;

IF OBJECT_ID(N'dbo.di_flpFileConfiguration', N'U') IS NULL
    THROW 52240, 'Required table dbo.di_flpFileConfiguration was not found.', 1;

IF COL_LENGTH(N'dbo.di_flpFileConfiguration', N'structuredParentSelection') IS NULL
    THROW 52241, 'Required column dbo.di_flpFileConfiguration.structuredParentSelection was not found.', 1;

IF EXISTS (
    SELECT 1
    FROM dbo.di_flpFileConfiguration
    WHERE structuredParentSelection IS NOT NULL
      AND ISJSON(structuredParentSelection) <> 1
)
    THROW 52242, 'Existing structuredParentSelection data contains invalid JSON. Deployment stopped.', 1;

IF EXISTS (
    SELECT 1
    FROM dbo.di_flpFileConfiguration
    WHERE tabName LIKE 'json:%' OR tabName LIKE 'xml:%'
    GROUP BY flpConfigurationId, tabName
    HAVING SUM(CASE WHEN active = 1 THEN 1 ELSE 0 END) > 1
)
    THROW 52243, 'More than one active JSON/XML file configuration exists for the same process and table.', 1;

SELECT
    DB_NAME() AS database_name,
    @@SERVERNAME AS server_name,
    TYPE_NAME(column_definition.user_type_id) AS current_data_type,
    column_definition.max_length AS current_max_length,
    SUM(CASE WHEN file_configuration.structuredParentSelection IS NOT NULL THEN 1 ELSE 0 END) AS saved_structured_configurations
FROM sys.columns column_definition
JOIN sys.tables table_definition
  ON table_definition.object_id = column_definition.object_id
LEFT JOIN dbo.di_flpFileConfiguration file_configuration
  ON 1 = 1
WHERE table_definition.name = N'di_flpFileConfiguration'
  AND SCHEMA_NAME(table_definition.schema_id) = N'dbo'
  AND column_definition.name = N'structuredParentSelection'
GROUP BY column_definition.user_type_id, column_definition.max_length;

SELECT N'PRECHECK_OK' AS deployment_status;
