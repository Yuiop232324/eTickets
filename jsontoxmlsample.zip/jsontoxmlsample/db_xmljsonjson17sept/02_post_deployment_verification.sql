SET NOCOUNT ON;
SET XACT_ABORT ON;

IF COL_LENGTH(N'dbo.di_flpFileConfiguration', N'structuredParentSelection') IS NULL
    THROW 52250, 'Current configuration column is missing.', 1;

IF EXISTS (
    SELECT 1
    FROM sys.columns column_definition
    JOIN sys.tables table_definition
      ON table_definition.object_id = column_definition.object_id
    WHERE table_definition.name = N'di_flpFileConfiguration'
      AND SCHEMA_NAME(table_definition.schema_id) = N'dbo'
      AND column_definition.name = N'structuredParentSelection'
      AND (TYPE_NAME(column_definition.user_type_id) <> N'nvarchar' OR column_definition.max_length <> -1)
)
    THROW 52251, 'Current configuration column is not NVARCHAR(MAX).', 1;

IF OBJECT_ID(N'dbo.di_flpFileConfigurationHistory', N'U') IS NOT NULL
   AND COL_LENGTH(N'dbo.di_flpFileConfigurationHistory', N'structuredParentSelection') IS NOT NULL
   AND EXISTS (
       SELECT 1
       FROM sys.columns column_definition
       JOIN sys.tables table_definition
         ON table_definition.object_id = column_definition.object_id
       WHERE table_definition.name = N'di_flpFileConfigurationHistory'
         AND SCHEMA_NAME(table_definition.schema_id) = N'dbo'
         AND column_definition.name = N'structuredParentSelection'
         AND (TYPE_NAME(column_definition.user_type_id) <> N'nvarchar' OR column_definition.max_length <> -1)
   )
    THROW 52252, 'Configuration history column is not NVARCHAR(MAX).', 1;

IF OBJECT_ID(N'dbo.commit_structuredParentSelection', N'P') IS NULL
    THROW 52253, 'Procedure dbo.commit_structuredParentSelection is missing.', 1;

IF OBJECT_DEFINITION(OBJECT_ID(N'dbo.commit_structuredParentSelection')) NOT LIKE N'%OPENJSON(@Selections)%'
    THROW 52254, 'Procedure is not the multi-ancestor version.', 1;

BEGIN TRANSACTION;

DECLARE @TestId NVARCHAR(100) = N'xml-json-17sept-verification';
DELETE FROM dbo.di_flpFileConfiguration WHERE flpConfigurationId = @TestId;

INSERT dbo.di_flpFileConfiguration(flpConfigurationId, tabName, active)
VALUES (@TestId, 'json:$.result.companies[].departments[].employees', 1);

EXEC dbo.commit_structuredParentSelection
    @TestId,
    'json:$.result.companies[].departments[].employees',
    N'{"parentPath":"json:$.result.companies[].departments","sourceField":"departmentCode","outputColumn":"department_code"}';

IF NOT EXISTS (
    SELECT 1
    FROM dbo.di_flpFileConfiguration
    WHERE flpConfigurationId = @TestId
      AND JSON_VALUE(structuredParentSelection, '$.outputColumn') = N'department_code'
)
    THROW 52255, 'Legacy single-selection persistence failed.', 1;

EXEC dbo.commit_structuredParentSelection
    @TestId,
    'json:$.result.companies[].departments[].employees',
    N'[{"parentPath":"json:$.result.companies[].departments","sourceField":"departmentCode","outputColumn":"department_code"},{"parentPath":"json:$.result.companies","sourceField":"companyCode","outputColumn":"company_code"}]';

IF NOT EXISTS (
    SELECT 1
    FROM dbo.di_flpFileConfiguration
    WHERE flpConfigurationId = @TestId
      AND (SELECT COUNT(*) FROM OPENJSON(structuredParentSelection)) = 2
)
    THROW 52256, 'Multiple ancestor-selection persistence failed.', 1;

DECLARE @TooManySelections NVARCHAR(MAX);
WITH selection_numbers AS (
    SELECT TOP (65) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS selection_number
    FROM sys.all_objects
)
SELECT @TooManySelections = (
    SELECT
        N'json:$.result.companies' AS parentPath,
        N'field_' + CONVERT(NVARCHAR(10), selection_number) AS sourceField,
        N'context_' + CONVERT(NVARCHAR(10), selection_number) AS outputColumn
    FROM selection_numbers
    FOR JSON PATH
);

BEGIN TRY
    EXEC dbo.commit_structuredParentSelection
        @TestId,
        'json:$.result.companies[].departments[].employees',
        @TooManySelections;
    THROW 52257, 'The 64-context-column database limit was not enforced.', 1;
END TRY
BEGIN CATCH
    IF ERROR_NUMBER() <> 52216
        THROW;
END CATCH;

ROLLBACK TRANSACTION;

SELECT
    DB_NAME() AS database_name,
    @@SERVERNAME AS server_name,
    N'LEGACY_OK' AS legacy_result,
    N'ARRAY_OK' AS multi_ancestor_result,
    N'LIMIT_OK' AS context_limit_result,
    N'VERIFICATION_OK' AS deployment_status;
