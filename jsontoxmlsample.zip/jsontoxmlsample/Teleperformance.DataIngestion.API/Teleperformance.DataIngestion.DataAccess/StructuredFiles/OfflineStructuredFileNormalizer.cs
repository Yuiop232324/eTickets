using SMBLibrary;
using Teleperformance.DataIngestion.Common.StructuredFiles;
using Teleperformance.DataIngestion.DataAccess.Interfaces.v1._0;
using Teleperformance.DataIngestion.Models.DTOs.v1._0.FileLoadingConfigurationProcess;
using Teleperformance.DataIngestion.Models.Entities.v1._0.FileLoadingConfigurationProcess;
using Teleperformance.DataIngestion.Models.Models.v1._0;

namespace Teleperformance.DataIngestion.DataAccess.StructuredFiles;

public static class OfflineStructuredFileNormalizer
{
    public static async Task NormalizeAsync(FlpProcessTempFile temp, string originalName, string? section, IBlobStorageService blobs, ISMBLibraryServices smb, SharedLocationDestinationServerDto server, string configurationId, string? structuredParentSelection = null)
    {
        StructuredNodeReader.ValidateFormat(originalName, section);
        if (!StructuredFileReader.Supports(originalName)) return;
        var ancestorSelections = StructuredParentFieldSelectionCodec.ParseManyForSection(section, structuredParentSelection);
        if (!string.IsNullOrWhiteSpace(temp.sourceTempFilePath))
        {
            var originalPath = temp.sourceTempFilePath;
            if (!string.IsNullOrWhiteSpace(server?.ServerName))
            {
                await NormalizeSmbAsync(temp, originalName, section, ancestorSelections, smb, server, configurationId);
                return;
            }
            await using var source = File.OpenRead(originalPath);
            var bytes = await StructuredFileReader.NormalizeWithAncestorsAsync(source, originalName, section, source.Length, ancestorSelections);
            var outputPath = Path.ChangeExtension(originalPath, ".csv");
            await File.WriteAllBytesAsync(outputPath, bytes);
            await source.DisposeAsync();
            File.Delete(originalPath);
            temp.sourceTempFilePath = outputPath;
            temp.FileSize = bytes.LongLength / (1024d * 1024d);
            return;
        }
        var blob = blobs.GetBlobClientDetails(temp.Name, temp.ParquetBlobConnectionString, temp.BlobContainerName);
        await using var input = await blob.OpenReadAsync();
        var content = await StructuredFileReader.NormalizeWithAncestorsAsync(input, originalName, section, input.CanSeek ? input.Length : null, ancestorSelections);
        var destination = blobs.GetBlobClientDetails(Path.ChangeExtension(temp.Name, ".csv"), temp.ParquetBlobConnectionString, temp.BlobContainerName);
        await using var output = new MemoryStream(content, writable: false);
        await destination.UploadAsync(output, overwrite: true);
        await input.DisposeAsync();
        await blob.DeleteIfExistsAsync();
        temp.Name = destination.Name;
        temp.Uri = destination.Uri.ToString();
        temp.CanGenerateSasUri = destination.CanGenerateSasUri;
        temp.FileSize = content.LongLength / (1024d * 1024d);
    }

    private static async Task NormalizeSmbAsync(FlpProcessTempFile temp, string fileName, string? section,
        IReadOnlyList<StructuredParentFieldSelection> ancestorSelections,
        ISMBLibraryServices smb, SharedLocationDestinationServerDto server, string configurationId)
    {
        var model = new CheckConnectivitySMBLibraryModel
        {
            serverIP = server.ServerName,
            sharedFolderName = server.FolderName,
            username = server.UserName,
            password = server.Password,
            domain = server.Domain
        };
        var (client, store) = smb.SMBRequest(model, configurationId);
        try
        {
            if (store is null) throw new IOException("Cannot open the JSON/XML temporary share.");
            using var source = smb.GetFileStream(store, temp.sourceTempFilePath, configurationId);
            var bytes = await StructuredFileReader.NormalizeWithAncestorsAsync(source, fileName, section, source.CanSeek ? source.Length : null, ancestorSelections);
            var outputPath = Path.ChangeExtension(temp.sourceTempFilePath, ".csv");
            var status = store.CreateFile(out var handle, out _, outputPath, AccessMask.GENERIC_WRITE,
                SMBLibrary.FileAttributes.Normal, ShareAccess.None, CreateDisposition.FILE_OVERWRITE_IF,
                CreateOptions.FILE_NON_DIRECTORY_FILE, null);
            if (status != NTStatus.STATUS_SUCCESS) throw new IOException($"Cannot create normalized temporary file: {status}.");
            try
            {
                var offset = 0;
                while (offset < bytes.Length)
                {
                    var count = Math.Min(4096, bytes.Length - offset);
                    var chunk = bytes.AsSpan(offset, count).ToArray();
                    status = store.WriteFile(out var written, handle, offset, chunk);
                    if (status != NTStatus.STATUS_SUCCESS || written <= 0 || written > count)
                        throw new IOException($"Cannot write normalized temporary file: {status}.");
                    offset += written;
                }
            }
            finally { store.CloseFile(handle); }
            // Keep the original temporary copy until the existing cleanup policy removes it.
            temp.sourceTempFilePath = outputPath;
            temp.FileSize = bytes.LongLength / (1024d * 1024d);
        }
        finally
        {
            store?.Disconnect();
            client?.Logoff();
            client?.Disconnect();
        }
    }
}
