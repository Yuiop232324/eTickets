using System.Text;
using Teleperformance.DataIngestion.Common.StructuredFiles;
using Xunit;

namespace Teleperformance.DataIngestion.Common.StructuredFiles.Tests;

public sealed class StructuredFileReaderTests
{
    [Fact]
    public async Task XmlRepeatedValuesArePreservedInIndexedFields()
    {
        const string xml = """
            <Customers>
              <Customer><Id>1</Id><Skills><Skill>A</Skill><Skill>B</Skill></Skills><Orders><Order><Id>O1</Id></Order><Order><Id>O2</Id></Order></Orders></Customer>
              <Customer><Id>2</Id><Skills><Skill>C</Skill></Skills><Orders><Order><Id>O3</Id></Order></Orders></Customer>
              <Customer><Id>3</Id><Skills /><Orders /></Customer>
            </Customers>
            """;

        var preview = await Preview(xml, "customers.xml", "/Customers/Customer");

        Assert.Equal(3, preview.TotalRecords);
        Assert.Equal("A", preview.Rows[0]["Skills.Skill1"]);
        Assert.Equal("B", preview.Rows[0]["Skills.Skill2"]);
        Assert.Equal("O1", preview.Rows[0]["Orders.Order1.Id"]);
        Assert.Equal("O2", preview.Rows[0]["Orders.Order2.Id"]);
        Assert.Equal("O3", preview.Rows[1]["Orders.Order1.Id"]);
        Assert.DoesNotContain(preview.Fields, field => field.Name is "Orders.Order.Id" or "Orders");
        Assert.Contains(preview.Warnings, warning => warning.StartsWith("Some records do not contain", StringComparison.Ordinal));
    }

    [Fact]
    public async Task JsonNestedCollectionsArePreservedAndTopLevelRecordsAreSelected()
    {
        const string json = """
            {"customers":[
              {"id":1,"skills":["A","B"],"orders":[{"id":"O1"},{"id":"O2"}]},
              {"id":2,"skills":["C"],"orders":[]}
            ]}
            """;

        var preview = await Preview(json, "customers.json");

        Assert.Equal("$.customers", preview.SelectedSection);
        Assert.Equal("A", preview.Rows[0]["skills1"]);
        Assert.Equal("B", preview.Rows[0]["skills2"]);
        Assert.Equal("O1", preview.Rows[0]["orders1.id"]);
        Assert.Equal("O2", preview.Rows[0]["orders2.id"]);
    }

    [Theory]
    [InlineData("{\"id\":1,\"ID\":2}", "duplicate field")]
    [InlineData("[{\"id\":1},2]", "cannot mix")]
    [InlineData("42", "root must be")]
    public async Task InvalidJsonRecordShapesAreRejected(string json, string expected)
    {
        var error = await Assert.ThrowsAsync<InvalidDataException>(() => Preview(json, "invalid.json"));
        Assert.Contains(expected, error.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task UnknownSelectedSectionIsRejectedInsteadOfSilentlyChangingData()
    {
        var error = await Assert.ThrowsAsync<InvalidDataException>(() =>
            Preview("{\"customers\":[{\"id\":1}]}", "customers.json", "$.missing"));

        Assert.Contains("was not found", error.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task XmlMixedContentIsRejectedInsteadOfLosingText()
    {
        var error = await Assert.ThrowsAsync<InvalidDataException>(() =>
            Preview("<root><record>before<id>1</id>after</record></root>", "invalid.xml"));

        Assert.Contains("mixes text", error.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task XmlExternalEntitiesRemainProhibited()
    {
        const string xml = "<!DOCTYPE root [<!ENTITY value SYSTEM 'file:///missing'>]><root><record><id>&value;</id></record></root>";
        await Assert.ThrowsAnyAsync<Exception>(() => Preview(xml, "invalid.xml"));
    }

    [Fact]
    public async Task NormalizationProducesACompleteCsvHeader()
    {
        const string xml = "<Customers><Customer><Id>1</Id><Tags><Tag>A</Tag><Tag>B</Tag></Tags></Customer></Customers>";
        await using var stream = Content(xml);

        var bytes = await StructuredFileReader.NormalizeAsync(stream, "customers.xml", "/Customers/Customer", stream.Length);
        var csv = Encoding.UTF8.GetString(bytes);

        Assert.StartsWith("Id,Tags.Tag1,Tags.Tag2", csv, StringComparison.Ordinal);
    }

    [Fact]
    public async Task NonStructuredFilesRemainUntouched()
    {
        await using var stream = Content("id,name\r\n1,A");

        var prepared = await StructuredFileReader.PrepareForIngestionAsync(stream, "existing.csv", null, stream.Length);

        Assert.Same(stream, prepared.Content);
        Assert.Equal("existing.csv", prepared.FileName);
    }

    private static async Task<StructuredFilePreview> Preview(string content, string name, string? section = null)
    {
        await using var stream = Content(content);
        return await StructuredFileReader.PreviewAsync(stream, name, section, 100, stream.Length);
    }

    private static MemoryStream Content(string value) => new(Encoding.UTF8.GetBytes(value), writable: false);
}
