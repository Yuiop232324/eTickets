using System.Text;
using Teleperformance.DataIngestion.Common.StructuredFiles;
using Xunit;

public class StructuredNodeReaderTests
{
    private const string Json = """{"responseCode":200,"result":{"data":[{"id":1,"filterData":{"name":"A"}},{"id":2,"filterData":{"name":"B"}}]}}""";
    private static async Task<StructuredFilePreview> Read(string content, string path, string name = "sample.json", int limit = 50)
    {
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(content));
        return await StructuredFileReader.PreviewAsync(stream, name, path, limit, stream.Length);
    }

    [Fact]
    public async Task RootAndParentObjectsAreSelectableAndKeepChildrenAsText()
    {
        var root = await Read(Json, "json:$");
        Assert.Equal(new[] { "responseCode", "result" }, root.Fields.Select(f => f.Name));
        Assert.IsType<string>(root.Rows[0]["result"]);
        var parent = await Read(Json, "json:$.result");
        Assert.Equal("data", Assert.Single(parent.Fields).Name);
        Assert.IsType<string>(parent.Rows[0]["data"]);
    }

    [Fact]
    public async Task ChildSelectionChangesRowsAndColumns()
    {
        var records = await Read(Json, "json:$.result.data");
        Assert.Equal(2, records.TotalRecords);
        Assert.Equal(new[] { "id", "filterData" }, records.Fields.Select(f => f.Name));
        var children = await Read(Json, "json:$.result.data[].filterData");
        Assert.Equal("name", Assert.Single(children.Fields).Name);
        Assert.Equal(new object?[] { "A", "B" }, children.Rows.Select(r => r["name"]));
    }

    [Fact]
    public async Task JsonChildRowsCanIncludeOneCorrelatedImmediateParentField()
    {
        const string content = """{"groups":[{"id":"G1","items":[{"name":"A"},{"name":"B"}]},{"id":"G2","items":[{"name":"C"}]}]}""";
        var selection = new StructuredParentFieldSelection("json:$.groups", "id", "parent_id");
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(content));
        var preview = await StructuredFileReader.PreviewAsync(stream, "sample.json", "json:$.groups[].items", 50,
            stream.Length, selection);
        Assert.Equal(new object?[] { "G1", "G1", "G2" }, preview.Rows.Select(row => row["parent_id"]));
        Assert.Equal(selection, preview.ParentNode?.Selection);
        Assert.Contains(preview.ParentNode!.Fields, field => field.SourceField == "id" && field.OutputColumn == "parent_id");
    }

    [Fact]
    public async Task XmlChildRowsCanIncludeOneCorrelatedImmediateParentField()
    {
        const string content = "<root><group id='G1'><item name='A'/><item name='B'/></group><group id='G2'><item name='C'/></group></root>";
        var selection = new StructuredParentFieldSelection("xml:/root/group", "@id", "parent_id");
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(content));
        var preview = await StructuredFileReader.PreviewAsync(stream, "sample.xml", "xml:/root/group/item", 50,
            stream.Length, selection);
        Assert.Equal(new object?[] { "G1", "G1", "G2" }, preview.Rows.Select(row => row["parent_id"]));
        Assert.Equal(selection, preview.ParentNode?.Selection);
    }

    [Fact]
    public async Task XmlEmployeeRowsRetainAllRecordsWhenDepartmentNameIsIncluded()
    {
        const string xml = """
            <company>
              <department name="Engineering">
                <employee id="E101"><firstName>Jane</firstName><lastName>Doe</lastName><role>Senior Developer</role></employee>
                <employee id="E102"><firstName>John</firstName><lastName>Smith</lastName><role>Systems Architect</role></employee>
              </department>
              <department name="Design">
                <employee id="D201"><firstName>Alice</firstName><lastName>Jones</lastName><role>UX Researcher</role></employee>
              </department>
            </company>
            """;
        var selection = new StructuredParentFieldSelection("xml:/company/department", "@name", "parent_name");
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(xml));

        var preview = await StructuredFileReader.PreviewAsync(stream, "company_directory.xml",
            "xml:/company/department/employee", 50, stream.Length, selection);

        Assert.Equal(3, preview.TotalRecords);
        Assert.Equal(new object?[] { "Engineering", "Engineering", "Design" },
            preview.Rows.Select(row => row["parent_name"]));
        Assert.All(preview.Rows, row => Assert.True(row.ContainsKey("firstName")));
        Assert.Contains(preview.ParentNode!.Fields,
            field => field.SourceField == "@name" && field.OutputColumn == "parent_name");

        using var normalizationStream = new MemoryStream(Encoding.UTF8.GetBytes(xml));
        var csv = Encoding.UTF8.GetString(await StructuredFileReader.NormalizeAsync(normalizationStream,
            "company_directory.xml", "xml:/company/department/employee", normalizationStream.Length, selection));
        Assert.Equal(4, csv.Split('\n', StringSplitOptions.RemoveEmptyEntries).Length);
        Assert.Contains("E101,Jane,Doe,Senior Developer,Engineering", csv, StringComparison.Ordinal);
        Assert.Contains("E102,John,Smith,Systems Architect,Engineering", csv, StringComparison.Ordinal);
        Assert.Contains("D201,Alice,Jones,UX Researcher,Design", csv, StringComparison.Ordinal);
    }

    [Fact]
    public async Task EmployeeTableCanIncludeDepartmentAndCompanyContextColumns()
    {
        const string content = """
            {"result":{"companies":[
              {"companyCode":"C1","departments":[
                {"departmentCode":"D1","employees":[{"employeeId":"E1"},{"employeeId":"E2"}]},
                {"departmentCode":"D2","employees":[{"employeeId":"E3"}]}
              ]},
              {"companyCode":"C2","departments":[
                {"departmentCode":"D3","employees":[{"employeeId":"E4"}]}
              ]}
            ]}}
            """;
        var selections = new[]
        {
            new StructuredParentFieldSelection("json:$.result.companies[].departments", "departmentCode", "department_code"),
            new StructuredParentFieldSelection("json:$.result.companies", "companyCode", "company_code")
        };
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(content));

        var preview = await StructuredFileReader.PreviewWithAncestorsAsync(stream, "companies.json",
            "json:$.result.companies[].departments[].employees", 50, stream.Length, selections);

        Assert.Equal(new object?[] { "D1", "D1", "D2", "D3" }, preview.Rows.Select(row => row["department_code"]));
        Assert.Equal(new object?[] { "C1", "C1", "C1", "C2" }, preview.Rows.Select(row => row["company_code"]));
        Assert.Contains(preview.AncestorNodes!, node => node.Path == "json:$.result.companies");
        Assert.Contains(preview.AncestorNodes!, node => node.Path == "json:$.result.companies[].departments");
    }

    [Fact]
    public async Task XmlEmployeeTableCanIncludeDepartmentAndCompanyContextColumns()
    {
        const string content = """
            <result>
              <company code="C1">
                <department code="D1">
                  <employee id="E1" />
                  <employee id="E2" />
                </department>
                <department code="D2"><employee id="E3" /></department>
              </company>
              <company code="C2">
                <department code="D3"><employee id="E4" /></department>
              </company>
            </result>
            """;
        var selections = new[]
        {
            new StructuredParentFieldSelection("xml:/result/company/department", "@code", "department_code"),
            new StructuredParentFieldSelection("xml:/result/company", "@code", "company_code")
        };
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(content));

        var preview = await StructuredFileReader.PreviewWithAncestorsAsync(stream, "companies.xml",
            "xml:/result/company/department/employee", 50, stream.Length, selections);

        Assert.Equal(new object?[] { "D1", "D1", "D2", "D3" }, preview.Rows.Select(row => row["department_code"]));
        Assert.Equal(new object?[] { "C1", "C1", "C1", "C2" }, preview.Rows.Select(row => row["company_code"]));
        Assert.Contains(preview.AncestorNodes!, node => node.Path == "xml:/result/company");
        Assert.Contains(preview.AncestorNodes!, node => node.Path == "xml:/result/company/department");
    }

    [Fact]
    public async Task XmlPreviewKeepsContainerOnlyAncestorLevelsForRelationshipDisplay()
    {
        const string content = """
            <globalDirectory><countries><country code="US"><companies>
              <company id="C1"><name>Example</name></company>
            </companies></country></countries></globalDirectory>
            """;
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(content));

        var preview = await StructuredFileReader.PreviewWithAncestorsAsync(stream, "organizations.xml",
            "xml:/globalDirectory/countries/country/companies/company", 50, stream.Length, []);

        var ancestors = Assert.IsAssignableFrom<IReadOnlyList<StructuredAncestorNode>>(preview.AncestorNodes);
        Assert.Equal(new[]
        {
            "xml:/globalDirectory/countries/country/companies",
            "xml:/globalDirectory/countries/country",
            "xml:/globalDirectory/countries",
            "xml:/globalDirectory"
        }, ancestors.Select(node => node.Path));
        Assert.Empty(ancestors[0].Fields);
        Assert.Contains(ancestors[1].Fields, field => field.SourceField == "@code");
        Assert.Empty(ancestors[2].Fields);
        Assert.Empty(ancestors[3].Fields);
        Assert.Equal("xml:/globalDirectory/countries/country", preview.ParentNode!.Path);
    }

    [Fact]
    public void AncestorSelectionCodecAcceptsLegacyObjectAndNewArray()
    {
        var department = new StructuredParentFieldSelection("json:$.companies[].departments", "name", "department_name");
        var company = new StructuredParentFieldSelection("json:$.companies", "name", "company_name");

        Assert.Equal([department], StructuredParentFieldSelectionCodec.ParseMany(
            StructuredParentFieldSelectionCodec.Serialize(department)));
        var serialized = StructuredParentFieldSelectionCodec.SerializeMany([department, company]);
        Assert.Equal([department, company], StructuredParentFieldSelectionCodec.ParseManyForSection(
            "json:$.companies[].departments[].employees", serialized));
    }

    [Fact]
    public void AncestorSelectionCodecAcceptsThe64ColumnLimitAndRejects65()
    {
        var selections = Enumerable.Range(1, 65)
            .Select(index => new StructuredParentFieldSelection(
                "json:$.companies", $"field_{index}", $"context_{index}"))
            .ToList();

        var sixtyFour = StructuredParentFieldSelectionCodec.SerializeMany(selections.Take(64).ToList());
        Assert.Equal(64, StructuredParentFieldSelectionCodec.ParseMany(sixtyFour).Count);

        var sixtyFive = StructuredParentFieldSelectionCodec.SerializeMany(selections);
        var error = Assert.Throws<InvalidDataException>(() =>
            StructuredParentFieldSelectionCodec.ParseMany(sixtyFive));
        Assert.Contains("maximum of 64", error.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public async Task NullParentSelectionPreservesNormalizedOutput()
    {
        using var original = new MemoryStream(Encoding.UTF8.GetBytes(Json));
        using var guarded = new MemoryStream(Encoding.UTF8.GetBytes(Json));
        var existing = await StructuredFileReader.NormalizeAsync(original, "sample.json", "json:$.result.data", original.Length);
        var optOut = await StructuredFileReader.NormalizeAsync(guarded, "sample.json", "json:$.result.data", guarded.Length, null);
        Assert.Equal(existing, optOut);
    }

    [Fact]
    public async Task InvalidParentSelectionFailsBeforeEnrichment()
    {
        var selection = new StructuredParentFieldSelection("json:$", "missing", "parent_missing");
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(Json));
        var error = await Assert.ThrowsAsync<InvalidDataException>(() => StructuredFileReader.PreviewAsync(
            stream, "sample.json", "json:$.result.data[].filterData", 50, stream.Length, selection));
        Assert.Contains("immediate parent", error.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void ParentSelectionCodecRoundTripsAndRejectsMalformedInput()
    {
        var selection = new StructuredParentFieldSelection("json:$.result.data", "id", "parent_id");
        Assert.Equal(selection, StructuredParentFieldSelectionCodec.Parse(StructuredParentFieldSelectionCodec.Serialize(selection)));
        Assert.Throws<InvalidDataException>(() => StructuredParentFieldSelectionCodec.Parse("{not-json}"));
        Assert.Throws<InvalidDataException>(() => StructuredParentFieldSelectionCodec.Parse(
            "{\"parentPath\":\"json:$\",\"sourceField\":\"id\",\"outputColumn\":\"bad column\"}"));
    }

    [Fact]
    public async Task PreviewLimitDoesNotHideLaterFieldsOrTruncateNormalization()
    {
        const string content = """[{"id":1},{"id":2,"later":"yes"}]""";
        var preview = await Read(content, "json:$", limit: 1);
        Assert.Single(preview.Rows);
        Assert.Contains(preview.Fields, f => f.Name == "later");
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(content));
        var csv = Encoding.UTF8.GetString(await StructuredFileReader.NormalizeAsync(stream, "sample.json", "json:$"));
        Assert.Contains("2,yes", csv);
    }

    [Fact]
    public async Task LongNestedValuesArePreserved()
    {
        var value = new string('x', 10000);
        var preview = await Read("{\"child\":{\"text\":\"" + value + "\"}}", "json:$");
        Assert.Contains(value, Assert.IsType<string>(preview.Rows[0]["child"]));
    }

    [Fact]
    public async Task MissingNodeAndWrongFormatFailExplicitly()
    {
        await Assert.ThrowsAsync<InvalidDataException>(() => Read(Json, "json:$.missing"));
        await Assert.ThrowsAsync<InvalidDataException>(() => Read("<root/>", "json:$", "sample.xml"));
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes("id\n1"));
        await Assert.ThrowsAsync<InvalidDataException>(() => StructuredFileReader.PrepareForIngestionAsync(stream, "sample.csv", "json:$"));
    }

    [Fact]
    public async Task PropertyNamesRemainDistinctAndAddressable()
    {
        var root = await Read("""{"a.b":{"id":1},"a":{"b":{"id":2}},"ID":1,"id":2}""", "json:$");
        Assert.Contains(root.Sections, s => s.Path == "json:$[\"a.b\"]");
        Assert.Contains(root.Sections, s => s.Path == "json:$.a.b");
        Assert.Equal(4, root.Fields.Count);
    }

    [Fact]
    public async Task XmlParentAndChildNodesAreSelectable()
    {
        const string xml = "<root><items><item id='1'><name>A</name></item><item id='2'><name>B</name></item></items></root>";
        var root = await Read(xml, "xml:/root", "sample.xml");
        Assert.Contains("<items>", Assert.IsType<string>(root.Rows[0]["items"]));
        var items = await Read(xml, "xml:/root/items/item", "sample.xml");
        Assert.Equal(2, items.TotalRecords);
        Assert.Equal("A", items.Rows[0]["name"]);
        Assert.Equal("1", items.Rows[0]["@id"]);
    }

    [Fact]
    public void MatchingConfigurationSelectionsAreAccepted()
    {
        const string selection = "json:$.result.data";

        Assert.Equal(selection, StructuredNodeReader.ValidateConfigurationSelections([selection], [selection]));
    }

    [Fact]
    public void LegacyTabCollectionsAreNotChangedByStructuredValidation()
    {
        Assert.Null(StructuredNodeReader.ValidateConfigurationSelections(["Sheet 1", "Sheet 2"], ["Sheet 1", "Sheet 2"]));
    }

    [Theory]
    [InlineData("json:$.items", null)]
    [InlineData("json:$.items", "json:$.other")]
    [InlineData("xml:root/item", "xml:root/item")]
    public void InvalidConfigurationSelectionsFail(string? fileSelection, string? mappingSelection)
    {
        Assert.Throws<InvalidDataException>(() =>
            StructuredNodeReader.ValidateConfigurationSelections([fileSelection], [mappingSelection]));
    }

    [Fact]
    public void OverlongConfigurationSelectionFailsBeforeDatabasePersistence()
    {
        var selection = "json:$" + new string('a', StructuredNodeReader.MaximumSelectionLength);

        Assert.Throws<InvalidDataException>(() =>
            StructuredNodeReader.ValidateConfigurationSelections([selection], [selection]));
    }
}
