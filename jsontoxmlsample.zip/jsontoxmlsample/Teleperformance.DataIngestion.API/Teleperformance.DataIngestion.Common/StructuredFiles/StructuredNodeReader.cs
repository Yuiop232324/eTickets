using System.Text.Json;
using System.Xml;
using System.Xml.Linq;

namespace Teleperformance.DataIngestion.Common.StructuredFiles;

// The format prefix distinguishes node-based configurations from legacy flattened sections.
public static class StructuredNodeReader
{
    public const int MaximumSelectionLength = 100;

    private sealed record AncestorContext(string Path, IReadOnlyDictionary<string, object?> Scalars);
    private sealed record NodeRecord(IReadOnlyDictionary<string, object?> Values,
        IReadOnlyList<AncestorContext> Ancestors);

    public static bool IsSelection(string? section) => section?.StartsWith("json:", StringComparison.Ordinal) == true
        || section?.StartsWith("xml:", StringComparison.Ordinal) == true;

    public static string? ValidateConfigurationSelections(IEnumerable<string?> fileSelections,
        IEnumerable<string?> mappingSelections)
    {
        var files = fileSelections.ToList();
        var mappings = mappingSelections.ToList();
        if (!files.Concat(mappings).Any(IsSelection)) return null;

        if (files.Count != 1 || mappings.Count != 1 || !IsSelection(files[0]) || !IsSelection(mappings[0]))
            throw new InvalidDataException("JSON/XML configurations require one selected node in both file and database settings.");

        var selection = files[0]!;
        if (!string.Equals(selection, mappings[0], StringComparison.Ordinal))
            throw new InvalidDataException("The JSON/XML node in file settings must match the node in database settings.");
        if (selection.Length > MaximumSelectionLength)
            throw new InvalidDataException($"The selected JSON/XML node cannot exceed {MaximumSelectionLength} characters.");

        var validPath = selection.StartsWith("json:", StringComparison.Ordinal)
            ? selection.AsSpan(5).StartsWith("$", StringComparison.Ordinal)
            : selection.AsSpan(4).StartsWith("/", StringComparison.Ordinal);
        if (!validPath || !string.Equals(selection, selection.Trim(), StringComparison.Ordinal))
            throw new InvalidDataException("The selected JSON/XML node is not valid.");

        return selection;
    }

    public static void ValidateFormat(string fileName, string? section)
    {
        if (IsSelection(section) && !Path.GetExtension(fileName).Equals("." + section!.Split(':')[0], StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("The incoming file format does not match the format saved in this process.");
    }

    public static async Task<StructuredFilePreview> ReadAsync(Stream stream, string fileName, string? section,
        int maxRows, CancellationToken cancellationToken)
        => await ReadWithAncestorsAsync(stream, fileName, section, [], maxRows, cancellationToken);

    public static async Task<StructuredFilePreview> ReadAsync(Stream stream, string fileName, string? section,
        StructuredParentFieldSelection? parentSelection, int maxRows, CancellationToken cancellationToken)
        => await ReadWithAncestorsAsync(stream, fileName, section, parentSelection is null ? [] : [parentSelection], maxRows,
            cancellationToken);

    public static async Task<StructuredFilePreview> ReadWithAncestorsAsync(Stream stream, string fileName, string? section,
        IReadOnlyList<StructuredParentFieldSelection> ancestorSelections, int maxRows, CancellationToken cancellationToken)
    {
        ValidateFormat(fileName, section);
        if (maxRows <= 0) throw new ArgumentOutOfRangeException(nameof(maxRows));
        var nodes = new Dictionary<string, List<NodeRecord>>(StringComparer.Ordinal);
        string rootPath;
        string format;
        void Add(string path, IReadOnlyDictionary<string, object?> row, IReadOnlyList<AncestorContext> ancestors)
        {
            if (!nodes.TryGetValue(path, out var rows))
            {
                if (nodes.Count >= 4096) throw new InvalidDataException("The file contains more than 4096 selectable nodes.");
                nodes[path] = rows = new();
            }
            rows.Add(new NodeRecord(row, ancestors));
        }
        if (Path.GetExtension(fileName).Equals(".json", StringComparison.OrdinalIgnoreCase))
        {
            format = "json";
            rootPath = "json:$";
            using var document = await JsonDocument.ParseAsync(stream, new JsonDocumentOptions { MaxDepth = 64 }, cancellationToken);
            object? Value(JsonElement value) => value.ValueKind switch
            {
                JsonValueKind.Null => null,
                JsonValueKind.String => value.GetString(),
                JsonValueKind.True => true,
                JsonValueKind.False => false,
                JsonValueKind.Number => value.TryGetInt64(out var integer) ? integer :
                    value.TryGetDecimal(out var number) ? (object)number : value.GetRawText(),
                _ => value.GetRawText()
            };
            string Child(string path, string name) => name.Length > 0 && (char.IsLetter(name[0]) || name[0] == '_')
                && name.All(c => char.IsLetterOrDigit(c) || c == '_') ? path + "." + name : path + "[" + JsonSerializer.Serialize(name) + "]";
            Dictionary<string, object?> DirectScalars(JsonElement value)
            {
                var scalars = new Dictionary<string, object?>(StringComparer.Ordinal);
                foreach (var property in value.EnumerateObject())
                    if (property.Value.ValueKind is not (JsonValueKind.Object or JsonValueKind.Array))
                        scalars[property.Name] = Value(property.Value);
                return scalars;
            }
            void Visit(JsonElement value, string path, IReadOnlyList<AncestorContext>? ancestors = null,
                bool arrayItem = false)
            {
                cancellationToken.ThrowIfCancellationRequested();
                ancestors ??= [];
                if (value.ValueKind == JsonValueKind.Array)
                {
                    if (!nodes.ContainsKey(path) && nodes.Count >= 4096) throw new InvalidDataException("The file contains more than 4096 selectable nodes.");
                    nodes.TryAdd(path, new());
                    foreach (var item in value.EnumerateArray()) Visit(item, path, ancestors, true);
                    return;
                }
                if (value.ValueKind != JsonValueKind.Object)
                {
                    Add(path, new Dictionary<string, object?> { ["value"] = Value(value) }, ancestors);
                    return;
                }
                var row = new Dictionary<string, object?>(StringComparer.Ordinal);
                foreach (var property in value.EnumerateObject())
                {
                    if (!row.TryAdd(property.Name, Value(property.Value)))
                        throw new InvalidDataException($"Duplicate JSON property '{property.Name}'.");
                }
                Add(path, row, ancestors);
                var childAncestors = ancestors.Append(new AncestorContext(path, DirectScalars(value))).ToList();
                foreach (var property in value.EnumerateObject())
                    Visit(property.Value, Child(path + (arrayItem ? "[]" : ""), property.Name), childAncestors);
            }
            Visit(document.RootElement, rootPath);
        }
        else
        {
            format = "xml";
            using var reader = XmlReader.Create(stream, new XmlReaderSettings { Async = true, DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null });
            var document = await XDocument.LoadAsync(reader, LoadOptions.None, cancellationToken);
            var root = document.Root ?? throw new InvalidDataException("The XML document has no root.");
            rootPath = "xml:/" + root.Name;
            Dictionary<string, object?> DirectScalars(XElement element)
            {
                var scalars = new Dictionary<string, object?>(StringComparer.Ordinal);
                foreach (var attribute in element.Attributes().Where(a => !a.IsNamespaceDeclaration))
                    scalars["@" + attribute.Name] = attribute.Value;
                foreach (var group in element.Elements().GroupBy(e => e.Name))
                {
                    var children = group.ToList();
                    if (children.Count == 1 && !children[0].HasElements && !children[0].HasAttributes)
                        scalars[group.Key.ToString()] = children[0].Value;
                }
                return scalars;
            }
            void Visit(XElement element, string path, int depth,
                IReadOnlyList<AncestorContext>? ancestors = null)
            {
                cancellationToken.ThrowIfCancellationRequested();
                ancestors ??= [];
                if (depth > 64) throw new InvalidDataException("XML nesting cannot exceed 64 levels.");
                var row = new Dictionary<string, object?>(StringComparer.Ordinal);
                foreach (var attribute in element.Attributes().Where(a => !a.IsNamespaceDeclaration)) row["@" + attribute.Name] = attribute.Value;
                if (!element.HasElements) row["value"] = element.Value;
                else
                {
                    foreach (var group in element.Elements().GroupBy(e => e.Name))
                        row[group.Key.ToString()] = group.Count() == 1 && !group.First().HasElements && !group.First().HasAttributes
                            ? group.First().Value : string.Concat(group.Select(e => e.ToString(SaveOptions.DisableFormatting)));
                    var text = string.Concat(element.Nodes().OfType<XText>().Select(t => t.Value));
                    if (!string.IsNullOrWhiteSpace(text)) row["#text"] = text;
                }
                Add(path, row, ancestors);
                var childAncestors = ancestors.Append(new AncestorContext(path, DirectScalars(element))).ToList();
                foreach (var child in element.Elements()) Visit(child, path + "/" + child.Name, depth + 1, childAncestors);
            }
            Visit(root, rootPath, 1);
        }
        var selected = string.IsNullOrWhiteSpace(section) ? rootPath : section;
        if (!nodes.TryGetValue(selected, out var records)) throw new InvalidDataException($"The selected node '{selected}' was not found in the file.");
        if (records.Count == 0) throw new InvalidDataException("The selected node contains no records.");
        var names = records.SelectMany(r => r.Values.Keys).Distinct(StringComparer.Ordinal).ToList();
        if (names.Count == 0 || names.Count > 1024) throw new InvalidDataException("Select a node containing between 1 and 1024 fields.");
        string Type(IEnumerable<object?> values)
        {
            var types = values.Where(v => v is not null)
                .Select(v => v is bool ? "boolean" : v is long ? "integer" : v is decimal ? "decimal" : "string").Distinct().ToList();
            return types.Count == 1 ? types[0] : types.Count == 0 ? "string" : types.All(t => t is "integer" or "decimal") ? "decimal" : "mixed";
        }
        var ancestorPaths = records[0].Ancestors.Select(ancestor => ancestor.Path).ToList();
        if (records.Any(record => !record.Ancestors.Select(ancestor => ancestor.Path).SequenceEqual(ancestorPaths,
                StringComparer.Ordinal)))
            throw new InvalidDataException("The selected table resolves through inconsistent ancestor hierarchies.");
        string SuggestedOutput(string ancestorPath, string sourceField)
        {
            var tableName = ancestorPath.Split(['.', '/'], StringSplitOptions.RemoveEmptyEntries).LastOrDefault()
                ?.Replace("[]", string.Empty, StringComparison.Ordinal) ?? "ancestor";
            var output = new System.Text.StringBuilder();
            var separator = true;
            var prefix = string.Equals(ancestorPath, ancestorPaths.LastOrDefault(), StringComparison.Ordinal)
                ? "parent" : tableName;
            foreach (var character in prefix + "_" + sourceField)
            {
                if (char.IsLetterOrDigit(character))
                {
                    output.Append(char.ToLowerInvariant(character));
                    separator = false;
                }
                else if (!separator && output.Length > 0)
                {
                    output.Append('_');
                    separator = true;
                }
            }
            var value = output.ToString().TrimEnd('_');
            if (string.IsNullOrWhiteSpace(value) || !char.IsLetter(value[0]) && value[0] != '_') value = "ancestor_" + value;
            return value.Length <= 255 ? value : value[..255];
        }
        var ancestorNodes = ancestorPaths.AsEnumerable().Reverse().Select(path =>
        {
            var contexts = records.Select(record => record.Ancestors.Single(ancestor => ancestor.Path == path)).ToList();
            var fieldNames = contexts.SelectMany(context => context.Scalars.Keys)
                .Where(name => name.Length <= 255).Distinct(StringComparer.Ordinal).ToList();
            var options = fieldNames.Select(name => new StructuredParentFieldOption(name,
                Type(contexts.Select(context => context.Scalars.GetValueOrDefault(name))), SuggestedOutput(path, name))).ToList();
            return new StructuredAncestorNode(path, options, []);
        }).ToList();

        var resolvedSelections = new List<StructuredParentFieldSelection>();
        var usedOutputColumns = new HashSet<string>(names, StringComparer.OrdinalIgnoreCase);
        foreach (var selection in ancestorSelections)
        {
            var ancestor = ancestorNodes.FirstOrDefault(node => string.Equals(node.Path, selection.ParentPath, StringComparison.Ordinal))
                ?? throw new InvalidDataException($"The ancestor table '{selection.ParentPath}' does not belong to the selected table.");
            var option = ancestor.Fields.FirstOrDefault(field => string.Equals(field.SourceField, selection.SourceField, StringComparison.Ordinal))
                ?? throw new InvalidDataException($"The field '{selection.SourceField}' was not found on the selected ancestor table (including the immediate parent).");
            var outputColumn = string.IsNullOrWhiteSpace(selection.OutputColumn) ? option.OutputColumn : selection.OutputColumn.Trim();
            if (outputColumn.Length > 255 || !char.IsLetter(outputColumn[0]) && outputColumn[0] != '_'
                || outputColumn.Any(character => !char.IsLetterOrDigit(character) && character != '_'))
                throw new InvalidDataException("An ancestor output column must contain only letters, numbers, and underscores and cannot exceed 255 characters.");
            if (!usedOutputColumns.Add(outputColumn))
                throw new InvalidDataException($"The ancestor output column '{outputColumn}' conflicts with another output field.");
            if (usedOutputColumns.Count > 1024)
                throw new InvalidDataException("The selected table cannot exceed 1024 fields after adding ancestor context columns.");
            if (resolvedSelections.Any(existing => existing.ParentPath == selection.ParentPath
                && existing.SourceField == selection.SourceField))
                throw new InvalidDataException($"The ancestor field '{selection.SourceField}' was selected more than once.");
            resolvedSelections.Add(new StructuredParentFieldSelection(selection.ParentPath, option.SourceField, outputColumn));
        }

        ancestorNodes = ancestorNodes.Select(node => node with
        {
            Selections = resolvedSelections.Where(selection => selection.ParentPath == node.Path).ToList()
        }).ToList();
        IReadOnlyList<IReadOnlyDictionary<string, object?>> outputRows = records.Select(record =>
        {
            var row = new Dictionary<string, object?>(record.Values, StringComparer.Ordinal);
            foreach (var selection in resolvedSelections)
            {
                var context = record.Ancestors.Single(ancestor => ancestor.Path == selection.ParentPath);
                row[selection.OutputColumn] = context.Scalars.GetValueOrDefault(selection.SourceField);
            }
            return (IReadOnlyDictionary<string, object?>)row;
        }).ToList();
        names.AddRange(resolvedSelections.Select(selection => selection.OutputColumn));

        var warnings = new List<string> { "Columns come from the selected table. Unexpanded child objects and arrays are stored in full as text; allow sufficient destination column length." };
        if (resolvedSelections.Count > 0)
            warnings.Add($"{resolvedSelections.Count} ancestor context column(s) are included in the output table.");
        if (records.Count > maxRows) warnings.Add($"Showing {maxRows} of {records.Count} records. All records are used during processing.");
        // Preserve the legacy parent-node contract by exposing the nearest ancestor
        // that actually has selectable scalar fields. AncestorNodes intentionally
        // keeps container-only levels so the UI can explain the complete path.
        var immediateAncestor = ancestorNodes.FirstOrDefault(node => node.Fields.Count > 0);
        return new(format, nodes.Select(n => new StructuredFileSection(n.Key, n.Value.Count)).ToList(), selected,
            names.Select(n => new StructuredFileField(n, Type(outputRows.Select(row => row.GetValueOrDefault(n))))).ToList(),
            outputRows.Take(maxRows).ToList(), records.Count, records.Count > maxRows, warnings,
            immediateAncestor is null ? null : new StructuredParentNode(immediateAncestor.Path, immediateAncestor.Fields,
                immediateAncestor.Selections.FirstOrDefault()), ancestorNodes);
    }
}
