using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Xml;
using System.Xml.Linq;

namespace Teleperformance.DataIngestion.Common.StructuredFiles;

public sealed record StructuredFileSection(string Path, int RecordCount);
public sealed record StructuredFileField(string Name, string DataType);
public sealed record StructuredParentFieldOption(string SourceField, string DataType, string OutputColumn);
public sealed record StructuredParentFieldSelection(string ParentPath, string SourceField, string OutputColumn);
public sealed record StructuredParentNode(string Path, IReadOnlyList<StructuredParentFieldOption> Fields,
    StructuredParentFieldSelection? Selection);
public sealed record StructuredAncestorNode(string Path, IReadOnlyList<StructuredParentFieldOption> Fields,
    IReadOnlyList<StructuredParentFieldSelection> Selections);
public sealed record StructuredFilePreview(string Format, IReadOnlyList<StructuredFileSection> Sections, string SelectedSection,
    IReadOnlyList<StructuredFileField> Fields, IReadOnlyList<IReadOnlyDictionary<string, object?>> Rows,
    int TotalRecords, bool Truncated, IReadOnlyList<string> Warnings, StructuredParentNode? ParentNode = null,
    IReadOnlyList<StructuredAncestorNode>? AncestorNodes = null);
public sealed record StructuredIngestionFile(Stream Content, string FileName, long ContentLength);

public static class StructuredParentFieldSelectionCodec
{
    public const int MaximumSerializedLength = 16000;
    private static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web);

    public static StructuredParentFieldSelection? Parse(string? value)
    {
        var selections = ParseMany(value);
        if (selections.Count > 1)
            throw new InvalidDataException("This operation supports only one parent field selection.");
        return selections.SingleOrDefault();
    }

    public static IReadOnlyList<StructuredParentFieldSelection> ParseMany(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return [];
        if (value.Length > MaximumSerializedLength)
            throw new InvalidDataException($"The ancestor field selections cannot exceed {MaximumSerializedLength} characters.");
        try
        {
            using var document = JsonDocument.Parse(value);
            var selections = document.RootElement.ValueKind switch
            {
                JsonValueKind.Object => [JsonSerializer.Deserialize<StructuredParentFieldSelection>(document.RootElement.GetRawText(), Options)
                    ?? throw new InvalidDataException("The ancestor field selection is empty.")],
                JsonValueKind.Array => JsonSerializer.Deserialize<List<StructuredParentFieldSelection>>(document.RootElement.GetRawText(), Options)
                    ?? [],
                _ => throw new InvalidDataException("The ancestor field selections must be a JSON object or array.")
            };
            if (selections.Count > 64)
                throw new InvalidDataException("A maximum of 64 ancestor context columns can be selected.");
            foreach (var selection in selections) Validate(selection);
            if (selections.Select(selection => selection.OutputColumn).Distinct(StringComparer.OrdinalIgnoreCase).Count() != selections.Count)
                throw new InvalidDataException("Each ancestor context column must have a unique output column name.");
            return selections;
        }
        catch (JsonException error)
        {
            throw new InvalidDataException("The ancestor field selections are not valid JSON.", error);
        }
    }

    public static StructuredParentFieldSelection? ParseForSection(string? section, string? value)
    {
        var selection = Parse(value);
        if (selection is null) return null;
        if (!StructuredNodeReader.IsSelection(section))
            throw new InvalidDataException("A parent field can be saved only with a JSON/XML node selection.");
        var formatPrefix = section!.StartsWith("json:", StringComparison.Ordinal) ? "json:" : "xml:";
        if (!selection.ParentPath.StartsWith(formatPrefix, StringComparison.Ordinal)
            || string.Equals(selection.ParentPath, section, StringComparison.Ordinal)
            || !section.StartsWith(selection.ParentPath, StringComparison.Ordinal))
            throw new InvalidDataException("The parent field does not belong to the selected JSON/XML node.");
        return selection;
    }

    public static IReadOnlyList<StructuredParentFieldSelection> ParseManyForSection(string? section, string? value)
    {
        var selections = ParseMany(value);
        foreach (var selection in selections) ValidateForSection(section, selection);
        return selections;
    }

    public static string? Serialize(StructuredParentFieldSelection? selection)
    {
        if (selection is null) return null;
        Validate(selection);
        var value = JsonSerializer.Serialize(selection, Options);
        if (value.Length > MaximumSerializedLength)
            throw new InvalidDataException($"The parent field selection cannot exceed {MaximumSerializedLength} characters.");
        return value;
    }

    public static string? SerializeMany(IReadOnlyCollection<StructuredParentFieldSelection>? selections)
    {
        if (selections is null || selections.Count == 0) return null;
        foreach (var selection in selections) Validate(selection);
        if (selections.Select(selection => selection.OutputColumn).Distinct(StringComparer.OrdinalIgnoreCase).Count() != selections.Count)
            throw new InvalidDataException("Each ancestor context column must have a unique output column name.");
        var value = selections.Count == 1
            ? JsonSerializer.Serialize(selections.Single(), Options)
            : JsonSerializer.Serialize(selections, Options);
        if (value.Length > MaximumSerializedLength)
            throw new InvalidDataException($"The ancestor field selections cannot exceed {MaximumSerializedLength} characters.");
        return value;
    }

    private static void ValidateForSection(string? section, StructuredParentFieldSelection selection)
    {
        if (!StructuredNodeReader.IsSelection(section))
            throw new InvalidDataException("Ancestor fields can be saved only with a JSON/XML table selection.");
        var formatPrefix = section!.StartsWith("json:", StringComparison.Ordinal) ? "json:" : "xml:";
        if (!selection.ParentPath.StartsWith(formatPrefix, StringComparison.Ordinal)
            || string.Equals(selection.ParentPath, section, StringComparison.Ordinal)
            || !section.StartsWith(selection.ParentPath, StringComparison.Ordinal))
            throw new InvalidDataException("The ancestor field does not belong to the selected JSON/XML table.");
    }

    private static void Validate(StructuredParentFieldSelection selection)
    {
        if (string.IsNullOrWhiteSpace(selection.ParentPath)
            || !StructuredNodeReader.IsSelection(selection.ParentPath)
            || selection.ParentPath.Length > StructuredNodeReader.MaximumSelectionLength)
            throw new InvalidDataException("The immediate parent node path is not valid.");
        if (string.IsNullOrWhiteSpace(selection.SourceField) || selection.SourceField.Length > 255)
            throw new InvalidDataException("The parent source field is not valid.");
        if (string.IsNullOrWhiteSpace(selection.OutputColumn) || selection.OutputColumn.Length > 255
            || !char.IsLetter(selection.OutputColumn[0]) && selection.OutputColumn[0] != '_'
            || selection.OutputColumn.Any(character => !char.IsLetterOrDigit(character) && character != '_'))
            throw new InvalidDataException("The parent output column must contain only letters, numbers, and underscores and cannot exceed 255 characters.");
    }
}

public static class StructuredFileReader
{
    #region JSON/XML validation and normalization

    private const int MaximumDepth = 64;
    private const int MaximumSections = 100;
    private const int MaximumFields = 1024;

    public static async Task<StructuredFilePreview> PreviewAsync(Stream stream, string fileName, string? section, int maxRows,
        long? length = null, CancellationToken cancellationToken = default)
        => await PreviewWithAncestorsAsync(stream, fileName, section, maxRows, length,
            Array.Empty<StructuredParentFieldSelection>(), cancellationToken);

    public static async Task<StructuredFilePreview> PreviewAsync(Stream stream, string fileName, string? section, int maxRows,
        long? length, StructuredParentFieldSelection? parentSelection, CancellationToken cancellationToken = default)
        => await PreviewWithAncestorsAsync(stream, fileName, section, maxRows, length,
            parentSelection is null ? [] : [parentSelection], cancellationToken);

    public static async Task<StructuredFilePreview> PreviewWithAncestorsAsync(Stream stream, string fileName, string? section, int maxRows,
        long? length, IReadOnlyList<StructuredParentFieldSelection> ancestorSelections, CancellationToken cancellationToken = default)
    {
        Validate(fileName, length ?? (stream.CanSeek ? stream.Length : null));
        if (StructuredNodeReader.IsSelection(section))
            return await StructuredNodeReader.ReadWithAncestorsAsync(stream, fileName, section, ancestorSelections, maxRows, cancellationToken);
        if (ancestorSelections.Count > 0)
            throw new InvalidDataException("Ancestor fields are supported only for JSON/XML table selections.");
        var warnings = length > 10 * 1024 * 1024
            ? new List<string> { "Large file detected. Preview rows are limited while the full file remains available for normalization." }
            : new List<string>();
        return Path.GetExtension(fileName).Equals(".json", StringComparison.OrdinalIgnoreCase)
            ? await ReadJsonAsync(stream, section, maxRows, warnings, cancellationToken)
            : await ReadXmlAsync(stream, section, maxRows, warnings, cancellationToken);
    }

    public static async Task<byte[]> NormalizeAsync(Stream stream, string fileName, string? section,
        long? length = null, CancellationToken cancellationToken = default)
        => await NormalizeWithAncestorsAsync(stream, fileName, section, length,
            Array.Empty<StructuredParentFieldSelection>(), cancellationToken);

    public static async Task<byte[]> NormalizeAsync(Stream stream, string fileName, string? section,
        long? length, StructuredParentFieldSelection? parentSelection, CancellationToken cancellationToken = default)
        => await NormalizeWithAncestorsAsync(stream, fileName, section, length,
            parentSelection is null ? [] : [parentSelection], cancellationToken);

    public static async Task<byte[]> NormalizeWithAncestorsAsync(Stream stream, string fileName, string? section,
        long? length, IReadOnlyList<StructuredParentFieldSelection> ancestorSelections, CancellationToken cancellationToken = default)
    {
        var preview = await PreviewWithAncestorsAsync(stream, fileName, section, int.MaxValue, length, ancestorSelections, cancellationToken);
        if (preview.Fields.Count == 0) throw new InvalidDataException("No fields were found in the selected data section.");
        var csv = new StringBuilder().AppendLine(string.Join(',', preview.Fields.Select(field => Escape(field.Name))));
        foreach (var row in preview.Rows) csv.AppendLine(string.Join(',', preview.Fields.Select(field => Escape(row.GetValueOrDefault(field.Name)))));
        return Encoding.UTF8.GetBytes(csv.ToString());
    }

    public static bool Supports(string fileName) => Path.GetExtension(fileName).ToLowerInvariant() is ".json" or ".xml";

    public static async Task<StructuredIngestionFile> PrepareForIngestionAsync(Stream stream, string fileName, string? section,
        long? length = null, CancellationToken cancellationToken = default)
        => await PrepareForIngestionWithAncestorsAsync(stream, fileName, section, length,
            Array.Empty<StructuredParentFieldSelection>(), cancellationToken);

    public static async Task<StructuredIngestionFile> PrepareForIngestionAsync(Stream stream, string fileName, string? section,
        long? length, StructuredParentFieldSelection? parentSelection, CancellationToken cancellationToken = default)
        => await PrepareForIngestionWithAncestorsAsync(stream, fileName, section, length,
            parentSelection is null ? [] : [parentSelection], cancellationToken);

    public static async Task<StructuredIngestionFile> PrepareForIngestionWithAncestorsAsync(Stream stream, string fileName, string? section,
        long? length, IReadOnlyList<StructuredParentFieldSelection> ancestorSelections, CancellationToken cancellationToken = default)
    {
        StructuredNodeReader.ValidateFormat(fileName, section);
        if (!Supports(fileName))
            return new(stream, fileName, length ?? (stream.CanSeek ? stream.Length : 0));

        var content = await NormalizeWithAncestorsAsync(stream, fileName, section, length, ancestorSelections, cancellationToken);
        return new(new MemoryStream(content, writable: false), Path.ChangeExtension(fileName, ".csv"), content.LongLength);
    }

    private static async Task<StructuredFilePreview> ReadJsonAsync(Stream stream, string? requested, int maxRows, List<string> warnings, CancellationToken cancellationToken)
    {
        using var document = await JsonDocument.ParseAsync(stream,
            new JsonDocumentOptions { AllowTrailingCommas = true, MaxDepth = MaximumDepth }, cancellationToken);
        ValidateJson(document.RootElement);
        var candidates = new Dictionary<string, List<JsonElement>>(StringComparer.OrdinalIgnoreCase);
        FindJsonSections(document.RootElement, "$", candidates);
        if (candidates.Count == 0 && document.RootElement.ValueKind == JsonValueKind.Object)
            candidates["$"] = new List<JsonElement> { document.RootElement };
        ValidateSections(candidates.Count);
        var selected = SelectSection(candidates, requested);
        return Build("json", candidates.Select(item => new StructuredFileSection(item.Key, item.Value.Count)), selected.Key,
            selected.Value.Select(FlattenJson), selected.Value.Count, maxRows, warnings);
    }

    private static async Task<StructuredFilePreview> ReadXmlAsync(Stream stream, string? requested, int maxRows, List<string> warnings, CancellationToken cancellationToken)
    {
        using var reader = XmlReader.Create(stream, new XmlReaderSettings { Async = true, DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null });
        var document = await XDocument.LoadAsync(reader, LoadOptions.None, cancellationToken);
        var root = document.Root ?? throw new InvalidDataException("The XML document has no root element.");
        ValidateXml(root);
        var candidatePaths = root.DescendantsAndSelf().SelectMany(parent => parent.Elements().GroupBy(child => child.Name.LocalName)
                .Where(group => group.Count() > 1 || IsRecordElement(group.First()) || parent == root && group.First().HasElements)
                .Select(group => XmlPath(group.First())))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var candidates = root.DescendantsAndSelf().Where(element => candidatePaths.Contains(XmlPath(element)))
            .GroupBy(XmlPath, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.ToList(), StringComparer.OrdinalIgnoreCase);
        if (candidates.Count == 0) candidates[XmlPath(root)] = new List<XElement> { root };
        ValidateSections(candidates.Count);
        var selected = SelectSection(candidates, requested);
        var shape = AnalyzeXmlShape(selected.Value);
        return Build("xml", candidates.Select(item => new StructuredFileSection(item.Key, item.Value.Count)), selected.Key,
            selected.Value.Select(record => FlattenXml(record, shape)), selected.Value.Count, maxRows, warnings);
    }

    private static StructuredFilePreview Build(string format, IEnumerable<StructuredFileSection> sections, string selectedSection,
        IEnumerable<IReadOnlyDictionary<string, object?>> sourceRows, int total, int maxRows, List<string> warnings)
    {
        if (maxRows <= 0) throw new ArgumentOutOfRangeException(nameof(maxRows), "Preview row count must be greater than zero.");
        if (total == 0) throw new InvalidDataException("The selected data section contains no records.");
        var rows = sourceRows.Take(maxRows).ToList();
        var names = rows.SelectMany(row => row.Keys).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (names.Count == 0) throw new InvalidDataException("No fields were found in the selected data section.");
        if (names.Count > MaximumFields)
            throw new InvalidDataException($"The selected data section contains {names.Count:N0} fields; the maximum supported is {MaximumFields:N0}.");
        var fields = names.Select(name => new StructuredFileField(name, InferType(rows.Select(row => row.GetValueOrDefault(name))))).ToList();
        if (rows.Count > 1 && names.Any(name => rows.Count(row => row.ContainsKey(name)) != rows.Count))
            warnings.Add("Some records do not contain the same fields. Missing values will remain empty.");
        var mixed = fields.Where(field => field.DataType == "mixed").Select(field => field.Name).Take(5).ToList();
        if (mixed.Count > 0) warnings.Add($"Mixed data types were detected in: {string.Join(", ", mixed)}.");
        if (total > rows.Count) warnings.Add($"Showing {rows.Count:N0} of {total:N0} records.");
        return new(format, sections.OrderByDescending(item => item.RecordCount).ToList(), selectedSection, fields, rows, total, total > rows.Count, warnings);
    }

    private static void FindJsonSections(JsonElement value, string path, Dictionary<string, List<JsonElement>> found)
    {
        if (value.ValueKind == JsonValueKind.Array)
        {
            var items = value.EnumerateArray().ToList();
            if (items.Count > 0 && (path == "$" || items.All(item => item.ValueKind == JsonValueKind.Object)))
            {
                if (!found.TryGetValue(path, out var records)) found[path] = records = new List<JsonElement>();
                records.AddRange(items);
            }
            foreach (var item in items)
                if (item.ValueKind is JsonValueKind.Object or JsonValueKind.Array) FindJsonSections(item, path + "[]", found);
        }
        else if (value.ValueKind == JsonValueKind.Object)
            foreach (var property in value.EnumerateObject()) FindJsonSections(property.Value, $"{path}.{property.Name}", found);
    }

    private static IReadOnlyDictionary<string, object?> FlattenJson(JsonElement value)
    {
        var row = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
        void Add(string name, object? value)
        {
            if (!row.TryAdd(name, value)) throw new InvalidDataException($"The field '{name}' occurs more than once and cannot be flattened safely.");
        }
        void Visit(JsonElement element, string path)
        {
            if (element.ValueKind == JsonValueKind.Object)
                foreach (var property in element.EnumerateObject()) Visit(property.Value, string.IsNullOrEmpty(path) ? property.Name : $"{path}.{property.Name}");
            else if (element.ValueKind == JsonValueKind.Array)
            {
                var index = 0;
                foreach (var item in element.EnumerateArray()) Visit(item, $"{path}{++index}");
            }
            else Add(string.IsNullOrEmpty(path) ? "value" : path, element.ValueKind switch
            {
                JsonValueKind.String => element.TryGetDateTime(out var date) ? date : element.GetString(),
                JsonValueKind.Number => element.TryGetInt64(out var integer) ? (object)integer : element.GetDecimal(),
                JsonValueKind.True => true,
                JsonValueKind.False => false,
                JsonValueKind.Null or JsonValueKind.Undefined => null,
                _ => throw new InvalidDataException("The selected data section contains an unsupported value.")
            });
        }
        Visit(value, "");
        return row;
    }

    private static IReadOnlyDictionary<string, object?> FlattenXml(XElement element, XmlShape shape)
    {
        var row = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
        void Add(string name, object? value)
        {
            if (!row.TryAdd(name, value)) throw new InvalidDataException($"The field '{name}' occurs more than once and cannot be flattened safely.");
        }
        foreach (var attribute in element.Attributes()) Add($"@{attribute.Name.LocalName}", Scalar(attribute.Value));
        void Visit(XElement node, string outputPath, string logicalPath, string? segment = null)
        {
            var name = string.IsNullOrEmpty(outputPath) ? segment ?? node.Name.LocalName : $"{outputPath}.{segment ?? node.Name.LocalName}";
            foreach (var attribute in node.Attributes()) Add($"{name}.@{attribute.Name.LocalName}", Scalar(attribute.Value));
            if (!node.HasElements)
            {
                if (!shape.Containers.Contains(logicalPath)) Add(name, Scalar(node.Value));
                return;
            }
            foreach (var group in node.Elements().GroupBy(child => child.Name.LocalName))
            {
                var children = group.ToList();
                var childPath = string.IsNullOrEmpty(logicalPath) ? group.Key : $"{logicalPath}.{group.Key}";
                for (var index = 0; index < children.Count; index++)
                    Visit(children[index], name, childPath,
                        shape.Repeated.Contains(childPath) ? $"{children[index].Name.LocalName}{index + 1}" : null);
            }
        }
        if (!element.HasElements) Add(element.Name.LocalName, Scalar(element.Value));
        else foreach (var group in element.Elements().GroupBy(child => child.Name.LocalName))
        {
            var children = group.ToList();
            var childPath = group.Key;
            for (var index = 0; index < children.Count; index++)
                Visit(children[index], "", childPath, shape.Repeated.Contains(childPath) ? $"{children[index].Name.LocalName}{index + 1}" : null);
        }
        return row;
    }

    private sealed record XmlShape(HashSet<string> Repeated, HashSet<string> Containers);
    private static XmlShape AnalyzeXmlShape(IEnumerable<XElement> records)
    {
        var repeated = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var containers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        void Visit(XElement element, string path)
        {
            foreach (var group in element.Elements().GroupBy(child => child.Name.LocalName))
            {
                var childPath = string.IsNullOrEmpty(path) ? group.Key : $"{path}.{group.Key}";
                var children = group.ToList();
                if (children.Count > 1) repeated.Add(childPath);
                foreach (var child in children)
                {
                    if (child.HasElements) containers.Add(childPath);
                    Visit(child, childPath);
                }
            }
        }
        foreach (var record in records) Visit(record, "");
        return new(repeated, containers);
    }

    private static void ValidateJson(JsonElement root)
    {
        if (root.ValueKind is not (JsonValueKind.Object or JsonValueKind.Array))
            throw new InvalidDataException("The JSON root must be an object or an array of records.");
        void Visit(JsonElement value)
        {
            if (value.ValueKind == JsonValueKind.Object)
            {
                var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var property in value.EnumerateObject())
                {
                    if (string.IsNullOrWhiteSpace(property.Name)) throw new InvalidDataException("JSON field names cannot be empty.");
                    if (!names.Add(property.Name)) throw new InvalidDataException($"The JSON object contains the duplicate field '{property.Name}'.");
                    Visit(property.Value);
                }
            }
            else if (value.ValueKind == JsonValueKind.Array)
            {
                var items = value.EnumerateArray().ToList();
                if (items.Any(item => item.ValueKind == JsonValueKind.Array))
                    throw new InvalidDataException("Nested arrays must be contained in named record fields.");
                if (items.Select(item => item.ValueKind == JsonValueKind.Object).Distinct().Count() > 1)
                    throw new InvalidDataException("A JSON record collection cannot mix objects with scalar values.");
                foreach (var item in items) Visit(item);
            }
        }
        Visit(root);
    }

    private static void ValidateXml(XElement root)
    {
        foreach (var element in root.DescendantsAndSelf())
        {
            if (element.Ancestors().Count() >= MaximumDepth)
                throw new InvalidDataException($"XML nesting cannot exceed {MaximumDepth} levels.");
            if (element.HasElements && element.Nodes().OfType<XText>().Any(text => !string.IsNullOrWhiteSpace(text.Value)))
                throw new InvalidDataException($"The element '{element.Name.LocalName}' mixes text and child records and cannot be flattened safely.");
        }
    }

    private static bool IsRecordElement(XElement element) => element.HasElements &&
        element.Elements().Where(child => !child.HasElements).Select(child => child.Name.LocalName).Distinct(StringComparer.OrdinalIgnoreCase).Take(2).Count() == 2;

    private static KeyValuePair<string, List<T>> SelectSection<T>(Dictionary<string, List<T>> sections, string? requested)
    {
        if (!string.IsNullOrWhiteSpace(requested))
        {
            foreach (var section in sections)
                if (section.Key.Equals(requested, StringComparison.OrdinalIgnoreCase)) return section;
            throw new InvalidDataException($"The selected data section '{requested}' was not found in the file.");
        }
        return sections.OrderBy(section => SectionDepth(section.Key)).ThenByDescending(section => section.Value.Count).First();
    }

    private static int SectionDepth(string path) => path.Count(character => character is '/' or '.');
    private static void ValidateSections(int count)
    {
        if (count == 0) throw new InvalidDataException("No record collection was found in the file.");
        if (count > MaximumSections)
            throw new InvalidDataException($"The file contains {count:N0} data sections; the maximum supported is {MaximumSections:N0}.");
    }

    private static object Scalar(string value) => bool.TryParse(value, out var boolean) ? boolean :
        long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var integer) ? integer :
        decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out var number) ? number :
        DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var date) ? date : value;
    private static string XmlPath(XElement element) => "/" + string.Join('/', element.AncestorsAndSelf().Reverse().Select(node => node.Name.LocalName));
    private static string InferType(IEnumerable<object?> values)
    {
        var types = values.Where(value => value is not null).Select(value => value switch
        { bool => "boolean", byte or short or int or long => "integer", float or double or decimal => "decimal", DateTime => "datetime", _ => "string" }).Distinct().ToList();
        return types.Count == 1 ? types[0] : types.Count == 0 ? "string" : types.All(type => type is "integer" or "decimal") ? "decimal" : "mixed";
    }
    private static string Escape(object? value)
    {
        var text = Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
        return text.IndexOfAny([',', '"', '\r', '\n']) < 0 ? text : $"\"{text.Replace("\"", "\"\"")}\"";
    }
    private static void Validate(string fileName, long? length)
    {
        if (!Supports(fileName)) throw new ArgumentException("Only JSON and XML files are supported.", nameof(fileName));
        if (length is 0) throw new ArgumentException("Select a non-empty JSON or XML file.", nameof(fileName));
        if (length > 100 * 1024 * 1024) throw new ArgumentException("JSON/XML files larger than 100MB are not supported.", nameof(fileName));
    }

    #endregion
}
