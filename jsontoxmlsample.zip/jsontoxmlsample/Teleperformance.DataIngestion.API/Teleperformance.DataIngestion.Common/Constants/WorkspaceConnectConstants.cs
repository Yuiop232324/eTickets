namespace Teleperformance.DataIngestion.Common.Constants;

public static class WorkspaceConnectMessages
{
    public const string ConnectorFilterInvalid = "Connector must be all, sharepoint, or google-drive.";
    public const string StatusFilterInvalid = "Status must be all, active, inactive, or draft.";
    public const string ProfileFilterInvalid = "Profile must be all, internal, external, or user.";
    public const string DatabaseConfigurationMissing = "Workspace Connect database configuration is missing.";
}

public static class WorkspaceConnectDefaults
{
    public const int DefaultPageNumber = 1;
    public const int DefaultPageSize = 8;
    public const int MaximumPageSize = 100;
    public const string AllFilter = "all";
}
