using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Xml;
using Teleperformance.DataIngestion.API.Features.StructuredFiles;
using Teleperformance.DataIngestion.Common.StructuredFiles;

namespace Teleperformance.DataIngestion.API.Controllers.v4._1;

[ApiController]
[ApiVersion("4.1")]
[Route("api/structured-files")]
[Authorize]
public sealed class StructuredFilesController(IStructuredFileService service) : ControllerBase
{
    [HttpPost("preview")]
    [RequestSizeLimit(104_857_600)]
    public async Task<IActionResult> Preview([FromForm] StructuredFilePreviewRequest request)
    {
        try
        {
            return Ok(await service.PreviewAsync(request.File, request.Section,
                StructuredParentFieldSelectionCodec.ParseMany(request.ParentSelection),
                Math.Clamp(request.MaxRows, 1, 500), HttpContext.RequestAborted));
        }
        catch (Exception error) when (error is ArgumentException or InvalidDataException or JsonException or XmlException)
        { return BadRequest(new { message = error.Message }); }
    }

    [HttpPost("normalize")]
    [RequestSizeLimit(104_857_600)]
    public async Task<IActionResult> Normalize([FromForm] StructuredFileNormalizeRequest request)
    {
        try
        {
            var content = await service.NormalizeAsync(request.File, request.Section,
                StructuredParentFieldSelectionCodec.ParseMany(request.ParentSelection), HttpContext.RequestAborted);
            return File(content, "text/csv", Path.ChangeExtension(request.File.FileName, ".csv"));
        }
        catch (Exception error) when (error is ArgumentException or InvalidDataException or JsonException or XmlException)
        { return BadRequest(new { message = error.Message }); }
    }
}
