using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Teleperformance.DataIngestion.API.Features.WorkspaceConnectList;
using Teleperformance.DataIngestion.Common.Constants;
using SharePointApiResponse = Teleperformance.DataIngestion.Sharepoint.Models.Response.ApiResponse;

namespace Teleperformance.DataIngestion.API.Controllers.v4._1;

[ApiController]
[ApiVersion("4.1")]
[Route("api/workspace-connect")]
[Authorize]
public sealed class WorkspaceConnectListController : ControllerBase
{
    private readonly IWorkspaceConnectListRepository _listRepository;

    public WorkspaceConnectListController(IWorkspaceConnectListRepository listRepository)
    {
        _listRepository = listRepository;
    }

    [HttpGet("tenants")]
    public async Task<IActionResult> GetTenants(
        int pageNumber = WorkspaceConnectDefaults.DefaultPageNumber,
        int pageSize = WorkspaceConnectDefaults.DefaultPageSize,
        string connector = WorkspaceConnectDefaults.AllFilter,
        string status = WorkspaceConnectDefaults.AllFilter,
        string profile = WorkspaceConnectDefaults.AllFilter,
        string? searchTerm = null,
        int? regionIdent = null,
        string? subRegionCode = null,
        int? clientIdent = null,
        Guid? securityGroupId = null,
        string? securityGroupIds = null)
    {
        pageNumber = Math.Max(1, pageNumber);
        pageSize = Math.Clamp(pageSize, 1, WorkspaceConnectDefaults.MaximumPageSize);
        connector = connector.Trim().ToLowerInvariant();
        status = status.Trim().ToLowerInvariant();
        profile = profile.Trim().ToLowerInvariant();
        if (connector is not ("all" or "sharepoint" or "google-drive"))
            return BadRequest(SharePointApiResponse.Fail(WorkspaceConnectMessages.ConnectorFilterInvalid));
        if (status is not ("all" or "active" or "inactive" or "draft"))
            return BadRequest(SharePointApiResponse.Fail(WorkspaceConnectMessages.StatusFilterInvalid));
        if (profile is not ("all" or "internal" or "external" or "user"))
            return BadRequest(SharePointApiResponse.Fail(WorkspaceConnectMessages.ProfileFilterInvalid));

        var response = await _listRepository.GetPageAsync(new WorkspaceConnectListQuery
        {
            PageNumber = pageNumber,
            PageSize = pageSize,
            Connector = connector,
            Status = status,
            Profile = profile,
            SearchTerm = searchTerm,
            RegionIdent = regionIdent,
            SubRegionCode = subRegionCode,
            ClientIdent = clientIdent,
            SecurityGroupId = securityGroupId,
            SecurityGroupIds = ParseSecurityGroupIds(securityGroupIds)
        }, HttpContext.RequestAborted).ConfigureAwait(false);
        return Ok(SharePointApiResponse.Ok(response));
    }

    private static IReadOnlyCollection<Guid> ParseSecurityGroupIds(string? value) =>
        string.IsNullOrWhiteSpace(value)
            ? []
            : value.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(id => Guid.TryParse(id, out var parsed) ? parsed : Guid.Empty)
                .Where(id => id != Guid.Empty)
                .Distinct()
                .ToArray();
}
