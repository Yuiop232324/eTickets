using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Teleperformance.DataIngestion.GoogleDrive.Constants;
using Teleperformance.DataIngestion.GoogleDrive.Interfaces.V1_0;
using Teleperformance.DataIngestion.GoogleDrive.Models.Request;
using Teleperformance.DataIngestion.GoogleDrive.Models.Response;

namespace Teleperformance.DataIngestion.API.Controllers.v4._1;

[Route("api/[controller]")]
[ApiController]
[EnableCors("CorsPolicy")]
[ApiVersion("4.1")]
[Authorize]
public sealed class GoogleDriveController : ControllerBase
{
    private readonly IGoogleDriveWorkspaceService _googleDriveService;
    private readonly IGoogleDriveTenantService _tenantService;

    public GoogleDriveController(
        IGoogleDriveWorkspaceService googleDriveService,
        IGoogleDriveTenantService tenantService)
    {
        _googleDriveService = googleDriveService ?? throw new ArgumentNullException(nameof(googleDriveService));
        _tenantService = tenantService ?? throw new ArgumentNullException(nameof(tenantService));
    }

    [HttpGet("connector-info")]
    public IActionResult GetGoogleDriveConnectorInfo() =>
        Ok(ApiResponse.Ok(_tenantService.GetConnectorInfo()));

    [HttpGet("tenants")]
    public Task<IActionResult> GetGoogleDriveTenants(
        string? ownerKey = null,
        int? regionIdent = null,
        string? subRegionCode = null,
        int? clientIdent = null,
        Guid? securityGroupId = null,
        string? securityGroupIds = null,
        bool includeInactive = true) =>
        ExecuteAsync(async () =>
        {
            var result = await _tenantService.GetAsync(
                ownerKey,
                regionIdent,
                subRegionCode,
                clientIdent,
                securityGroupId,
                ParseSecurityGroupIds(securityGroupIds),
                includeInactive,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return Ok(ApiResponse.Ok(result));
        });

    private static IReadOnlyCollection<Guid> ParseSecurityGroupIds(string? value) =>
        string.IsNullOrWhiteSpace(value)
            ? []
            : value.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(id => Guid.TryParse(id, out var parsed) ? parsed : Guid.Empty)
                .Where(id => id != Guid.Empty)
                .Distinct()
                .ToArray();

    [HttpGet("tenants/{tenantId:guid}")]
    public Task<IActionResult> GetGoogleDriveTenant(Guid tenantId) =>
        ExecuteAsync(async () =>
        {
            var result = await _tenantService.GetByIdAsync(tenantId, HttpContext.RequestAborted).ConfigureAwait(false);
            return result is null
                ? NotFound(ApiResponse.Fail(GoogleDriveConstants.TenantNotFound))
                : Ok(ApiResponse.Ok(result));
        });

    [HttpPost("tenants")]
    public Task<IActionResult> SaveGoogleDriveTenant(SaveGoogleDriveTenantRequest? request = null) =>
        ExecuteAsync(async () =>
        {
            if (request is null) throw new ArgumentException(GoogleDriveConstants.TenantRequired, nameof(request));
            var result = await _tenantService.SaveAsync(request, HttpContext.RequestAborted).ConfigureAwait(false);
            return Ok(ApiResponse.Ok(result, request.TenantId.HasValue
                ? GoogleDriveConstants.TenantUpdated
                : GoogleDriveConstants.TenantCreated));
        });

    [HttpDelete("tenants/{tenantId:guid}")]
    public Task<IActionResult> DeactivateGoogleDriveTenant(Guid tenantId) =>
        ExecuteAsync(async () =>
        {
            var deactivated = await _tenantService.DeactivateAsync(tenantId, HttpContext.RequestAborted).ConfigureAwait(false);
            return deactivated
                ? Ok(ApiResponse.Ok(true, GoogleDriveConstants.TenantDeactivated))
                : NotFound(ApiResponse.Fail(GoogleDriveConstants.TenantNotFound));
        });

    [HttpPost("tenants/{tenantId:guid}/browse")]
    public Task<IActionResult> BrowseGoogleDriveTenantFolder(
        Guid tenantId,
        BrowseGoogleDriveTenantRequest? request = null) =>
        ExecuteAsync(async () =>
        {
            if (request is null || request.TenantFolderId == Guid.Empty)
                throw new ArgumentException(GoogleDriveConstants.TenantFolderRequired, nameof(request));
            var result = await _tenantService.BrowseAsync(
                tenantId,
                request.TenantFolderId,
                request?.FolderId,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return Ok(ApiResponse.Ok(result));
        });

    [HttpPost("validate")]
    public Task<IActionResult> ValidateGoogleDriveWorkspace(ValidateGoogleDriveWorkspaceRequest? request = null) =>
        ExecuteAsync(async () =>
        {
            RequireValue(request?.WorkspaceUrlOrId, nameof(request.WorkspaceUrlOrId));
            var result = await _googleDriveService.ValidateWorkspaceAsync(
                request!.WorkspaceUrlOrId,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return Ok(ApiResponse.Ok(result));
        });

    [HttpPost("browse")]
    public Task<IActionResult> BrowseGoogleDriveWorkspace(BrowseGoogleDriveWorkspaceRequest? request = null) =>
        ExecuteAsync(async () =>
        {
            RequireValue(request?.WorkspaceUrlOrId, nameof(request.WorkspaceUrlOrId));
            var result = await _googleDriveService.BrowseFolderAsync(
                request!.WorkspaceUrlOrId,
                request.FolderId,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return Ok(ApiResponse.Ok(result));
        });

    [HttpPost("createfolder")]
    public Task<IActionResult> CreateGoogleDriveFolder(CreateGoogleDriveFolderRequest? request = null) =>
        ExecuteAsync(async () =>
        {
            RequireValue(request?.WorkspaceUrlOrId, nameof(request.WorkspaceUrlOrId));
            RequireValue(request?.FolderName, nameof(request.FolderName));
            var result = await _googleDriveService.CreateFolderAsync(
                request!.WorkspaceUrlOrId,
                request.ParentFolderId,
                request.FolderName,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return Ok(ApiResponse.Ok(result));
        });

    [HttpPost("uploadfile")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(367001600)]
    public Task<IActionResult> UploadGoogleDriveFile() =>
        ExecuteAsync(async () =>
        {
            var form = await Request.ReadFormAsync(HttpContext.RequestAborted).ConfigureAwait(false);
            var workspaceUrlOrId = form[GoogleDriveHttpConstants.WorkspaceReferenceField].FirstOrDefault();
            var parentFolderId = form[GoogleDriveHttpConstants.ParentFolderIdField].FirstOrDefault();
            var file = form.Files.GetFile(GoogleDriveHttpConstants.FileField);
            RequireValue(workspaceUrlOrId, nameof(workspaceUrlOrId));
            if (file is null || file.Length == 0) throw new ArgumentException(GoogleDriveConstants.NonEmptyFileRequired, nameof(file));

            await using var content = file.OpenReadStream();
            var result = await _googleDriveService.UploadFileAsync(
                workspaceUrlOrId!,
                string.IsNullOrWhiteSpace(parentFolderId) ? GoogleDriveDefaults.RootFolderId : parentFolderId,
                file.FileName,
                string.IsNullOrWhiteSpace(file.ContentType) ? GoogleDriveDefaults.BinaryContentType : file.ContentType,
                content,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return Ok(ApiResponse.Ok(result));
        });

    [HttpPost("downloadfile")]
    public Task<IActionResult> DownloadGoogleDriveFile(DownloadGoogleDriveFileRequest? request = null) =>
        ExecuteAsync(async () =>
        {
            RequireValue(request?.WorkspaceUrlOrId, nameof(request.WorkspaceUrlOrId));
            RequireValue(request?.FileId, nameof(request.FileId));
            var result = await _googleDriveService.DownloadFileAsync(
                request!.WorkspaceUrlOrId,
                request.FileId,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return File(result.Content, result.ContentType, result.FileName, enableRangeProcessing: false);
        });

    [HttpGet("file")]
    public Task<IActionResult> GetGoogleDriveFile(
        string? workspaceUrlOrId,
        string? fileId,
        bool download = false) =>
        ExecuteAsync(async () =>
        {
            RequireValue(workspaceUrlOrId, nameof(workspaceUrlOrId));
            RequireValue(fileId, nameof(fileId));
            var result = await _googleDriveService.DownloadFileAsync(
                workspaceUrlOrId!,
                fileId!,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return download
                ? File(result.Content, result.ContentType, result.FileName, enableRangeProcessing: false)
                : File(result.Content, result.ContentType, enableRangeProcessing: false);
        });

    [HttpPost("movefile")]
    public Task<IActionResult> MoveGoogleDriveFile(MoveGoogleDriveFileRequest? request = null) =>
        ExecuteAsync(async () =>
        {
            RequireValue(request?.WorkspaceUrlOrId, nameof(request.WorkspaceUrlOrId));
            RequireValue(request?.FileId, nameof(request.FileId));
            var result = await _googleDriveService.MoveFileAsync(
                request!.WorkspaceUrlOrId,
                request.FileId,
                request.DestinationFolderId,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return Ok(ApiResponse.Ok(result));
        });

    [HttpPost("deleteitem")]
    public Task<IActionResult> DeleteGoogleDriveItem(DeleteGoogleDriveItemRequest? request = null) =>
        ExecuteAsync(async () =>
        {
            RequireValue(request?.WorkspaceUrlOrId, nameof(request.WorkspaceUrlOrId));
            RequireValue(request?.ItemId, nameof(request.ItemId));
            var result = await _googleDriveService.MoveItemToTrashAsync(
                request!.WorkspaceUrlOrId,
                request.ItemId,
                HttpContext.RequestAborted).ConfigureAwait(false);
            return Ok(ApiResponse.Ok(result));
        });

    private async Task<IActionResult> ExecuteAsync(Func<Task<IActionResult>> action)
    {
        try
        {
            return await action().ConfigureAwait(false);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ApiResponse.Fail(ex.Message));
        }
        catch (SqlException ex) when (ex.Number == 50001)
        {
            return Conflict(ApiResponse.Fail(ex.Message));
        }
        catch (SqlException ex) when (ex.Number == 50002)
        {
            return StatusCode(StatusCodes.Status503ServiceUnavailable, ApiResponse.Fail(ex.Message));
        }
        catch (NotSupportedException ex)
        {
            return StatusCode(StatusCodes.Status415UnsupportedMediaType, ApiResponse.Fail(ex.Message));
        }
        catch (GoogleDriveOperationException ex)
        {
            var statusCode = ex.StatusCode is >= 400 and <= 599
                ? ex.StatusCode
                : StatusCodes.Status502BadGateway;
            return StatusCode(statusCode, ApiResponse.Fail(ex.Message));
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(ApiResponse.Fail(ex.Message));
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ApiResponse.Fail(ex.Message));
        }
    }

    private static void RequireValue(string? value, string name)
    {
        if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException(string.Format(GoogleDriveConstants.RequiredValue, name), name);
    }
}
