using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace Teleperformance.DataIngestion.API.Authentication;

public static class GoogleDriveDevelopmentAuthenticationDefaults
{
    public const string Scheme = "GoogleDriveDevelopment";
    public const string AuthenticationSchemes = "Bearer," + Scheme;
    public const string GuestToken = "guest-dev-bypass-token";
}

/// <summary>
/// Allows the LocalTesting guest session to exercise only endpoints that
/// explicitly opt into this scheme. It never authenticates outside Development.
/// </summary>
public sealed class GoogleDriveDevelopmentAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    private readonly IWebHostEnvironment _environment;

    public GoogleDriveDevelopmentAuthenticationHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory logger,
        UrlEncoder encoder,
        IWebHostEnvironment environment)
        : base(options, logger, encoder)
    {
        _environment = environment;
    }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        if (!_environment.IsDevelopment())
        {
            return Task.FromResult(AuthenticateResult.NoResult());
        }

        var authorization = Request.Headers.Authorization.ToString();
        var expected = $"Bearer {GoogleDriveDevelopmentAuthenticationDefaults.GuestToken}";
        if (!string.Equals(authorization, expected, StringComparison.Ordinal))
        {
            return Task.FromResult(AuthenticateResult.NoResult());
        }

        Claim[] claims =
        [
            new(ClaimTypes.NameIdentifier, "local-google-drive-guest"),
            new(ClaimTypes.Name, "Local Google Drive Guest")
        ];
        var identity = new ClaimsIdentity(claims, Scheme.Name);
        var principal = new ClaimsPrincipal(identity);
        var ticket = new AuthenticationTicket(principal, Scheme.Name);
        return Task.FromResult(AuthenticateResult.Success(ticket));
    }
}
