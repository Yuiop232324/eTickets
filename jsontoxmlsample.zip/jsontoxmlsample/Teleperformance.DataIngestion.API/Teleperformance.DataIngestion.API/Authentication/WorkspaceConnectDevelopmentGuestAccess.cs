namespace Teleperformance.DataIngestion.API.Authentication;

/// <summary>
/// Keeps the LocalTesting guest token out of the production token-decryption
/// pipeline for Workspace Connect endpoints only. This is never enabled
/// outside the Development environment.
/// </summary>
public static class WorkspaceConnectDevelopmentGuestAccess
{
    public static bool ShouldBypassTokenDecryption(HttpContext context, string token)
    {
        var environment = context.RequestServices.GetRequiredService<IWebHostEnvironment>();
        if (!environment.IsDevelopment()
            || !string.Equals(token, GoogleDriveDevelopmentAuthenticationDefaults.GuestToken, StringComparison.Ordinal))
        {
            return false;
        }

        var path = context.Request.Path;
        return path.StartsWithSegments("/api/GoogleDrive")
            || path.StartsWithSegments("/api/workspace-connect")
#region Structured JSON/XML files
            || path.StartsWithSegments("/api/structured-files")
#endregion
            || path.StartsWithSegments("/api/applications")
            || path.StartsWithSegments("/api/workspace")
            || string.Equals(path.Value, "/api/auth/requesttoken", StringComparison.OrdinalIgnoreCase)
            || string.Equals(path.Value, "/api/auth/token", StringComparison.OrdinalIgnoreCase);
    }
}
