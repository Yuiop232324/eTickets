using Teleperformance.DataIngestion.Common.Constants;

namespace Teleperformance.DataIngestion.API.Features.WorkspaceConnectList;

public sealed class WorkspaceConnectListQuery
{
    public int PageNumber { get; init; }
    public int PageSize { get; init; }
    public string Connector { get; init; } = WorkspaceConnectDefaults.AllFilter;
    public string Status { get; init; } = WorkspaceConnectDefaults.AllFilter;
    public string Profile { get; init; } = WorkspaceConnectDefaults.AllFilter;
    public string? SearchTerm { get; init; }
    public int? RegionIdent { get; init; }
    public string? SubRegionCode { get; init; }
    public int? ClientIdent { get; init; }
    public Guid? SecurityGroupId { get; init; }
    public IReadOnlyCollection<Guid>? SecurityGroupIds { get; init; }
}
