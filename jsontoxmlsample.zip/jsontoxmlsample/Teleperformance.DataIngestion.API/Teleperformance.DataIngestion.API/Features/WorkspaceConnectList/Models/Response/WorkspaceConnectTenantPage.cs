using Teleperformance.DataIngestion.GoogleDrive.Models.Response;
using Teleperformance.DataIngestion.Sharepoint.Models.Response;

namespace Teleperformance.DataIngestion.API.Features.WorkspaceConnectList;

public sealed class WorkspaceConnectTenantPage
{
    public IReadOnlyList<Application> Applications { get; init; } = [];
    public IReadOnlyList<GoogleDriveTenant> Tenants { get; init; } = [];
    public int PageNumber { get; init; }
    public int PageSize { get; init; }
    public int FilteredCount { get; init; }
    public int TotalCount { get; init; }
    public int SharePointCount { get; init; }
    public int GoogleDriveCount { get; init; }
    public int ActiveCount { get; init; }
    public int DraftCount { get; init; }
    public int InactiveCount { get; init; }
    public IReadOnlyList<WorkspaceConnectMonthlyCount> MonthlyCounts { get; init; } = [];
}

public sealed class WorkspaceConnectMonthlyCount
{
    public int Year { get; init; }
    public int Month { get; init; }
    public int SharePoint { get; init; }
    public int GoogleDrive { get; init; }
}

internal sealed class WorkspaceConnectPageSummary
{
    public int PageNumber { get; init; }
    public int PageSize { get; init; }
    public int FilteredCount { get; init; }
    public int TotalCount { get; init; }
    public int SharePointCount { get; init; }
    public int GoogleDriveCount { get; init; }
    public int ActiveCount { get; init; }
    public int DraftCount { get; init; }
    public int InactiveCount { get; init; }
}
