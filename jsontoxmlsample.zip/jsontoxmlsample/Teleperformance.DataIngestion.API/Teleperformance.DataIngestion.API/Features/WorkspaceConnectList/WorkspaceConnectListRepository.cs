using System.Data;
using Dapper;
using Microsoft.Data.SqlClient;
using Teleperformance.DataIngestion.Common;
using Teleperformance.DataIngestion.Common.Constants;
using Teleperformance.DataIngestion.GoogleDrive.Models.Response;
using Teleperformance.DataIngestion.Sharepoint.Configuration;
using Teleperformance.DataIngestion.Sharepoint.Models.Response;

namespace Teleperformance.DataIngestion.API.Features.WorkspaceConnectList;

public interface IWorkspaceConnectListRepository
{
    Task<WorkspaceConnectTenantPage> GetPageAsync(WorkspaceConnectListQuery query, CancellationToken cancellationToken);
}

public sealed class WorkspaceConnectListRepository : IWorkspaceConnectListRepository
{
    private readonly string _connectionString;
    private readonly int _commandTimeout;

    public WorkspaceConnectListRepository()
    {
#if DEBUG
        var localConnectionString = Environment.GetEnvironmentVariable("connectionstring")?.Trim();
        if (!string.IsNullOrWhiteSpace(localConnectionString))
        {
            _connectionString = localConnectionString;
            _commandTimeout = WorkspaceConnectSharePointConfiguration.DatabaseCommandTimeoutSeconds;
            return;
        }
#endif
        _connectionString = KeyVault.GetKeyVaultValue(
                WorkspaceConnectSharePointConfiguration.DataIngestionConnectionStringSecret).Result
            ?? throw new InvalidOperationException(WorkspaceConnectMessages.DatabaseConfigurationMissing);
        _commandTimeout = WorkspaceConnectSharePointConfiguration.DatabaseCommandTimeoutSeconds;
    }

    public async Task<WorkspaceConnectTenantPage> GetPageAsync(WorkspaceConnectListQuery query, CancellationToken cancellationToken)
    {
        await using var connection = new SqlConnection(_connectionString);
        var command = new CommandDefinition(
            "dbo.sel_workspace_connect_tenantpage",
            new
            {
                query.PageNumber,
                query.PageSize,
                query.Connector,
                query.Status,
                query.Profile,
                query.SearchTerm,
                query.RegionIdent,
                query.SubRegionCode,
                query.ClientIdent,
                query.SecurityGroupId,
                Securitygroupids = JoinSecurityGroupIds(query.SecurityGroupIds)
            },
            commandType: CommandType.StoredProcedure,
            commandTimeout: _commandTimeout,
            cancellationToken: cancellationToken);

        using var results = await connection.QueryMultipleAsync(command).ConfigureAwait(false);
        var summary = await results.ReadSingleAsync<WorkspaceConnectPageSummary>().ConfigureAwait(false);
        var monthlyCounts = (await results.ReadAsync<WorkspaceConnectMonthlyCount>().ConfigureAwait(false)).AsList();
        var applications = (await results.ReadAsync<Application>().ConfigureAwait(false)).AsList();
        var tenants = (await results.ReadAsync<GoogleDriveTenant>().ConfigureAwait(false)).AsList();
        var folders = (await results.ReadAsync<GoogleDriveTenantFolder>().ConfigureAwait(false)).AsList();
        var sites = (await results.ReadAsync<ApplicationSite>().ConfigureAwait(false)).AsList();

        var foldersByTenant = folders.GroupBy(folder => folder.TenantId).ToDictionary(group => group.Key, group => group.ToList());
        foreach (var tenant in tenants)
            tenant.Folders = foldersByTenant.GetValueOrDefault(tenant.TenantId) ?? [];

        var sitesByApplication = sites.GroupBy(site => site.ApplicationId).ToDictionary(group => group.Key, group => group.ToList());
        foreach (var application in applications)
            application.Sites = sitesByApplication.GetValueOrDefault(application.ApplicationId) ?? [];

        return new WorkspaceConnectTenantPage
        {
            Applications = applications,
            Tenants = tenants,
            PageNumber = summary.PageNumber,
            PageSize = summary.PageSize,
            FilteredCount = summary.FilteredCount,
            TotalCount = summary.TotalCount,
            SharePointCount = summary.SharePointCount,
            GoogleDriveCount = summary.GoogleDriveCount,
            ActiveCount = summary.ActiveCount,
            DraftCount = summary.DraftCount,
            InactiveCount = summary.InactiveCount,
            MonthlyCounts = monthlyCounts
        };
    }

    private static string? JoinSecurityGroupIds(IReadOnlyCollection<Guid>? securityGroupIds) =>
        securityGroupIds is { Count: > 0 }
            ? string.Join(',', securityGroupIds.Distinct())
            : null;
}
