using Teleperformance.DataIngestion.Common.StructuredFiles;

namespace Teleperformance.DataIngestion.API.Features.StructuredFiles;

public sealed class StructuredFileService : IStructuredFileService
{
    public async Task<StructuredFilePreview> PreviewAsync(IFormFile file, string? section,
        IReadOnlyList<StructuredParentFieldSelection> ancestorSelections, int maxRows, CancellationToken cancellationToken)
    {
        Validate(file);
        await using var stream = file.OpenReadStream();
        if (string.IsNullOrWhiteSpace(section))
        {
            if (ancestorSelections.Count > 0)
                throw new InvalidDataException("Select a JSON/XML table before adding ancestor context columns.");
            return await StructuredNodeReader.ReadAsync(stream, file.FileName, null, maxRows, cancellationToken);
        }
        return await StructuredFileReader.PreviewWithAncestorsAsync(stream, file.FileName, section, maxRows, file.Length,
            ancestorSelections, cancellationToken);
    }

    public async Task<byte[]> NormalizeAsync(IFormFile file, string? section,
        IReadOnlyList<StructuredParentFieldSelection> ancestorSelections, CancellationToken cancellationToken)
    {
        Validate(file);
        if (string.IsNullOrWhiteSpace(section))
        {
            if (ancestorSelections.Count > 0)
                throw new InvalidDataException("Select a JSON/XML table before adding ancestor context columns.");
            section = (await PreviewAsync(file, null, [], 1, cancellationToken)).SelectedSection;
        }
        await using var stream = file.OpenReadStream();
        return await StructuredFileReader.NormalizeWithAncestorsAsync(stream, file.FileName, section, file.Length,
            ancestorSelections, cancellationToken);
    }

    private static void Validate(IFormFile file)
    {
        if (file is null || file.Length == 0) throw new ArgumentException("Select a non-empty JSON or XML file.", nameof(file));
        if (!StructuredFileReader.Supports(file.FileName)) throw new ArgumentException("Select a JSON or XML file.");
        if (file.Length > 100 * 1024 * 1024) throw new ArgumentException("JSON/XML files larger than 100MB are not supported.");
    }
}
