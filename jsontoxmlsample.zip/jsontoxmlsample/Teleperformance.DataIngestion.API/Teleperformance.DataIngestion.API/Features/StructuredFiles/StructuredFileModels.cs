using Teleperformance.DataIngestion.Common.StructuredFiles;

namespace Teleperformance.DataIngestion.API.Features.StructuredFiles;

public sealed class StructuredFilePreviewRequest
{
    public required IFormFile File { get; init; }
    public string? Section { get; init; }
    public string? ParentSelection { get; init; }
    public int MaxRows { get; init; } = 50;
}

public sealed class StructuredFileNormalizeRequest
{
    public required IFormFile File { get; init; }
    public string? Section { get; init; }
    public string? ParentSelection { get; init; }
}

public interface IStructuredFileService
{
    Task<StructuredFilePreview> PreviewAsync(IFormFile file, string? section,
        IReadOnlyList<StructuredParentFieldSelection> ancestorSelections, int maxRows, CancellationToken cancellationToken);
    Task<byte[]> NormalizeAsync(IFormFile file, string? section,
        IReadOnlyList<StructuredParentFieldSelection> ancestorSelections, CancellationToken cancellationToken);
}
