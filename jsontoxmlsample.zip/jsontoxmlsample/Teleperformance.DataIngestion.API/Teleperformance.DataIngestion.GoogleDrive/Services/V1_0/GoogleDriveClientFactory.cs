using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Services;
using Teleperformance.DataIngestion.GoogleDrive.Configuration;
using Teleperformance.DataIngestion.GoogleDrive.Interfaces.V1_0;

namespace Teleperformance.DataIngestion.GoogleDrive.Services.V1_0;

public sealed class GoogleDriveClientFactory : IGoogleDriveClientFactory
{
    private readonly GoogleDriveWorkspaceOptions _options;

    public GoogleDriveClientFactory(GoogleDriveWorkspaceOptions options)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _options.Validate();
    }

    public DriveService CreateClient()
    {
        var initializer = new ServiceAccountCredential.Initializer(_options.ClientEmail, _options.TokenUri)
        {
            ProjectId = _options.ProjectId,
            Scopes = _options.Scopes
        }.FromPrivateKey(_options.PrivateKey);

        var credential = new ServiceAccountCredential(initializer);
        return new DriveService(new BaseClientService.Initializer
        {
            HttpClientInitializer = credential,
            ApplicationName = _options.ApplicationName
        });
    }
}
