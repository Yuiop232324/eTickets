using Teleperformance.DataIngestion.GoogleDrive.Configuration;
using Teleperformance.DataIngestion.GoogleDrive.Constants;
using Teleperformance.DataIngestion.GoogleDrive.Interfaces.V1_0;
using Teleperformance.DataIngestion.GoogleDrive.Models.Request;
using Teleperformance.DataIngestion.GoogleDrive.Models.Response;
using Teleperformance.DataIngestion.GoogleDrive.Utilities;

namespace Teleperformance.DataIngestion.GoogleDrive.Services.V1_0;

public sealed class GoogleDriveTenantService : IGoogleDriveTenantService
{
    private static readonly Guid AllSecurityGroups = Guid.Empty;
    private readonly IGoogleDriveTenantRepository _repository;
    private readonly IGoogleDriveWorkspaceService _workspaceService;
    private readonly GoogleDriveWorkspaceOptions _options;

    public GoogleDriveTenantService(
        IGoogleDriveTenantRepository repository,
        IGoogleDriveWorkspaceService workspaceService,
        GoogleDriveWorkspaceOptions options)
    {
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        _workspaceService = workspaceService ?? throw new ArgumentNullException(nameof(workspaceService));
        _options = options ?? throw new ArgumentNullException(nameof(options));
    }

    public GoogleDriveConnectorInfo GetConnectorInfo() => new()
    {
        ServiceAccountEmail = _options.ClientEmail,
        ConnectorMode = GoogleDriveDefaults.ConnectorMode,
        RequiredPermission = GoogleDriveDefaults.RequiredPermission,
        PermissionGuidance = GoogleDriveConstants.ConnectorPermissionGuidance
    };

    public Task<IReadOnlyList<GoogleDriveTenant>> GetAsync(
        string? ownerKey,
        int? regionIdent,
        string? subRegionCode,
        int? clientIdent,
        Guid? securityGroupId,
        IReadOnlyCollection<Guid>? securityGroupIds,
        bool includeInactive,
        CancellationToken cancellationToken = default) =>
        _repository.GetAsync(ownerKey, regionIdent, subRegionCode, clientIdent, securityGroupId, securityGroupIds, includeInactive, cancellationToken);

    public Task<GoogleDriveTenant?> GetByIdAsync(Guid tenantId, CancellationToken cancellationToken = default) =>
        _repository.GetByIdAsync(tenantId, cancellationToken);

    public async Task<GoogleDriveTenant> SaveAsync(
        SaveGoogleDriveTenantRequest request,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);
        RequireValue(request.DisplayName, nameof(request.DisplayName));
        RequireValue(request.Owner, nameof(request.Owner));

        var displayName = request.DisplayName.Trim();

        var folderRequests = request.Folders ?? [];
        if (!request.IsDraft)
        {
            if (request.RegionIdent is null or <= 0) throw new ArgumentException(GoogleDriveConstants.RegionRequired, nameof(request.RegionIdent));
            if (folderRequests.Count == 0) throw new ArgumentException(GoogleDriveConstants.ApprovedFolderRequired, nameof(request.Folders));
        }

        var folders = new List<GoogleDriveTenantFolder>();
        var knownFolderIds = new HashSet<string>(StringComparer.Ordinal);
        for (var index = 0; index < folderRequests.Count; index++)
        {
            var folderRequest = folderRequests[index];
            if (string.IsNullOrWhiteSpace(folderRequest.FolderUrlOrId))
            {
                continue;
            }
            GoogleDriveTenantFolder folder;
            if (request.IsDraft)
            {
                try
                {
                    var folderId = GoogleDriveIdParser.Parse(folderRequest.FolderUrlOrId);
                    folder = new GoogleDriveTenantFolder
                    {
                        FolderId = folderId,
                        FolderName = folderId,
                        PermissionConfirmed = folderRequest.PermissionConfirmed,
                        SortOrder = index,
                        IsActive = false
                    };
                }
                catch (ArgumentException)
                {
                    continue;
                }
            }
            else if (!folderRequest.PermissionConfirmed)
            {
                try
                {
                    var folderId = GoogleDriveIdParser.Parse(folderRequest.FolderUrlOrId);
                    folder = new GoogleDriveTenantFolder
                    {
                        FolderId = folderId,
                        FolderName = folderId,
                        PermissionConfirmed = false,
                        SortOrder = index,
                        IsActive = false
                    };
                }
                catch (ArgumentException)
                {
                    continue;
                }
            }
            else
            {
                try
                {
                    var connectivity = await _workspaceService.ValidateWorkspaceAsync(folderRequest.FolderUrlOrId, cancellationToken).ConfigureAwait(false);
                    folder = new GoogleDriveTenantFolder
                    {
                        FolderId = connectivity.FolderId,
                        FolderName = connectivity.FolderName,
                        FolderWebViewLink = connectivity.WebViewLink,
                        DriveId = connectivity.DriveId,
                        PermissionConfirmed = true,
                        SortOrder = index,
                        IsActive = true
                    };
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
                {
                    throw;
                }
                catch
                {
                    try
                    {
                        var folderId = GoogleDriveIdParser.Parse(folderRequest.FolderUrlOrId);
                        folder = new GoogleDriveTenantFolder
                        {
                            FolderId = folderId,
                            FolderName = folderId,
                            PermissionConfirmed = false,
                            SortOrder = index,
                            IsActive = false
                        };
                    }
                    catch (ArgumentException)
                    {
                        continue;
                    }
                }
            }

            if (!knownFolderIds.Add(folder.FolderId))
                throw new ArgumentException(string.Format(GoogleDriveConstants.DuplicateFolder, folder.FolderName), nameof(request.Folders));
            folders.Add(folder);
        }

        var securityGroups = request.SecurityGroups
            .Where(group => group.Id != Guid.Empty && group.Id != AllSecurityGroups)
            .GroupBy(group => group.Id)
            .Select(group => group.First())
            .ToList();
        if (securityGroups.Count == 0 && request.SecurityGroupId is { } legacyId && legacyId != AllSecurityGroups)
        {
            securityGroups.Add(new GoogleDriveTenantSecurityGroupRequest
            {
                Id = legacyId,
                Name = string.IsNullOrWhiteSpace(request.SecurityGroupName) ? legacyId.ToString() : request.SecurityGroupName.Trim()
            });
        }
        var primarySecurityGroup = securityGroups.FirstOrDefault();

        var tenant = new GoogleDriveTenant
        {
            TenantId = request.TenantId ?? Guid.Empty,
            OwnerKey = string.IsNullOrWhiteSpace(request.OwnerKey) ? GoogleDriveDefaults.OwnerKey : request.OwnerKey.Trim(),
            DisplayName = displayName,
            Owner = request.Owner.Trim(),
            OwnerUpn = TrimOrNull(request.OwnerUpn),
            CoOwner = TrimOrNull(request.CoOwner),
            CoOwnerUpn = TrimOrNull(request.CoOwnerUpn),
            Notes = TrimOrNull(request.Notes),
            RegionIdent = request.RegionIdent,
            RegionName = TrimOrNull(request.RegionName),
            SubRegionCode = string.IsNullOrWhiteSpace(request.SubRegionCode) ? GoogleDriveDefaults.AllCode : request.SubRegionCode.Trim(),
            SubRegionName = string.IsNullOrWhiteSpace(request.SubRegionName) ? GoogleDriveDefaults.AllLabel : request.SubRegionName.Trim(),
            ClientIdent = request.ClientIdent is null or <= 0 ? 0 : request.ClientIdent,
            ClientName = request.ClientIdent is null or <= 0 || string.IsNullOrWhiteSpace(request.ClientName) ? GoogleDriveDefaults.AllLabel : request.ClientName.Trim(),
            SecurityGroupId = primarySecurityGroup?.Id ?? AllSecurityGroups,
            SecurityGroupName = primarySecurityGroup is null ? GoogleDriveDefaults.AllLabel : primarySecurityGroup.Name.Trim(),
            SecurityGroups = securityGroups.Select(group => new GoogleDriveTenantSecurityGroup
            {
                Id = group.Id,
                Name = string.IsNullOrWhiteSpace(group.Name) ? group.Id.ToString() : group.Name.Trim()
            }).ToList(),
            IsActive = !request.IsDraft && request.IsActive && folders.Any(folder => folder.IsActive && folder.PermissionConfirmed),
            IsDraft = request.IsDraft,
            Folders = folders
        };

        return await _repository.SaveAsync(tenant, cancellationToken).ConfigureAwait(false);
    }

    public Task<bool> DeactivateAsync(Guid tenantId, CancellationToken cancellationToken = default) =>
        _repository.DeactivateAsync(tenantId, cancellationToken);

    public async Task<IReadOnlyList<GoogleDriveItem>> BrowseAsync(
        Guid tenantId,
        Guid tenantFolderId,
        string? folderId,
        CancellationToken cancellationToken = default)
    {
        var tenant = await _repository.GetByIdAsync(tenantId, cancellationToken).ConfigureAwait(false)
            ?? throw new KeyNotFoundException(GoogleDriveConstants.TenantNotFound);
        if (!tenant.IsActive || tenant.IsDraft)
            throw new InvalidOperationException(GoogleDriveConstants.TenantNotReady);

        var approvedFolder = tenant.Folders.FirstOrDefault(folder =>
            folder.TenantFolderId == tenantFolderId && folder.IsActive && folder.PermissionConfirmed)
            ?? throw new KeyNotFoundException(GoogleDriveConstants.ApprovedFolderNotFound);

        return await _workspaceService.BrowseFolderAsync(approvedFolder.FolderId, folderId, cancellationToken).ConfigureAwait(false);
    }

    private static void RequireValue(string? value, string name)
    {
        if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException(string.Format(GoogleDriveConstants.RequiredValue, name), name);
    }

    private static string? TrimOrNull(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
