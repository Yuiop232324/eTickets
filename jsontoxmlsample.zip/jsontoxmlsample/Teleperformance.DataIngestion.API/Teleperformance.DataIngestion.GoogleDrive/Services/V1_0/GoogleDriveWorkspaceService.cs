using Google.Apis.Download;
using Google.Apis.Drive.v3;
using Google.Apis.Drive.v3.Data;
using Google.Apis.Upload;
using Teleperformance.DataIngestion.GoogleDrive.Constants;
using Teleperformance.DataIngestion.GoogleDrive.Interfaces.V1_0;
using Teleperformance.DataIngestion.GoogleDrive.Models.Response;
using Teleperformance.DataIngestion.GoogleDrive.Utilities;
using DriveFile = Google.Apis.Drive.v3.Data.File;

namespace Teleperformance.DataIngestion.GoogleDrive.Services.V1_0;

public sealed class GoogleDriveWorkspaceService : IGoogleDriveWorkspaceService, IDisposable
{
    private const string FileFields = "id,name,mimeType,size,modifiedTime,webViewLink,parents,trashed,driveId,shortcutDetails";
    private readonly DriveService _drive;

    public GoogleDriveWorkspaceService(IGoogleDriveClientFactory clientFactory)
    {
        ArgumentNullException.ThrowIfNull(clientFactory);
        _drive = clientFactory.CreateClient();
    }

    public async Task<WorkspaceConnectivityResult> ValidateWorkspaceAsync(string workspaceUrlOrId, CancellationToken cancellationToken = default)
    {
        var workspaceId = GoogleDriveIdParser.Parse(workspaceUrlOrId);
        var folder = await GetMetadataAsync(workspaceId, cancellationToken).ConfigureAwait(false);

        if (!string.Equals(folder.MimeType, GoogleDriveConstants.FolderMimeType, StringComparison.Ordinal))
        {
            throw new InvalidOperationException(GoogleDriveConstants.WorkspaceMustBeFolder);
        }

        return new WorkspaceConnectivityResult
        {
            IsConnected = true,
            FolderId = folder.Id,
            FolderName = folder.Name,
            WebViewLink = folder.WebViewLink,
            DriveId = folder.DriveId,
            Message = GoogleDriveConstants.WorkspaceAccessVerified
        };
    }

    public async Task<IReadOnlyList<GoogleDriveItem>> BrowseFolderAsync(string workspaceUrlOrId, string? folderId = null, CancellationToken cancellationToken = default)
    {
        var workspaceId = GoogleDriveIdParser.Parse(workspaceUrlOrId);
        var targetId = ResolveTargetId(workspaceId, folderId);
        await RequireFolderInsideWorkspaceAsync(workspaceId, targetId, cancellationToken).ConfigureAwait(false);

        var items = new List<GoogleDriveItem>();
        string? pageToken = null;

        do
        {
            var request = _drive.Files.List();
            request.Q = $"'{targetId}' in parents and trashed = false";
            request.Spaces = "drive";
            request.PageSize = 1000;
            request.PageToken = pageToken;
            request.SupportsAllDrives = true;
            request.IncludeItemsFromAllDrives = true;
            request.OrderBy = "folder,name_natural";
            request.Fields = $"nextPageToken,files({FileFields})";

            var page = await ExecuteGoogleRequestAsync(
                () => request.ExecuteAsync(cancellationToken)).ConfigureAwait(false);
            items.AddRange((page.Files ?? [])
                .Where(file => !string.Equals(file.MimeType, GoogleDriveConstants.ShortcutMimeType, StringComparison.Ordinal))
                .Select(MapItem));
            pageToken = page.NextPageToken;
        }
        while (!string.IsNullOrWhiteSpace(pageToken));

        return items;
    }

    public async Task<GoogleDriveItem> CreateFolderAsync(string workspaceUrlOrId, string parentFolderId, string folderName, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(folderName)) throw new ArgumentException(GoogleDriveConstants.FolderNameRequired, nameof(folderName));

        var workspaceId = GoogleDriveIdParser.Parse(workspaceUrlOrId);
        var targetId = ResolveTargetId(workspaceId, parentFolderId);
        await RequireFolderInsideWorkspaceAsync(workspaceId, targetId, cancellationToken).ConfigureAwait(false);

        var metadata = new DriveFile
        {
            Name = folderName.Trim(),
            MimeType = GoogleDriveConstants.FolderMimeType,
            Parents = [targetId]
        };

        var request = _drive.Files.Create(metadata);
        request.SupportsAllDrives = true;
        request.Fields = FileFields;
        return MapItem(await ExecuteGoogleRequestAsync(
            () => request.ExecuteAsync(cancellationToken)).ConfigureAwait(false));
    }

    public async Task<GoogleDriveItem> UploadFileAsync(string workspaceUrlOrId, string parentFolderId, string fileName, string contentType, Stream content, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(fileName)) throw new ArgumentException(GoogleDriveConstants.FileNameRequired, nameof(fileName));
        ArgumentNullException.ThrowIfNull(content);

        var workspaceId = GoogleDriveIdParser.Parse(workspaceUrlOrId);
        var targetId = ResolveTargetId(workspaceId, parentFolderId);
        await RequireFolderInsideWorkspaceAsync(workspaceId, targetId, cancellationToken).ConfigureAwait(false);

        var metadata = new DriveFile { Name = fileName.Trim(), Parents = [targetId] };
        var request = _drive.Files.Create(metadata, content, string.IsNullOrWhiteSpace(contentType) ? GoogleDriveDefaults.BinaryContentType : contentType);
        request.SupportsAllDrives = true;
        request.Fields = FileFields;

        var progress = await request.UploadAsync(cancellationToken).ConfigureAwait(false);
        if (progress.Status != UploadStatus.Completed || request.ResponseBody is null)
        {
            if (progress.Exception is Google.GoogleApiException googleException)
            {
                throw ToOperationException(googleException);
            }

            throw progress.Exception ?? new InvalidOperationException(GoogleDriveConstants.UploadFailed);
        }

        return MapItem(request.ResponseBody);
    }

    public async Task<GoogleDriveDownload> DownloadFileAsync(string workspaceUrlOrId, string fileId, CancellationToken cancellationToken = default)
    {
        var workspaceId = GoogleDriveIdParser.Parse(workspaceUrlOrId);
        await RequireInsideWorkspaceAsync(workspaceId, fileId, cancellationToken).ConfigureAwait(false);
        var file = await GetMetadataAsync(fileId, cancellationToken).ConfigureAwait(false);

        if (string.Equals(file.MimeType, GoogleDriveConstants.FolderMimeType, StringComparison.Ordinal))
        {
            throw new InvalidOperationException(GoogleDriveConstants.FolderCannotBeDownloaded);
        }

        var stream = new MemoryStream();
        string outputName;
        string contentType;

        if (file.MimeType.StartsWith(GoogleDriveConstants.GoogleMimeTypePrefix, StringComparison.OrdinalIgnoreCase))
        {
            if (!GoogleDriveExportFormats.TryGet(file.MimeType, out var format))
            {
                throw new NotSupportedException(string.Format(GoogleDriveConstants.UnsupportedGoogleFileType, file.MimeType));
            }

            var request = _drive.Files.Export(file.Id, format.ContentType);
            var progress = await request.DownloadAsync(stream, cancellationToken).ConfigureAwait(false);
            EnsureDownloadCompleted(progress);
            outputName = Path.ChangeExtension(file.Name, format.Extension);
            contentType = format.ContentType;
        }
        else
        {
            var request = _drive.Files.Get(file.Id);
            request.SupportsAllDrives = true;
            var progress = await request.DownloadAsync(stream, cancellationToken).ConfigureAwait(false);
            EnsureDownloadCompleted(progress);
            outputName = file.Name;
            contentType = file.MimeType;
        }

        stream.Position = 0;
        return new GoogleDriveDownload
        {
            Content = stream,
            FileName = outputName,
            ContentType = string.IsNullOrWhiteSpace(contentType) ? GoogleDriveDefaults.BinaryContentType : contentType,
            ContentLength = stream.Length
        };
    }

    public async Task<GoogleDriveItem> MoveFileAsync(string workspaceUrlOrId, string fileId, string destinationFolderId, CancellationToken cancellationToken = default)
    {
        return await MoveFileInternalAsync(workspaceUrlOrId, fileId, destinationFolderId, null, cancellationToken).ConfigureAwait(false);
    }

    public async Task<GoogleDriveItem> MoveFileAsync(string workspaceUrlOrId, string fileId, string destinationFolderId, string newFileName, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(newFileName)) throw new ArgumentException(GoogleDriveConstants.NewFileNameRequired, nameof(newFileName));
        return await MoveFileInternalAsync(workspaceUrlOrId, fileId, destinationFolderId, newFileName.Trim(), cancellationToken).ConfigureAwait(false);
    }

    private async Task<GoogleDriveItem> MoveFileInternalAsync(string workspaceUrlOrId, string fileId, string destinationFolderId, string? newFileName, CancellationToken cancellationToken)
    {
        var workspaceId = GoogleDriveIdParser.Parse(workspaceUrlOrId);
        var targetId = ResolveTargetId(workspaceId, destinationFolderId);
        await RequireInsideWorkspaceAsync(workspaceId, fileId, cancellationToken).ConfigureAwait(false);
        await RequireFolderInsideWorkspaceAsync(workspaceId, targetId, cancellationToken).ConfigureAwait(false);

        var source = await GetMetadataAsync(fileId, cancellationToken).ConfigureAwait(false);
        var workspaceParents = new List<string>();

        foreach (var parentId in source.Parents ?? [])
        {
            if (await IsInsideWorkspaceAsync(workspaceId, parentId, cancellationToken).ConfigureAwait(false))
            {
                workspaceParents.Add(parentId);
            }
        }

        if (workspaceParents.Count == 0)
        {
            throw new InvalidOperationException(string.Format(GoogleDriveConstants.ItemOutsideWorkspace, fileId));
        }

        var request = _drive.Files.Update(
            string.IsNullOrWhiteSpace(newFileName) ? new DriveFile() : new DriveFile { Name = newFileName },
            fileId);
        request.AddParents = targetId;
        request.RemoveParents = string.Join(',', workspaceParents);
        request.SupportsAllDrives = true;
        request.Fields = FileFields;
        return MapItem(await ExecuteGoogleRequestAsync(
            () => request.ExecuteAsync(cancellationToken)).ConfigureAwait(false));
    }

    public async Task<GoogleDriveItem> MoveItemToTrashAsync(string workspaceUrlOrId, string itemId, CancellationToken cancellationToken = default)
    {
        var workspaceId = GoogleDriveIdParser.Parse(workspaceUrlOrId);
        if (string.Equals(workspaceId, itemId, StringComparison.Ordinal))
        {
            throw new InvalidOperationException(GoogleDriveConstants.WorkspaceRootCannotBeTrashed);
        }

        await RequireInsideWorkspaceAsync(workspaceId, itemId, cancellationToken).ConfigureAwait(false);
        var request = _drive.Files.Update(new DriveFile { Trashed = true }, itemId);
        request.SupportsAllDrives = true;
        request.Fields = FileFields;
        return MapItem(await ExecuteGoogleRequestAsync(
            () => request.ExecuteAsync(cancellationToken)).ConfigureAwait(false));
    }

    private async Task<DriveFile> GetMetadataAsync(string fileId, CancellationToken cancellationToken)
    {
        var request = _drive.Files.Get(fileId);
        request.SupportsAllDrives = true;
        request.Fields = FileFields;
        return await ExecuteGoogleRequestAsync(
            () => request.ExecuteAsync(cancellationToken)).ConfigureAwait(false);
    }

    private async Task RequireFolderInsideWorkspaceAsync(string workspaceId, string folderId, CancellationToken cancellationToken)
    {
        await RequireInsideWorkspaceAsync(workspaceId, folderId, cancellationToken).ConfigureAwait(false);
        var folder = await GetMetadataAsync(folderId, cancellationToken).ConfigureAwait(false);
        if (!string.Equals(folder.MimeType, GoogleDriveConstants.FolderMimeType, StringComparison.Ordinal))
        {
            throw new InvalidOperationException(string.Format(GoogleDriveConstants.TargetMustBeFolder, folderId));
        }
    }

    private async Task RequireInsideWorkspaceAsync(string workspaceId, string fileId, CancellationToken cancellationToken)
    {
        if (!await IsInsideWorkspaceAsync(workspaceId, fileId, cancellationToken).ConfigureAwait(false))
        {
            throw new InvalidOperationException(string.Format(GoogleDriveConstants.ItemOutsideWorkspace, fileId));
        }
    }

    private async Task<bool> IsInsideWorkspaceAsync(string workspaceId, string fileId, CancellationToken cancellationToken)
    {
        if (string.Equals(workspaceId, fileId, StringComparison.Ordinal)) return true;

        var pending = new Queue<string>();
        var visited = new HashSet<string>(StringComparer.Ordinal) { fileId };
        pending.Enqueue(fileId);

        while (pending.Count > 0 && visited.Count <= 1000)
        {
            var current = await GetMetadataAsync(pending.Dequeue(), cancellationToken).ConfigureAwait(false);
            foreach (var parentId in current.Parents ?? [])
            {
                if (string.Equals(parentId, workspaceId, StringComparison.Ordinal)) return true;
                if (visited.Add(parentId)) pending.Enqueue(parentId);
            }
        }

        return false;
    }

    private static string ResolveTargetId(string workspaceId, string? targetId) =>
        string.IsNullOrWhiteSpace(targetId) || string.Equals(targetId, GoogleDriveDefaults.RootFolderId, StringComparison.OrdinalIgnoreCase)
            ? workspaceId
            : GoogleDriveIdParser.Parse(targetId);

    private static GoogleDriveItem MapItem(DriveFile file) => new()
    {
        Id = file.Id,
        Name = file.Name,
        DownloadName = GoogleDriveExportFormats.ResolveOutputFileName(file.Name, file.MimeType),
        MimeType = file.MimeType,
        Size = file.Size,
        ModifiedTime = file.ModifiedTimeDateTimeOffset,
        WebViewLink = file.WebViewLink,
        ParentIds = file.Parents?.ToArray() ?? [],
        IsFolder = string.Equals(file.MimeType, GoogleDriveConstants.FolderMimeType, StringComparison.Ordinal),
        IsShortcut = string.Equals(file.MimeType, GoogleDriveConstants.ShortcutMimeType, StringComparison.Ordinal),
        IsTrashed = file.Trashed ?? false
    };

    private static void EnsureDownloadCompleted(IDownloadProgress progress)
    {
        if (progress.Status == DownloadStatus.Completed) return;
        if (progress.Exception is Google.GoogleApiException googleException)
        {
            throw ToOperationException(googleException);
        }

        throw progress.Exception ?? new InvalidOperationException(GoogleDriveConstants.DownloadFailed);
    }

    private static async Task<T> ExecuteGoogleRequestAsync<T>(Func<Task<T>> action)
    {
        try
        {
            return await action().ConfigureAwait(false);
        }
        catch (Google.GoogleApiException ex)
        {
            throw ToOperationException(ex);
        }
    }

    private static GoogleDriveOperationException ToOperationException(Google.GoogleApiException exception)
    {
        var statusCode = (int)exception.HttpStatusCode;
        var message = exception.Error?.Message;
        if (string.IsNullOrWhiteSpace(message)) message = exception.Message;
        return new GoogleDriveOperationException(message, statusCode, exception);
    }

    public void Dispose() => _drive.Dispose();
}
