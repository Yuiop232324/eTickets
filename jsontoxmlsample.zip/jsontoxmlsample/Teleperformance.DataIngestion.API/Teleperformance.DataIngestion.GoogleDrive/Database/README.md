# Google Drive database source

The authoritative, deployment-ready tenant and multi-folder SQL scripts are kept in the workspace-level `Google drive Database` folder as requested.

The former single-table `WorkspaceConnect.GoogleDrive.sql` script was removed because the runtime now uses the normalized `di_gdrive_tenant` and `di_gdrive_tenantfolder` objects.

