using Teleperformance.DataIngestion.GoogleDrive.Constants;

namespace Teleperformance.DataIngestion.GoogleDrive.Configuration;

public sealed class GoogleDriveWorkspaceOptions
{
    public string ProjectId { get; init; } = string.Empty;
    public string ClientEmail { get; init; } = string.Empty;
    public string? ClientId { get; init; }
    public string PrivateKey { get; init; } = string.Empty;
    public string TokenUri { get; init; } = "https://oauth2.googleapis.com/token";
    public string ApplicationName { get; init; } = GoogleDriveConstants.DefaultApplicationName;
    public IReadOnlyList<string> Scopes { get; init; } = [GoogleDriveConstants.DefaultServiceAccountScope];

    public static GoogleDriveWorkspaceOptions FromEnvironment()
    {
        var scopeValue = GetOptional(GoogleDriveEnvironmentVariables.ServiceAccountScope);

        var options = new GoogleDriveWorkspaceOptions
        {
            ProjectId = GetRequired(GoogleDriveEnvironmentVariables.ProjectId),
            ClientEmail = GetRequired(GoogleDriveEnvironmentVariables.ClientEmail),
            ClientId = GetOptional(GoogleDriveEnvironmentVariables.ClientId),
            PrivateKey = NormalizePrivateKey(GetRequired(GoogleDriveEnvironmentVariables.PrivateKey)),
            TokenUri = GetOptional(GoogleDriveEnvironmentVariables.TokenUri) ?? "https://oauth2.googleapis.com/token",
            Scopes = ParseScopes(scopeValue)
        };

        options.Validate();
        return options;
    }

    public void Validate()
    {
        var missing = new List<string>();
        if (string.IsNullOrWhiteSpace(ProjectId)) missing.Add(GoogleDriveEnvironmentVariables.ProjectId);
        if (string.IsNullOrWhiteSpace(ClientEmail)) missing.Add(GoogleDriveEnvironmentVariables.ClientEmail);
        if (string.IsNullOrWhiteSpace(PrivateKey)) missing.Add(GoogleDriveEnvironmentVariables.PrivateKey);
        if (string.IsNullOrWhiteSpace(TokenUri)) missing.Add(GoogleDriveEnvironmentVariables.TokenUri);
        if (Scopes.Count == 0) missing.Add(GoogleDriveEnvironmentVariables.ServiceAccountScope);

        if (missing.Count > 0)
        {
            throw new InvalidOperationException(string.Format(GoogleDriveConstants.ConfigurationMissing, string.Join(", ", missing)));
        }
    }

    private static string GetRequired(string name) =>
        GetOptional(name) ?? throw new InvalidOperationException(string.Format(GoogleDriveConstants.ConfigurationMissing, name));

    private static string? GetOptional(string name)
    {
        var value = Environment.GetEnvironmentVariable(name);
        return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
    }

    private static string NormalizePrivateKey(string privateKey) =>
        privateKey.Replace("\\n", "\n", StringComparison.Ordinal).Trim();

    private static IReadOnlyList<string> ParseScopes(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return [GoogleDriveConstants.DefaultServiceAccountScope];

        return value.Split([',', ';', ' '], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Distinct(StringComparer.Ordinal)
            .ToArray();
    }
}
