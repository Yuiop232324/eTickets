using Teleperformance.DataIngestion.GoogleDrive.Models.Response;

namespace Teleperformance.DataIngestion.GoogleDrive.Interfaces.V1_0;

public interface IGoogleDriveWorkspaceService
{
    Task<WorkspaceConnectivityResult> ValidateWorkspaceAsync(string workspaceUrlOrId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<GoogleDriveItem>> BrowseFolderAsync(string workspaceUrlOrId, string? folderId = null, CancellationToken cancellationToken = default);
    Task<GoogleDriveItem> CreateFolderAsync(string workspaceUrlOrId, string parentFolderId, string folderName, CancellationToken cancellationToken = default);
    Task<GoogleDriveItem> UploadFileAsync(string workspaceUrlOrId, string parentFolderId, string fileName, string contentType, Stream content, CancellationToken cancellationToken = default);
    Task<GoogleDriveDownload> DownloadFileAsync(string workspaceUrlOrId, string fileId, CancellationToken cancellationToken = default);
    Task<GoogleDriveItem> MoveFileAsync(string workspaceUrlOrId, string fileId, string destinationFolderId, CancellationToken cancellationToken = default);
    Task<GoogleDriveItem> MoveFileAsync(string workspaceUrlOrId, string fileId, string destinationFolderId, string newFileName, CancellationToken cancellationToken = default);
    Task<GoogleDriveItem> MoveItemToTrashAsync(string workspaceUrlOrId, string itemId, CancellationToken cancellationToken = default);
}
