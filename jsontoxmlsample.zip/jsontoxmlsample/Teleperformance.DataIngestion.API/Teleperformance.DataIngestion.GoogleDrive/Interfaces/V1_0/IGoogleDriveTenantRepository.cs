using Teleperformance.DataIngestion.GoogleDrive.Models.Response;

namespace Teleperformance.DataIngestion.GoogleDrive.Interfaces.V1_0;

public interface IGoogleDriveTenantRepository
{
    Task<IReadOnlyList<GoogleDriveTenant>> GetAsync(
        string? ownerKey,
        int? regionIdent,
        string? subRegionCode,
        int? clientIdent,
        Guid? securityGroupId,
        IReadOnlyCollection<Guid>? securityGroupIds,
        bool includeInactive,
        CancellationToken cancellationToken = default);

    Task<GoogleDriveTenant?> GetByIdAsync(Guid tenantId, CancellationToken cancellationToken = default);
    Task<GoogleDriveTenant> SaveAsync(GoogleDriveTenant tenant, CancellationToken cancellationToken = default);
    Task<bool> DeactivateAsync(Guid tenantId, CancellationToken cancellationToken = default);
}

