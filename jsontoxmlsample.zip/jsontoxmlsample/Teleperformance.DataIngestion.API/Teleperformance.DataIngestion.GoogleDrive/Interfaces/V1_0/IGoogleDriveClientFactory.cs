using Google.Apis.Drive.v3;

namespace Teleperformance.DataIngestion.GoogleDrive.Interfaces.V1_0;

public interface IGoogleDriveClientFactory
{
    DriveService CreateClient();
}
