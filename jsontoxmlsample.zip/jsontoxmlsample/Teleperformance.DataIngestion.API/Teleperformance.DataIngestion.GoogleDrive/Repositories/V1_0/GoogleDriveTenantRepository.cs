using System.Data;
using System.Text.Json;
using Dapper;
using Microsoft.Data.SqlClient;
using Teleperformance.DataIngestion.Common;
using Teleperformance.DataIngestion.GoogleDrive.Constants;
using Teleperformance.DataIngestion.GoogleDrive.Interfaces.V1_0;
using Teleperformance.DataIngestion.GoogleDrive.Models.Response;

namespace Teleperformance.DataIngestion.GoogleDrive.Repositories.V1_0;

public sealed class GoogleDriveTenantRepository : IGoogleDriveTenantRepository
{
    private const string ConnectionStringSecret = "TPDataIngestionConnectionString";
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);
    private readonly string _connectionString;

    public GoogleDriveTenantRepository()
    {
        _connectionString = ResolveConnectionString();
    }

    private static string ResolveConnectionString()
    {
#if DEBUG
        var localConnectionString = Environment.GetEnvironmentVariable("googledrivedbconnectionstring")?.Trim();
        if (!string.IsNullOrWhiteSpace(localConnectionString)) return localConnectionString;
#endif
        try
        {
            var secretValue = KeyVault.GetKeyVaultValue(ConnectionStringSecret).Result?.Trim();
            if (!string.IsNullOrWhiteSpace(secretValue)) return secretValue;
        }
        catch
        {
            // Throw final clear message below.
        }

        throw new InvalidOperationException(string.Format(
            GoogleDriveConstants.DatabaseConfigurationMissing,
            ConnectionStringSecret));
    }

    public async Task<IReadOnlyList<GoogleDriveTenant>> GetAsync(
        string? ownerKey,
        int? regionIdent,
        string? subRegionCode,
        int? clientIdent,
        Guid? securityGroupId,
        IReadOnlyCollection<Guid>? securityGroupIds,
        bool includeInactive,
        CancellationToken cancellationToken = default)
    {
        await using var connection = await OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        var command = new CommandDefinition(
            "dbo.sel_gdrive_tenant",
            new
            {
                Ownerkey = NullIfBlank(ownerKey),
                Regionident = regionIdent,
                Subregioncode = NullIfBlank(subRegionCode),
                Clientident = clientIdent,
                Securitygroupid = securityGroupId,
                Securitygroupids = JoinSecurityGroupIds(securityGroupIds),
                Includeinactive = includeInactive
            },
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken);
        var tenants = (await connection.QueryAsync<GoogleDriveTenant>(command).ConfigureAwait(false)).AsList();
        await PopulateSecurityGroupsAsync(connection, tenants, cancellationToken).ConfigureAwait(false);
        foreach (var tenant in tenants)
        {
            tenant.Folders = (await GetFoldersAsync(connection, tenant.TenantId, includeInactive, null, cancellationToken).ConfigureAwait(false)).ToList();
            tenant.FolderCount = tenant.Folders.Count(folder => folder.IsActive);
        }
        return tenants;
    }

    public async Task<GoogleDriveTenant?> GetByIdAsync(Guid tenantId, CancellationToken cancellationToken = default)
    {
        await using var connection = await OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        var command = new CommandDefinition(
            "dbo.sel_gdrive_tenantbyid",
            new { Tenantid = tenantId },
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken);
        var tenant = await connection.QuerySingleOrDefaultAsync<GoogleDriveTenant>(command).ConfigureAwait(false);
        if (tenant is null) return null;
        await PopulateSecurityGroupsAsync(connection, [tenant], cancellationToken).ConfigureAwait(false);
        tenant.Folders = (await GetFoldersAsync(connection, tenantId, true, null, cancellationToken).ConfigureAwait(false)).ToList();
        tenant.FolderCount = tenant.Folders.Count(folder => folder.IsActive);
        return tenant;
    }

    public async Task<GoogleDriveTenant> SaveAsync(GoogleDriveTenant tenant, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(tenant);
        await using var connection = await OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        await using var transaction = await connection.BeginTransactionAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var saveTenant = new CommandDefinition(
                "dbo.commit_gdrive_tenant",
                new
                {
                    Tenantid = tenant.TenantId == Guid.Empty ? (Guid?)null : tenant.TenantId,
                    Ownerkey = tenant.OwnerKey,
                    Displayname = tenant.DisplayName,
                    Owner = tenant.Owner,
                    Ownerupn = NullIfBlank(tenant.OwnerUpn),
                    Coowner = NullIfBlank(tenant.CoOwner),
                    Coownerupn = NullIfBlank(tenant.CoOwnerUpn),
                    Notes = NullIfBlank(tenant.Notes),
                    Regionident = tenant.RegionIdent,
                    Regionname = NullIfBlank(tenant.RegionName),
                    Subregioncode = NullIfBlank(tenant.SubRegionCode),
                    Subregionname = NullIfBlank(tenant.SubRegionName),
                    Clientident = tenant.ClientIdent,
                    Clientname = NullIfBlank(tenant.ClientName),
                    Securitygroupid = tenant.SecurityGroupId,
                    Securitygroupname = NullIfBlank(tenant.SecurityGroupName),
                    Securitygroupsjson = JsonSerializer.Serialize(tenant.SecurityGroups.Select(group => new { id = group.Id, name = group.Name }), JsonOptions),
                    Isactive = tenant.IsActive,
                    Isdraft = tenant.IsDraft
                },
                transaction: transaction,
                commandType: CommandType.StoredProcedure,
                cancellationToken: cancellationToken);
            var saved = await connection.QuerySingleAsync<GoogleDriveTenant>(saveTenant).ConfigureAwait(false);
            await PopulateSecurityGroupsAsync(connection, [saved], cancellationToken, transaction).ConfigureAwait(false);

            var folderPayload = tenant.Folders.Select((folder, index) => new
            {
                folder.FolderId,
                folder.FolderName,
                folder.FolderWebViewLink,
                folder.DriveId,
                folder.PermissionConfirmed,
                folder.IsActive,
                SortOrder = index
            });
            var saveFolders = new CommandDefinition(
                "dbo.commit_gdrive_tenantfolders",
                new { Tenantid = saved.TenantId, FoldersJson = JsonSerializer.Serialize(folderPayload, JsonOptions) },
                transaction: transaction,
                commandType: CommandType.StoredProcedure,
                cancellationToken: cancellationToken);
            saved.Folders = (await connection.QueryAsync<GoogleDriveTenantFolder>(saveFolders).ConfigureAwait(false)).AsList();
            saved.FolderCount = saved.Folders.Count(folder => folder.IsActive);

            await transaction.CommitAsync(cancellationToken).ConfigureAwait(false);
            return saved;
        }
        catch
        {
            await transaction.RollbackAsync(cancellationToken).ConfigureAwait(false);
            throw;
        }
    }

    public async Task<bool> DeactivateAsync(Guid tenantId, CancellationToken cancellationToken = default)
    {
        await using var connection = await OpenConnectionAsync(cancellationToken).ConfigureAwait(false);
        var command = new CommandDefinition(
            "dbo.commit_gdrive_tenantdelete",
            new { Tenantid = tenantId },
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken);
        return await connection.ExecuteScalarAsync<int>(command).ConfigureAwait(false) > 0;
    }

    private static async Task<IReadOnlyList<GoogleDriveTenantFolder>> GetFoldersAsync(
        SqlConnection connection,
        Guid tenantId,
        bool includeInactive,
        IDbTransaction? transaction,
        CancellationToken cancellationToken)
    {
        var command = new CommandDefinition(
            "dbo.sel_gdrive_tenantfolders",
            new { Tenantid = tenantId, Includeinactive = includeInactive },
            transaction: transaction,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken);
        return (await connection.QueryAsync<GoogleDriveTenantFolder>(command).ConfigureAwait(false)).AsList();
    }

    private static async Task PopulateSecurityGroupsAsync(
        SqlConnection connection,
        IReadOnlyCollection<GoogleDriveTenant> tenants,
        CancellationToken cancellationToken,
        IDbTransaction? transaction = null)
    {
        if (tenants.Count == 0) return;
        var command = new CommandDefinition(
            "dbo.sel_gdrive_tenantsecuritygroups",
            new { Tenantidsjson = JsonSerializer.Serialize(tenants.Select(tenant => tenant.TenantId), JsonOptions) },
            transaction: transaction,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken);
        var groups = await connection.QueryAsync<GoogleDriveTenantSecurityGroupRow>(command).ConfigureAwait(false);
        var byTenant = groups.GroupBy(group => group.TenantId).ToDictionary(group => group.Key, group => group
            .OrderBy(item => item.SortOrder)
            .Select(item => new GoogleDriveTenantSecurityGroup { Id = item.Id, Name = item.Name })
            .ToList());
        foreach (var tenant in tenants)
        {
            tenant.SecurityGroups = byTenant.GetValueOrDefault(tenant.TenantId) ?? [];
        }
    }

    private static string? JoinSecurityGroupIds(IReadOnlyCollection<Guid>? securityGroupIds) =>
        securityGroupIds is { Count: > 0 } ? string.Join(',', securityGroupIds.Distinct()) : null;

    private sealed class GoogleDriveTenantSecurityGroupRow
    {
        public Guid TenantId { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int SortOrder { get; set; }
    }

    private async Task<SqlConnection> OpenConnectionAsync(CancellationToken cancellationToken)
    {
        var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken).ConfigureAwait(false);
        return connection;
    }

    private static string? NullIfBlank(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
