# TPDI Google Drive workspace

This project is an isolated backend library for the Google Drive connector. It follows the same solution-level project boundary as `Teleperformance.DataIngestion.Sharepoint`.

It is included in `Teleperformance.DataIngestion.API.sln` and is consumed only by dedicated Google Drive endpoints in the API project. SharePoint, Data Access, ingestion, and Function App projects do not reference it.

## Current scope

- Authenticate as the configured UAT service account.
- Validate a folder URL or folder ID shared with that service account.
- Browse a registered workspace folder.
- Create folders and upload files.
- Download binary files and export supported Google Workspace files.
- Move files between folders inside the registered workspace.
- Move an item to trash while preventing the registered workspace root from being trashed.
- Reject operations on items outside the registered workspace hierarchy.
- Persist Google Drive tenants and their approved folders through a Google Drive-only repository, normalized tables, and stored procedures.
- Allow one tenant to own multiple independently verified folder roots without storing service-account credentials per tenant.
- List, edit, deactivate, and browse tenants and approved folders.

The existing ingestion process, SharePoint persistence, OAuth/Picker UI, and Function App remain out of scope.

## Configuration

The console reads the same service-account variable names already established for UAT:

- `googledriveserviceaccountprojectid`
- `googledriveserviceaccountemail`
- `googledriveserviceaccountclientid` (optional for Drive calls)
- `googledriveserviceaccountprivatekey`
- `googledriveserviceaccounttokenuri`
- `googledriveserviceaccountscope` (optional; defaults to the Drive scope)

No JSON credential file is required at runtime. The private-key value can contain real line breaks or escaped `\n` sequences.

## Integration boundary

The connector uses `dbo.di_gdrive_tenant`, `dbo.di_gdrive_tenantfolder`, and only the dedicated `sel_gdrive_*` / `commit_gdrive_*` procedures in the workspace-level `Google drive Database` folder. The legacy `dbo.di_gdrive_registration` table is preserved only as an additive migration source. The connector does not read or write SharePoint registration or Data Ingestion process tables.

Database access resolves the shared `TPDataIngestionConnectionString` secret directly from Key Vault. There is no local connection-string environment-variable fallback.

## API endpoints

The API exposes a single secured, versioned `GoogleDriveController` under `api/GoogleDrive`:

- `POST validate`
- `POST browse`
- `POST createfolder`
- `POST uploadfile` (`multipart/form-data`)
- `POST downloadfile`
- `GET file`
- `POST movefile`
- `POST deleteitem`
- `GET connector-info`
- `GET tenants`
- `GET tenants/{tenantId}`
- `POST tenants`
- `DELETE tenants/{tenantId}`
- `POST tenants/{tenantId}/browse`

The API project has only a project reference to this library. The Google Drive SDK package remains contained in this project.
