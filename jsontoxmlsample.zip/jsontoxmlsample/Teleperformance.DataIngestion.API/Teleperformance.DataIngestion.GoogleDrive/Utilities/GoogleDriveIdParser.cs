using System.Text.RegularExpressions;
using Teleperformance.DataIngestion.GoogleDrive.Constants;

namespace Teleperformance.DataIngestion.GoogleDrive.Utilities;

public static partial class GoogleDriveIdParser
{
    public static string Parse(string urlOrId)
    {
        if (string.IsNullOrWhiteSpace(urlOrId)) throw new ArgumentException(GoogleDriveConstants.WorkspaceReferenceRequired, nameof(urlOrId));

        var value = urlOrId.Trim();
        if (DriveIdRegex().IsMatch(value)) return value;

        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri) ||
            !uri.Host.EndsWith("drive.google.com", StringComparison.OrdinalIgnoreCase))
        {
            throw new ArgumentException(GoogleDriveConstants.InvalidWorkspaceReference, nameof(urlOrId));
        }

        var folderMatch = FolderUrlRegex().Match(uri.AbsolutePath);
        if (folderMatch.Success) return folderMatch.Groups[1].Value;

        var fileMatch = FileUrlRegex().Match(uri.AbsolutePath);
        if (fileMatch.Success) return fileMatch.Groups[1].Value;

        var query = ParseQuery(uri.Query);
        if (query.TryGetValue("id", out var id) && DriveIdRegex().IsMatch(id)) return id;

        throw new ArgumentException(GoogleDriveConstants.InvalidWorkspaceReference, nameof(urlOrId));
    }

    private static Dictionary<string, string> ParseQuery(string query)
    {
        return query.TrimStart('?')
            .Split('&', StringSplitOptions.RemoveEmptyEntries)
            .Select(part => part.Split('=', 2))
            .Where(parts => parts.Length == 2)
            .ToDictionary(parts => Uri.UnescapeDataString(parts[0]), parts => Uri.UnescapeDataString(parts[1]), StringComparer.OrdinalIgnoreCase);
    }

    [GeneratedRegex("^[A-Za-z0-9_-]{10,}$", RegexOptions.CultureInvariant)]
    private static partial Regex DriveIdRegex();

    [GeneratedRegex(@"/folders/([A-Za-z0-9_-]{10,})", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex FolderUrlRegex();

    [GeneratedRegex(@"/file/d/([A-Za-z0-9_-]{10,})", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex FileUrlRegex();
}
