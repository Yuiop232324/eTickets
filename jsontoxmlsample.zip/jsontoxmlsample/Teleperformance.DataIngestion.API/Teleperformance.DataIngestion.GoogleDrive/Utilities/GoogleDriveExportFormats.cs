namespace Teleperformance.DataIngestion.GoogleDrive.Utilities;

public sealed record GoogleDriveExportFormat(string ContentType, string Extension);

public static class GoogleDriveExportFormats
{
    private static readonly IReadOnlyDictionary<string, GoogleDriveExportFormat> Formats =
        new Dictionary<string, GoogleDriveExportFormat>(StringComparer.OrdinalIgnoreCase)
        {
            ["application/vnd.google-apps.document"] = new("application/vnd.openxmlformats-officedocument.wordprocessingml.document", ".docx"),
            ["application/vnd.google-apps.spreadsheet"] = new("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx"),
            ["application/vnd.google-apps.presentation"] = new("application/vnd.openxmlformats-officedocument.presentationml.presentation", ".pptx"),
            ["application/vnd.google-apps.drawing"] = new("application/pdf", ".pdf"),
            ["application/vnd.google-apps.script"] = new("application/vnd.google-apps.script+json", ".json")
        };

    public static bool TryGet(string mimeType, out GoogleDriveExportFormat format) =>
        Formats.TryGetValue(mimeType, out format!);

    public static string ResolveOutputFileName(string? fileName, string? mimeType)
    {
        var name = fileName?.Trim() ?? string.Empty;
        if (string.IsNullOrWhiteSpace(mimeType) || !TryGet(mimeType, out var format))
        {
            return name;
        }

        return Path.ChangeExtension(name, format.Extension);
    }

    public static string AppendUtcTimestamp(string? fileName, DateTime utcTimestamp)
    {
        var name = Path.GetFileName(fileName?.Trim() ?? string.Empty);
        if (string.IsNullOrWhiteSpace(name)) name = "file";

        var extension = Path.GetExtension(name);
        var baseName = Path.GetFileNameWithoutExtension(name);
        return $"{baseName}_{utcTimestamp:yyyyMMdd_HHmmss}{extension}";
    }
}
