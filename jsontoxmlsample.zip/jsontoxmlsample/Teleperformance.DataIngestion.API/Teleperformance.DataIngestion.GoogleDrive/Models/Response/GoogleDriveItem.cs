namespace Teleperformance.DataIngestion.GoogleDrive.Models.Response;

public sealed class GoogleDriveItem
{
    public string Id { get; init; } = string.Empty;
    public string Name { get; init; } = string.Empty;
    public string DownloadName { get; init; } = string.Empty;
    public string MimeType { get; init; } = string.Empty;
    public long? Size { get; init; }
    public DateTimeOffset? ModifiedTime { get; init; }
    public string? WebViewLink { get; init; }
    public IReadOnlyList<string> ParentIds { get; init; } = [];
    public bool IsFolder { get; init; }
    public bool IsShortcut { get; init; }
    public bool IsTrashed { get; init; }
}
