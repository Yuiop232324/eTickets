namespace Teleperformance.DataIngestion.GoogleDrive.Models.Response;

public sealed class GoogleDriveDownload : IAsyncDisposable
{
    public required Stream Content { get; init; }
    public string FileName { get; init; } = string.Empty;
    public string ContentType { get; init; } = "application/octet-stream";
    public long? ContentLength { get; init; }

    public ValueTask DisposeAsync() => Content.DisposeAsync();
}
