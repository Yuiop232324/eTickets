using Teleperformance.DataIngestion.GoogleDrive.Constants;

namespace Teleperformance.DataIngestion.GoogleDrive.Models.Response;

public sealed class ApiResponse
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public object? Data { get; set; }

    public static ApiResponse Ok(object? data, string message = GoogleDriveConstants.SuccessMessage) =>
        new() { Success = true, Message = message, Data = data };

    public static ApiResponse Fail(string message, object? data = null) =>
        new() { Success = false, Message = message, Data = data };
}
