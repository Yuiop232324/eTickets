namespace Teleperformance.DataIngestion.GoogleDrive.Models.Response;

public sealed class GoogleDriveTenant
{
    public int PageOrdinal { get; set; }
    public Guid TenantId { get; set; }
    public string OwnerKey { get; set; } = "system";
    public string DisplayName { get; set; } = string.Empty;
    public string Owner { get; set; } = string.Empty;
    public string? OwnerUpn { get; set; }
    public string? CoOwner { get; set; }
    public string? CoOwnerUpn { get; set; }
    public string? Notes { get; set; }
    public int? RegionIdent { get; set; }
    public string? RegionName { get; set; }
    public string? SubRegionCode { get; set; }
    public string? SubRegionName { get; set; }
    public int? ClientIdent { get; set; }
    public string? ClientName { get; set; }
    public Guid? SecurityGroupId { get; set; }
    public string? SecurityGroupName { get; set; }
    public List<GoogleDriveTenantSecurityGroup> SecurityGroups { get; set; } = [];
    public bool IsActive { get; set; }
    public bool IsDraft { get; set; }
    public DateTime CreatedOn { get; set; }
    public DateTime? ModifiedOn { get; set; }
    public int FolderCount { get; set; }
    public List<GoogleDriveTenantFolder> Folders { get; set; } = [];
}

public sealed class GoogleDriveTenantSecurityGroup
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
}

public sealed class GoogleDriveTenantFolder
{
    public Guid TenantFolderId { get; set; }
    public Guid TenantId { get; set; }
    public string FolderId { get; set; } = string.Empty;
    public string FolderName { get; set; } = string.Empty;
    public string? FolderWebViewLink { get; set; }
    public string? DriveId { get; set; }
    public bool PermissionConfirmed { get; set; }
    public DateTime? PermissionConfirmedOn { get; set; }
    public int SortOrder { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedOn { get; set; }
    public DateTime? ModifiedOn { get; set; }
}

public sealed class GoogleDriveConnectorInfo
{
    public string ServiceAccountEmail { get; init; } = string.Empty;
    public string ConnectorMode { get; init; } = "Internal";
    public string RequiredPermission { get; init; } = "Viewer";
    public string PermissionGuidance { get; init; } = string.Empty;
}

