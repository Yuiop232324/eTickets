namespace Teleperformance.DataIngestion.GoogleDrive.Models.Response;

public sealed class WorkspaceConnectivityResult
{
    public bool IsConnected { get; init; }
    public string FolderId { get; init; } = string.Empty;
    public string FolderName { get; init; } = string.Empty;
    public string? WebViewLink { get; init; }
    public string? DriveId { get; init; }
    public string Message { get; init; } = string.Empty;
}
