namespace Teleperformance.DataIngestion.GoogleDrive.Models.Response;

public sealed class GoogleDriveOperationException : Exception
{
    public int StatusCode { get; }

    public GoogleDriveOperationException(string message, int statusCode, Exception? innerException = null)
        : base(message, innerException)
    {
        StatusCode = statusCode;
    }
}
