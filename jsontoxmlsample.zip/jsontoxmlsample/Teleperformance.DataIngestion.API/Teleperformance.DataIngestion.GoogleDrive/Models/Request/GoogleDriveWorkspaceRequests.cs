using Teleperformance.DataIngestion.GoogleDrive.Constants;

namespace Teleperformance.DataIngestion.GoogleDrive.Models.Request;

public sealed class ValidateGoogleDriveWorkspaceRequest
{
    public string WorkspaceUrlOrId { get; set; } = string.Empty;
}

public sealed class BrowseGoogleDriveWorkspaceRequest
{
    public string WorkspaceUrlOrId { get; set; } = string.Empty;
    public string? FolderId { get; set; }
}

public sealed class CreateGoogleDriveFolderRequest
{
    public string WorkspaceUrlOrId { get; set; } = string.Empty;
    public string ParentFolderId { get; set; } = GoogleDriveDefaults.RootFolderId;
    public string FolderName { get; set; } = string.Empty;
}

public sealed class DownloadGoogleDriveFileRequest
{
    public string WorkspaceUrlOrId { get; set; } = string.Empty;
    public string FileId { get; set; } = string.Empty;
}

public sealed class MoveGoogleDriveFileRequest
{
    public string WorkspaceUrlOrId { get; set; } = string.Empty;
    public string FileId { get; set; } = string.Empty;
    public string DestinationFolderId { get; set; } = GoogleDriveDefaults.RootFolderId;
}

public sealed class DeleteGoogleDriveItemRequest
{
    public string WorkspaceUrlOrId { get; set; } = string.Empty;
    public string ItemId { get; set; } = string.Empty;
}
