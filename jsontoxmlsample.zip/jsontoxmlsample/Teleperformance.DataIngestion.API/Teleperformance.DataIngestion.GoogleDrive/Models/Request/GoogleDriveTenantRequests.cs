using Teleperformance.DataIngestion.GoogleDrive.Constants;

namespace Teleperformance.DataIngestion.GoogleDrive.Models.Request;

public sealed class SaveGoogleDriveTenantRequest
{
    public Guid? TenantId { get; set; }
    public string OwnerKey { get; set; } = GoogleDriveDefaults.OwnerKey;
    public string DisplayName { get; set; } = string.Empty;
    public string Owner { get; set; } = string.Empty;
    public string? OwnerUpn { get; set; }
    public string? CoOwner { get; set; }
    public string? CoOwnerUpn { get; set; }
    public string? Notes { get; set; }
    public int? RegionIdent { get; set; }
    public string? RegionName { get; set; }
    public string? SubRegionCode { get; set; }
    public string? SubRegionName { get; set; }
    public int? ClientIdent { get; set; }
    public string? ClientName { get; set; }
    public Guid? SecurityGroupId { get; set; }
    public string? SecurityGroupName { get; set; }
    public List<GoogleDriveTenantSecurityGroupRequest> SecurityGroups { get; set; } = [];
    public bool IsActive { get; set; } = true;
    public bool IsDraft { get; set; }
    public List<SaveGoogleDriveTenantFolderRequest> Folders { get; set; } = [];
}

public sealed class GoogleDriveTenantSecurityGroupRequest
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
}

public sealed class SaveGoogleDriveTenantFolderRequest
{
    public string? FolderUrlOrId { get; set; }
    public bool PermissionConfirmed { get; set; }
}

public sealed class BrowseGoogleDriveTenantRequest
{
    public Guid TenantFolderId { get; set; }
    public string? FolderId { get; set; }
}

