namespace Teleperformance.DataIngestion.GoogleDrive.Constants;

public static class GoogleDriveConstants
{
    public const string FolderMimeType = "application/vnd.google-apps.folder";
    public const string ShortcutMimeType = "application/vnd.google-apps.shortcut";
    public const string GoogleMimeTypePrefix = "application/vnd.google-apps.";
    public const string DefaultApplicationName = "TPDI Google Drive Workspace UAT";
    public const string DefaultServiceAccountScope = "https://www.googleapis.com/auth/drive";

    public const string WorkspaceReferenceRequired = "A Google Drive workspace folder URL or folder ID is required.";
    public const string InvalidWorkspaceReference = "The supplied value is not a valid Google Drive folder URL or ID.";
    public const string WorkspaceFolderNotFound = "The configured Google Drive workspace folder could not be accessed.";
    public const string WorkspaceMustBeFolder = "The configured Google Drive workspace reference must resolve to a folder.";
    public const string ItemOutsideWorkspace = "Item '{0}' is outside the registered Google Drive workspace.";
    public const string TargetMustBeFolder = "Target item '{0}' must be a folder.";
    public const string FolderCannotBeDownloaded = "Google Drive folders cannot be downloaded as files.";
    public const string UnsupportedGoogleFileType = "Google Workspace file type '{0}' does not have a configured export format.";
    public const string UploadFailed = "Google Drive did not complete the upload.";
    public const string DownloadFailed = "Google Drive did not complete the download.";
    public const string ConfigurationMissing = "Required Google Drive service-account configuration is missing: {0}.";
    public const string WorkspaceAccessVerified = "Google Drive workspace access verified.";
    public const string FolderNameRequired = "Folder name is required.";
    public const string FileNameRequired = "File name is required.";
    public const string NewFileNameRequired = "The new file name is required.";
    public const string WorkspaceRootCannotBeTrashed = "The registered workspace root cannot be moved to trash.";
    public const string TenantNotFound = "The Google Drive tenant was not found.";
    public const string TenantRequired = "A Google Drive tenant is required.";
    public const string TenantCreated = "Google Drive tenant created.";
    public const string TenantUpdated = "Google Drive tenant updated.";
    public const string TenantDeactivated = "Google Drive tenant deactivated.";
    public const string TenantFolderRequired = "An approved tenant folder is required.";
    public const string NonEmptyFileRequired = "A non-empty file is required.";
    public const string RequiredValue = "{0} is required.";
    public const string RegionRequired = "A Region selection is required.";
    public const string ApprovedFolderRequired = "Add at least one approved Google Drive folder.";
    public const string DuplicateFolder = "The folder '{0}' was added more than once.";
    public const string TenantNotReady = "The Google Drive tenant is not active and ready for browsing.";
    public const string ApprovedFolderNotFound = "The approved Google Drive folder was not found for this tenant.";
    public const string DatabaseConfigurationMissing = "Google Drive tenant database configuration is missing. Expected Key Vault secret: {0}.";
    public const string SuccessMessage = "Success";
    public const string ConnectorPermissionGuidance = "Share each approved folder with the connector service account. Viewer is sufficient for registration and browsing; use Editor only when file-management actions are intentionally required.";
}

public static class GoogleDriveDefaults
{
    public const string OwnerKey = "system";
    public const string ConnectorMode = "Internal";
    public const string RequiredPermission = "Viewer";
    public const string RootFolderId = "root";
    public const string AllCode = "ALL";
    public const string AllLabel = "All";
    public const string BinaryContentType = "application/octet-stream";
}

public static class GoogleDriveHttpConstants
{
    public const string WorkspaceReferenceField = "workspaceUrlOrId";
    public const string ParentFolderIdField = "parentFolderId";
    public const string FileField = "file";
}

public static class GoogleDriveEnvironmentVariables
{
    public const string ProjectId = "googledriveserviceaccountprojectid";
    public const string ClientEmail = "googledriveserviceaccountemail";
    public const string ClientId = "googledriveserviceaccountclientid";
    public const string PrivateKey = "googledriveserviceaccountprivatekey";
    public const string TokenUri = "googledriveserviceaccounttokenuri";
    public const string ServiceAccountScope = "googledriveserviceaccountscope";
}
