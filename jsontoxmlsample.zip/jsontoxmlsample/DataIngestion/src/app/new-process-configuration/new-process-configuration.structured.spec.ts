import { NEVER } from 'rxjs';
import { DataSourceType } from '../shared/enum';
import { FilePreviewComponent } from './file-preview/file-preview.component';
import { NewProcessConfigurationComponent } from './new-process-configuration.component';

describe('JSON/XML process node settings', () => {
  it('does not clear an active validation toast during a tab redirect', () => {
    const component: any = Object.create(NewProcessConfigurationComponent.prototype);
    component.isEditConfigInitializing = false;
    component.sharePointSourceLoading = false;
    component.googleDriveSourceLoading = false;
    component.activeTab = 'client-tab';
    component.toastr = jasmine.createSpyObj('toastr', ['clear', 'info', 'error']);
    component.modifySettingsClose = jasmine.createSpy('modifySettingsClose');
    component.processConfigurationForm = {
      get: (name: string) => ({ value: ({ RegionId: 1, SubRegionId: 'A', ClientId: 2 } as Record<string, unknown>)[name] }),
    };

    component.onTabChanged('client-tab', false);

    expect(component.toastr.clear).not.toHaveBeenCalled();
  });

  it('loads database names when an edit opens Database Settings directly', () => {
    const component: any = Object.create(NewProcessConfigurationComponent.prototype);
    const controls: Record<string, any> = {
      RegionId: { value: 1, markAsTouched: jasmine.createSpy('markRegionAsTouched') },
      SubRegionId: { value: 2, markAsTouched: jasmine.createSpy('markSubRegionAsTouched') },
      ClientId: { value: 3, markAsTouched: jasmine.createSpy('markClientAsTouched') },
      deltaContainerName: { hasError: () => false, touched: false, dirty: false },
    };
    const fallbackControl = { value: null, touched: false, dirty: false, hasError: () => false };
    component.isEditConfigInitializing = false;
    component.sharePointSourceLoading = false;
    component.googleDriveSourceLoading = false;
    component.activeTab = 'client-tab';
    component.databaseNames = [];
    component.paramsId = 'configuration-id';
    component.configurationProcessType = DataSourceType.Default;
    component.toastr = jasmine.createSpyObj('toastr', ['info', 'error']);
    component.modifySettingsClose = jasmine.createSpy('modifySettingsClose');
    component.isAdditionalSettingsTabValid = jasmine.createSpy('isAdditionalSettingsTabValid').and.returnValue(false);
    component.processConfigurationForm = { get: (name: string) => controls[name] ?? fallbackControl };
    component.configService = {
      getDIDatabaseNames: jasmine.createSpy('getDIDatabaseNames').and.returnValue(NEVER),
    };

    component.onTabChanged('database-settings-tab', false);

    expect(component.configService.getDIDatabaseNames)
      .toHaveBeenCalledOnceWith(1, 2, 3, DataSourceType.Default);
    expect(component.isDatabaseNamesLoading).toBeTrue();
    expect(component.activeTab).toBe('database-settings-tab');
  });

  it('uses four-second toasts only while configuration-first is mounted', () => {
    const component: any = Object.create(NewProcessConfigurationComponent.prototype);
    component.toastr = { toastrConfig: { timeOut: 5000, extendedTimeOut: 1000 } };
    component.keyColumnsSubscription = null;

    component.previousToastTimeOut = component.toastr.toastrConfig.timeOut;
    component.previousToastExtendedTimeOut = component.toastr.toastrConfig.extendedTimeOut;
    component.toastr.toastrConfig.timeOut = 4000;
    component.toastr.toastrConfig.extendedTimeOut = 4000;

    expect(component.toastr.toastrConfig.timeOut).toBe(4000);
    expect(component.toastr.toastrConfig.extendedTimeOut).toBe(4000);

    component.ngOnDestroy();
    expect(component.toastr.toastrConfig.timeOut).toBe(5000);
    expect(component.toastr.toastrConfig.extendedTimeOut).toBe(1000);
  });

  it('derives the format from the saved node without a sample file', () => {
    const component = Object.create(NewProcessConfigurationComponent.prototype) as NewProcessConfigurationComponent;
    component.tabName = 'xml:/root/items/item';
    component.structuredParentSelection = {
      parentPath: 'xml:/root/items', sourceField: '@name', outputColumn: 'parent_name'
    };
    component.fileName = '';
    expect(component.structuredFormat).toBe('xml');
    expect(component.structuredNodePath).toBe('item');
    expect(component.structuredParentNodeName).toBe('name');
    expect(component.tabName).toBe('xml:/root/items/item');
  });

  it('does not treat an Excel sheet name as a structured format', () => {
    const component = Object.create(NewProcessConfigurationComponent.prototype) as NewProcessConfigurationComponent;
    component.tabName = 'Customers';
    component.fileName = 'sample.xlsx';
    expect(component.structuredFormat).toBe('');
  });

  it('blocks a selected node that exceeds the persistence limit', () => {
    const component: any = Object.create(NewProcessConfigurationComponent.prototype);
    component.tabName = `json:$${'a'.repeat(100)}`;
    component.toastr = jasmine.createSpyObj('toastr', ['error']);
    component.onSubmit({});
    expect(component.toastr.error).toHaveBeenCalledWith('The selected JSON/XML node cannot exceed 100 characters.');
  });

  it('persists only the extension matching the selected structured format', () => {
    const component: any = Object.create(NewProcessConfigurationComponent.prototype);
    component.tabName = 'json:$.items';
    component.fileName = 'sample.json';
    component.fileNameExtensions = [
      { id: 1, fileExtension: 'csv' },
      { id: 8, fileExtension: 'json' },
      { id: 9, fileExtension: 'xml' },
    ];

    expect(component.resolvedLandingLayerFileExtensions([1, 9])).toEqual([8]);
  });
});

describe('Structured sample detection', () => {
  it('uses the newly selected sample extension and discovers its nodes afresh', () => {
    const component: any = Object.create(FilePreviewComponent.prototype);
    component.filePreviewValues = {
      structuredFormat: 'json',
      structuredSection: 'json:$.items',
      structuredParentSelection: { parentPath: 'json:$', sourceField: 'id', outputColumn: 'parent_id' },
    };
    component.filePreviewForm = { get: () => ({ setValue: jasmine.createSpy('setValue') }) };
    component.disableDelimiter = { emit: jasmine.createSpy('emit') };
    component.previewFile = jasmine.createSpy('previewFile');
    component.toastr = jasmine.createSpyObj('toastr', ['error']);
    expect(component.useSampleFile(new File(['<root/>'], 'sample.xml'))).toBeTrue();
    expect(component.filePreviewValues.structuredFormat).toBe('xml');
    expect(component.filePreviewValues.structuredSection).toBeUndefined();
    expect(component.filePreviewValues.structuredParentSelection).toBeNull();
    expect(component.previewFile).toHaveBeenCalled();
  });

  it('opens the full document viewer only for a structured sample and reads all content', async () => {
    const component: any = Object.create(FilePreviewComponent.prototype);
    component.file = new File(['{"id":1}'], 'sample.json');
    component.structuredDocumentViewerOpen = false;
    component.structuredDocumentReadId = 0;

    await component.openStructuredDocumentViewer();
    expect(component.structuredDocumentViewerOpen).toBeTrue();
    expect(component.structuredDocumentContent).toBe('{"id":1}');

    component.closeStructuredDocumentViewer();
    expect(component.structuredDocumentViewerOpen).toBeFalse();
    expect(component.structuredDocumentContent).toBe('');
  });

  it('does not open the full document viewer for a tabular sample', () => {
    const component: any = Object.create(FilePreviewComponent.prototype);
    component.file = new File(['id\n1'], 'sample.csv');
    component.structuredDocumentViewerOpen = false;
    component.openStructuredDocumentViewer();
    expect(component.structuredDocumentViewerOpen).toBeFalse();
  });

  it('removes an ancestor context column when it is unchecked', async () => {
    const component: any = Object.create(FilePreviewComponent.prototype);
    component.structuredPreview = {
      selectedSection: 'json:$.items[].rows',
      ancestorNodes: [{
        path: 'json:$.items',
        selections: [{ parentPath: 'json:$.items', sourceField: 'id', outputColumn: 'parent_id' }],
      }],
    };
    component.previewStructuredFile = jasmine.createSpy('previewStructuredFile').and.resolveTo();

    await component.onStructuredAncestorFieldToggle('json:$.items', 'id', 'parent_id', false);

    expect(component.previewStructuredFile).toHaveBeenCalledOnceWith('json:$.items[].rows', []);
  });
});
