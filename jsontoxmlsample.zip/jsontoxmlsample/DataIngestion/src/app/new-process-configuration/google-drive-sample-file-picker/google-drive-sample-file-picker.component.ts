import { CommonModule } from '@angular/common';
import { Component, EventEmitter, inject, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { googleDriveTenantMatchesHierarchy } from '../../file-first/file-first-google-drive-attach/google-drive-file-first-scope';
import { isStructuredPreviewFileName, SAMPLE_PREVIEW_FORMAT_LABEL, samplePreviewMaxBytes } from '../../shared/structured-files/structured-preview-file';
import { googleDriveEffectiveFileName, isGoogleDriveProcessFile } from '../../workspace-connect/core/google-drive-file-eligibility';
import { GoogleDriveItem, GoogleDriveTenant, GoogleDriveTenantFolder } from '../../workspace-connect/core/google-drive-workspace.types';
import { SharePointTenantHierarchyFilter } from '../../workspace-connect/core/workspace-connect.tenant';
import { GoogleDriveWorkspaceComponent } from '../../workspace-connect/google-drive-workspace/google-drive-workspace.component';
import { GoogleDriveApiService } from '../../workspace-connect/services/google-drive-api.service';

@Component({
  selector: 'app-configuration-first-google-drive-sample-file-picker',
  standalone: true,
  imports: [CommonModule, FormsModule, GoogleDriveWorkspaceComponent],
  templateUrl: './google-drive-sample-file-picker.component.html',
  styleUrl: './google-drive-sample-file-picker.component.css',
})
export class ConfigurationFirstGoogleDriveSampleFilePickerComponent implements OnChanges {
  private readonly api = inject(GoogleDriveApiService);

  @Input() hierarchyFilter: SharePointTenantHierarchyFilter | null = null;
  @Input() tenantFolderId: string | null = null;
  @Output() fileSelected = new EventEmitter<File>();
  @Output() closePicker = new EventEmitter<void>();

  tenants: GoogleDriveTenant[] = [];
  selectedTenantId = '';
  selectedTenantFolderId = '';
  selectedTenant: GoogleDriveTenant | null = null;
  selectedFolder: GoogleDriveTenantFolder | null = null;
  loading = false;
  fileLoading = false;
  error = '';
  private loadGeneration = 0;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['hierarchyFilter'] || changes['tenantFolderId']) void this.loadSources();
  }

  get folders(): GoogleDriveTenantFolder[] {
    return this.selectedTenant?.folders.filter((folder) => folder.isActive && folder.permissionConfirmed) ?? [];
  }

  onTenantChanged(tenantId: string): void {
    this.selectedTenantId = tenantId;
    this.selectedTenantFolderId = '';
    this.selectedTenant = this.tenants.find((tenant) => tenant.tenantId === tenantId) ?? null;
    this.selectedFolder = null;
    this.error = '';
  }

  onFolderChanged(tenantFolderId: string): void {
    this.selectedTenantFolderId = tenantFolderId;
    this.selectedFolder = this.folders.find((folder) => folder.tenantFolderId === tenantFolderId) ?? null;
    this.error = '';
  }

  async useSelectedFile(item: GoogleDriveItem): Promise<void> {
    if (!this.selectedFolder || item.isFolder || this.fileLoading || !this.validateItem(item)) return;

    this.fileLoading = true;
    this.error = '';
    try {
      const blob = await firstValueFrom(this.api.downloadFile(this.selectedFolder.folderId, item.id));
      this.fileSelected.emit(new File([blob], googleDriveEffectiveFileName(item), {
        type: blob.type || item.mimeType || 'application/octet-stream',
      }));
    } catch (error: unknown) {
      console.error('[Google Drive Sample File] Could not fetch selected file', { itemId: item.id, error });
      this.error = 'The selected Google Drive file could not be downloaded. Please try again.';
    } finally {
      this.fileLoading = false;
    }
  }

  private async loadSources(): Promise<void> {
    const generation = ++this.loadGeneration;
    this.tenants = [];
    this.selectedTenantId = '';
    this.selectedTenantFolderId = '';
    this.selectedTenant = null;
    this.selectedFolder = null;
    this.error = '';

    if (!this.hierarchyFilter?.regionIdent) {
      this.error = 'Complete Client Settings before selecting a sample file.';
      return;
    }

    this.loading = true;
    try {
      const securityGroupIds = this.hierarchyFilter.securityGroupIds
        ?? (this.hierarchyFilter.securityGroupId ? [this.hierarchyFilter.securityGroupId] : []);
      const selected = {
        regionIdent: this.hierarchyFilter.regionIdent,
        regionName: '',
        subRegionCode: this.hierarchyFilter.subRegionCode ?? '',
        subRegionName: '',
        clientIdent: this.hierarchyFilter.clientIdent ?? null,
        clientName: '',
        securityGroupId: this.hierarchyFilter.securityGroupId ?? null,
        securityGroupName: '',
        securityGroups: securityGroupIds.map((id) => ({ id, name: id })),
      };
      const tenants = await firstValueFrom(this.api.getTenants(false, this.hierarchyFilter));
      if (generation !== this.loadGeneration) return;
      this.tenants = tenants.filter((tenant) => googleDriveTenantMatchesHierarchy(tenant, selected));

      const tenantFolderId = this.tenantFolderId?.trim();
      if (tenantFolderId) {
        this.selectedTenant = this.tenants.find((tenant) => tenant.folders.some((folder) =>
          folder.tenantFolderId === tenantFolderId && folder.isActive && folder.permissionConfirmed)) ?? null;
        this.selectedFolder = this.selectedTenant?.folders.find((folder) =>
          folder.tenantFolderId === tenantFolderId && folder.isActive && folder.permissionConfirmed) ?? null;
        this.selectedTenantId = this.selectedTenant?.tenantId ?? '';
        this.selectedTenantFolderId = this.selectedFolder?.tenantFolderId ?? '';
      }

      if (!this.tenants.length) this.error = 'No approved Google Drive tenant is available for this hierarchy.';
      else if (tenantFolderId && !this.selectedFolder) this.error = 'The previously selected Google Drive folder is no longer available. Choose another folder.';
    } catch (error: unknown) {
      console.error('[Google Drive Sample File] Could not load selected source', error);
      if (generation === this.loadGeneration) this.error = 'Google Drive source details could not be loaded.';
    } finally {
      if (generation === this.loadGeneration) this.loading = false;
    }
  }

  private validateItem(item: GoogleDriveItem): boolean {
    // #region Structured JSON/XML files
    const fileName = googleDriveEffectiveFileName(item);
    if (!isGoogleDriveProcessFile(item) && !isStructuredPreviewFileName(fileName)) {
      this.error = `Select a ${SAMPLE_PREVIEW_FORMAT_LABEL} file.`;
      return false;
    }
    const maxBytes = samplePreviewMaxBytes(fileName);
    if ((item.size ?? 0) > maxBytes) {
      this.error = `The selected file exceeds the ${maxBytes / 1024 / 1024}MB limit.`;
      return false;
    }
    // #endregion
    return true;
  }
}
