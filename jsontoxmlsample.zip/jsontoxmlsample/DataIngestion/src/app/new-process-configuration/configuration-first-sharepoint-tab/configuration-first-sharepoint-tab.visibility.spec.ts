import { TestBed } from '@angular/core/testing';
import { ToastrService } from 'ngx-toastr';
import { SHAREPOINT_PROCESS_TYPE_ID, SHAREPOINT_SETTINGS_TAB_ID } from '../../workspace-connect/integration/configuration-first.sharepoint';
import { ConfigurationFirstSharepointTabComponent } from './configuration-first-sharepoint-tab.component';

describe('SharePoint configuration panel visibility', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ConfigurationFirstSharepointTabComponent],
      providers: [{ provide: ToastrService, useValue: { error: jasmine.createSpy('error') } }]
    }).overrideComponent(ConfigurationFirstSharepointTabComponent, {
      set: { template: '<input aria-label="Retained workspace state" value="retained">' }
    }).compileComponents();
  });

  for (const nextTab of ['schedular-settings-tab', 'notification-settings-tab']) {
    it(`hides an empty SharePoint panel on ${nextTab} without destroying its state`, () => {
      const fixture = TestBed.createComponent(ConfigurationFirstSharepointTabComponent);
      fixture.componentRef.setInput('processType', SHAREPOINT_PROCESS_TYPE_ID);
      fixture.componentRef.setInput('activeTab', SHAREPOINT_SETTINGS_TAB_ID);
      fixture.detectChanges();
      const host = fixture.nativeElement as HTMLElement;
      const retainedInput = host.querySelector('input')!;
      retainedInput.value = 'Unsubmitted workspace state';
      expect(host.hidden).toBeFalse();
      expect(fixture.componentInstance.selection()).toBeNull();
      expect(fixture.componentInstance.validateSelection(false)).toBeFalse();

      fixture.componentRef.setInput('activeTab', nextTab);
      fixture.detectChanges();
      // Simulate a stale class left by Bootstrap's independent tab handling.
      host.classList.add('active');
      expect(host.hidden).toBeTrue();
      expect(getComputedStyle(host).display).toBe('none');
      expect(fixture.componentInstance.validateSelection(false)).toBeFalse();

      fixture.componentRef.setInput('activeTab', SHAREPOINT_SETTINGS_TAB_ID);
      fixture.detectChanges();
      expect(host.hidden).toBeFalse();
      expect(host.querySelector('input')).toBe(retainedInput);
      expect(retainedInput.value).toBe('Unsubmitted workspace state');
    });
  }

  it('treats a cleared live workspace selection as invalid instead of restoring cached edit data', () => {
    const fixture = TestBed.createComponent(ConfigurationFirstSharepointTabComponent);
    const component: any = fixture.componentInstance;
    component.cachedSelection = {
      sharePointApplicationId: 'saved-app',
      sharePointApplicationSiteId: 'saved-site',
      sharePointLibraryName: 'Documents',
      sharePointFolderPath: '',
    };
    component.sharepointWorkspace = {
      processConfigurationSelection: () => null,
    };

    expect(component.selection()).toBeNull();
    expect(component.validateSelection(true)).toBeFalse();
    expect(TestBed.inject(ToastrService).error).toHaveBeenCalledWith(
      component.m.validateSelection,
      undefined,
      { timeOut: 4000, extendedTimeOut: 4000 },
    );
  });

  it('requires application, site, and library when validating cached edit data', () => {
    const fixture = TestBed.createComponent(ConfigurationFirstSharepointTabComponent);
    const component: any = fixture.componentInstance;
    component.cachedSelection = {
      sharePointApplicationId: 'saved-app',
      sharePointApplicationSiteId: '',
      sharePointLibraryName: 'Documents',
      sharePointFolderPath: '',
    };

    expect(component.validateSelection(false)).toBeFalse();

    component.cachedSelection.sharePointApplicationSiteId = 'saved-site';
    expect(component.validateSelection(false)).toBeTrue();
  });
});
