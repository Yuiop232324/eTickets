import { Component, EventEmitter, inject, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { finalize } from 'rxjs';
import { googleDriveTenantMatchesHierarchy } from '../../file-first/file-first-google-drive-attach/google-drive-file-first-scope';
import { GoogleDriveTenant, GoogleDriveTenantFolder } from '../../workspace-connect/core/google-drive-workspace.types';
import { WC_IMAGES } from '../../workspace-connect/core/workspace-connect.assets';
import { SharePointTenantHierarchyFilter } from '../../workspace-connect/core/workspace-connect.tenant';
import { GoogleDriveWorkspaceComponent } from '../../workspace-connect/google-drive-workspace/google-drive-workspace.component';
import {
  GOOGLE_DRIVE_SETTINGS_TAB_ID,
  GOOGLE_DRIVE_SETTINGS_TAB_PANE_ID,
  isGoogleDriveProcessType,
  ProcessConfigGoogleDriveSelection,
} from '../../workspace-connect/integration/configuration-first.google-drive';
import { GoogleDriveApiService } from '../../workspace-connect/services/google-drive-api.service';

@Component({
  selector: 'app-configuration-first-google-drive-tab',
  templateUrl: './configuration-first-google-drive-tab.component.html',
  styleUrls: [
    '../../workspace-connect/workspace-connect-shell.css',
    './configuration-first-google-drive-tab.component.css',
  ],
  standalone: false,
  host: {
    class: 'tab-pane fade show',
    '[class.active]': 'isActive',
    '[attr.id]': 'paneId',
    role: 'tabpanel',
    '[attr.aria-labelledby]': 'tabId',
    tabindex: '0',
  },
})
export class ConfigurationFirstGoogleDriveTabComponent implements OnChanges {
  private readonly api = inject(GoogleDriveApiService);
  private readonly toastr = inject(ToastrService);

  readonly tabId = GOOGLE_DRIVE_SETTINGS_TAB_ID;
  readonly paneId = GOOGLE_DRIVE_SETTINGS_TAB_PANE_ID;
  readonly driveLogo = WC_IMAGES.googleDrive;

  @ViewChild('googleDriveWorkspace') googleDriveWorkspace?: GoogleDriveWorkspaceComponent;

  @Input() activeTab = '';
  @Input() processType: string | number = '';
  @Input() allowAllFileTypes = false;
  @Input() hierarchyFilter: SharePointTenantHierarchyFilter | null = null;
  @Input() initialTenantFolderId: string | null = null;
  @Input() initialsLoading = false;
  @Output() selectionChange = new EventEmitter<ProcessConfigGoogleDriveSelection | null>();

  loading = false;
  tenants: GoogleDriveTenant[] = [];
  selectedTenantId = '';
  selectedTenantFolderId = '';
  private loadGeneration = 0;

  get isActive(): boolean { return this.activeTab === this.tabId; }
  get shouldRender(): boolean { return isGoogleDriveProcessType(this.processType); }

  get selectedTenant(): GoogleDriveTenant | null {
    return this.tenants.find((tenant) => tenant.tenantId === this.selectedTenantId) ?? null;
  }

  get folders(): GoogleDriveTenantFolder[] {
    return this.selectedTenant?.folders.filter((folder) => folder.isActive && folder.permissionConfirmed) ?? [];
  }

  get selectedFolder(): GoogleDriveTenantFolder | null {
    return this.folders.find((folder) => folder.tenantFolderId === this.selectedTenantFolderId) ?? null;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (!this.shouldRender) return;
    if (changes['hierarchyFilter'] || changes['processType'] || changes['initialTenantFolderId']) {
      this.loadTenants();
    }
  }

  selection(): ProcessConfigGoogleDriveSelection | null {
    return this.selectedTenantFolderId
      ? { googleDriveTenantFolderId: this.selectedTenantFolderId }
      : null;
  }

  validateSelection(showToast = true): boolean {
    const valid = !!this.selectedFolder;
    if (!valid && showToast) this.toastr.error('Select an approved Google Drive tenant folder.');
    return valid;
  }

  onTenantChanged(tenantId: string): void {
    this.selectedTenantId = tenantId;
    this.selectedTenantFolderId = '';
    this.googleDriveWorkspace?.disconnect();
    this.emitSelection();
  }

  onFolderChanged(tenantFolderId: string): void {
    this.selectedTenantFolderId = tenantFolderId;
    this.emitSelection();
  }

  private loadTenants(): void {
    const generation = ++this.loadGeneration;
    if (!this.hierarchyFilter?.regionIdent) {
      this.resetSelection();
      return;
    }

    this.loading = true;
    const securityGroupIds = this.hierarchyFilter.securityGroupIds
      ?? (this.hierarchyFilter.securityGroupId ? [this.hierarchyFilter.securityGroupId] : []);
    const selected = {
      regionIdent: this.hierarchyFilter.regionIdent,
      regionName: '',
      subRegionCode: this.hierarchyFilter.subRegionCode ?? '',
      subRegionName: '',
      clientIdent: this.hierarchyFilter.clientIdent ?? null,
      clientName: '',
      securityGroupId: this.hierarchyFilter.securityGroupId ?? null,
      securityGroupName: '',
      securityGroups: securityGroupIds.map((id) => ({ id, name: id })),
    };

    this.api.getTenants(false, this.hierarchyFilter).pipe(finalize(() => {
      if (generation === this.loadGeneration) this.loading = false;
    })).subscribe({
      next: (tenants) => {
        if (generation !== this.loadGeneration) return;
        this.tenants = tenants.filter((tenant) => googleDriveTenantMatchesHierarchy(tenant, selected));
        this.restoreOrChooseSelection();
      },
      error: () => {
        if (generation !== this.loadGeneration) return;
        this.resetSelection();
        this.toastr.error('Google Drive tenants could not be loaded.');
      },
    });
  }

  private restoreOrChooseSelection(): void {
    const currentTenantId = this.selectedTenantId.trim();
    const currentFolderId = this.selectedTenantFolderId.trim();
    if (currentTenantId && currentFolderId) {
      const currentTenant = this.tenants.find((tenant) => tenant.tenantId === currentTenantId) ?? null;
      const currentFolder = currentTenant?.folders.find((folder) =>
        folder.tenantFolderId === currentFolderId && folder.isActive && folder.permissionConfirmed) ?? null;
      if (currentTenant && currentFolder) {
        this.selectedTenantId = currentTenant.tenantId;
        this.selectedTenantFolderId = currentFolder.tenantFolderId;
        this.emitSelection();
        return;
      }
    }

    const initialFolderId = this.initialTenantFolderId?.trim();
    const initialTenant = initialFolderId
      ? this.tenants.find((tenant) => tenant.folders.some((folder) =>
        folder.tenantFolderId === initialFolderId && folder.isActive && folder.permissionConfirmed))
      : null;

    if (initialTenant && initialFolderId) {
      this.selectedTenantId = initialTenant.tenantId;
      this.selectedTenantFolderId = initialFolderId;
      this.emitSelection();
      return;
    }

    this.selectedTenantId = '';
    this.selectedTenantFolderId = '';

    this.emitSelection();
  }

  private emitSelection(): void {
    this.selectionChange.emit(this.selection());
  }

  private resetSelection(): void {
    this.tenants = [];
    this.selectedTenantId = '';
    this.selectedTenantFolderId = '';
    this.googleDriveWorkspace?.disconnect();
    this.emitSelection();
  }
}
