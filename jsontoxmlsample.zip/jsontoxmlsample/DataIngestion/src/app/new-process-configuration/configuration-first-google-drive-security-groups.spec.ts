import { SimpleChange } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ToastrService } from 'ngx-toastr';
import { of } from 'rxjs';
import { SharePointTenantHierarchyFilter } from '../workspace-connect/core/workspace-connect.tenant';
import { GoogleDriveApiService } from '../workspace-connect/services/google-drive-api.service';
import { ConfigurationFirstGoogleDriveSampleFilePickerComponent } from './google-drive-sample-file-picker/google-drive-sample-file-picker.component';
import { ConfigurationFirstGoogleDriveTabComponent } from './configuration-first-google-drive-tab/configuration-first-google-drive-tab.component';

describe('Configuration First Google Drive security groups', () => {
  const filter: SharePointTenantHierarchyFilter = {
    regionIdent: 1,
    subRegionCode: 'AUS',
    clientIdent: 101,
    securityGroupId: 'group-one',
    securityGroupIds: ['group-one', 'group-two'],
  };

  let api: jasmine.SpyObj<GoogleDriveApiService>;

  beforeEach(() => {
    api = jasmine.createSpyObj<GoogleDriveApiService>('GoogleDriveApiService', ['getTenants']);
    api.getTenants.and.returnValue(of([]));
    TestBed.configureTestingModule({
      providers: [
        { provide: GoogleDriveApiService, useValue: api },
        { provide: ToastrService, useValue: { error: jasmine.createSpy('error') } },
      ],
    });
  });

  it('passes all selected groups when loading the Google Drive storage tab', () => {
    const component = TestBed.runInInjectionContext(() => new ConfigurationFirstGoogleDriveTabComponent());
    component.processType = 7;
    component.hierarchyFilter = filter;

    component.ngOnChanges({ hierarchyFilter: new SimpleChange(null, filter, true) });

    expect(api.getTenants).toHaveBeenCalledWith(false, filter);
  });

  it('passes all selected groups when loading the Google Drive sample picker', async () => {
    const component = TestBed.runInInjectionContext(() => new ConfigurationFirstGoogleDriveSampleFilePickerComponent());
    component.hierarchyFilter = filter;

    component.ngOnChanges({ hierarchyFilter: new SimpleChange(null, filter, true) });
    await Promise.resolve();

    expect(api.getTenants).toHaveBeenCalledWith(false, filter);
  });
});
