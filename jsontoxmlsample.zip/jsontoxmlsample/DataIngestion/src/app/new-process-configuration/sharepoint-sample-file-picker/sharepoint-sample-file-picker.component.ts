import { Component, EventEmitter, inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { BusyService } from '../../core/services/busy.service';
import { isSamplePreviewFileName, SAMPLE_PREVIEW_FORMAT_LABEL, samplePreviewMaxBytes } from '../../shared/structured-files/structured-preview-file';
import { SharePointTenantHierarchyFilter } from '../../workspace-connect/core/workspace-connect.tenant';
import { SharePointItemDto } from '../../workspace-connect/core/workspace-connect.types';
import { SharePointApiService } from '../../workspace-connect/services/sharepoint-api.service';
import { SharePointUserApiService, SharePointUserAuthService } from '../../workspace-connect/services/sharepoint-user.service';
import { SharepointWorkspaceComponent } from '../../workspace-connect/sharepoint-workspace/sharepoint-workspace.component';

@Component({
  selector: 'app-configuration-first-sharepoint-sample-file-picker',
  standalone: true,
  imports: [SharepointWorkspaceComponent],
  templateUrl: './sharepoint-sample-file-picker.component.html',
  styleUrls: [
    '../../workspace-connect/workspace-connect-shell.css',
    './sharepoint-sample-file-picker.component.css',
    '../../workspace-connect/workspace-connect.styles.css',
  ],
})
export class ConfigurationFirstSharepointSampleFilePickerComponent implements OnInit {
  private readonly api = inject(SharePointApiService);
  private readonly userApi = inject(SharePointUserApiService);
  private readonly auth = inject(SharePointUserAuthService);
  private readonly busyService = inject(BusyService);

  @Input() hierarchyFilter: SharePointTenantHierarchyFilter | null = null;
  @Output() fileSelected = new EventEmitter<File>();
  @Output() closePicker = new EventEmitter<void>();

  @ViewChild(SharepointWorkspaceComponent)
  private workspace!: SharepointWorkspaceComponent;

  fileLoading = false;
  error = '';

  async ngOnInit(): Promise<void> {
    if (this.auth.isConfigured) await this.auth.initialize();
  }

  get accessReady(): boolean {
    return !!this.hierarchyFilter?.regionIdent;
  }

  async useSelectedFile(): Promise<void> {
    const item = this.workspace?.selectedItem;
    if (!item || item.isFolder || this.fileLoading) return;
    if (!this.validateItem(item)) return;

    this.workspace.closeViewer();
    this.fileLoading = true;
    this.error = '';
    this.busyService.busy();
    const filePath = item.path ?? item.name;

    try {
      const blob = await this.fetchSelectedFileBlob(filePath);
      this.fileSelected.emit(new File([blob], item.name, {
        type: blob.type || 'application/octet-stream',
      }));
    } catch (error: unknown) {
      console.error('[SharePoint Sample File] Could not fetch selected file', { filePath, error });
      this.error = 'The selected SharePoint file could not be downloaded. Please try again.';
    } finally {
      this.fileLoading = false;
      this.busyService.idle();
    }
  }

  private validateItem(item: SharePointItemDto): boolean {
    // #region Structured JSON/XML files
    if (!isSamplePreviewFileName(item.name)) {
      this.error = `Select a ${SAMPLE_PREVIEW_FORMAT_LABEL} file.`;
      return false;
    }
    const maxBytes = samplePreviewMaxBytes(item.name);
    if (item.size > maxBytes) {
      this.error = `The selected file exceeds the ${maxBytes / 1024 / 1024}MB limit.`;
      return false;
    }
    // #endregion
    return true;
  }

  private async fetchSelectedFileBlob(filePath: string): Promise<Blob> {
    const fetchOnce = () => this.workspace.isModeUser
      ? firstValueFrom(this.userApi.fetchFileBlob(this.workspace.selectedUserLibraryDriveId(), filePath))
      : firstValueFrom(this.api.fetchFileBlob(this.workspace.workspaceConnection, filePath));

    try {
      return await fetchOnce();
    } catch {
      return await fetchOnce();
    }
  }
}
