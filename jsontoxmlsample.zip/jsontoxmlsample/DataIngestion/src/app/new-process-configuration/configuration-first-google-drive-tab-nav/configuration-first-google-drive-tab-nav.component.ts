import { Component, EventEmitter, Input, Output } from '@angular/core';
import {
  GOOGLE_DRIVE_PROCESS_TYPE_ID,
  GOOGLE_DRIVE_SETTINGS_TAB_ID,
  GOOGLE_DRIVE_SETTINGS_TAB_PANE_ID,
} from '../../workspace-connect/integration/configuration-first.google-drive';

@Component({
  selector: 'app-configuration-first-google-drive-tab-nav',
  templateUrl: './configuration-first-google-drive-tab-nav.component.html',
  styleUrl: './configuration-first-google-drive-tab-nav.component.css',
  standalone: false,
})
export class ConfigurationFirstGoogleDriveTabNavComponent {
  readonly processTypeId = GOOGLE_DRIVE_PROCESS_TYPE_ID;
  readonly tabId = GOOGLE_DRIVE_SETTINGS_TAB_ID;
  readonly paneId = GOOGLE_DRIVE_SETTINGS_TAB_PANE_ID;
  @Input() processType: string | number = '';
  @Input() activeTab = '';
  @Output() tabChanged = new EventEmitter<boolean>();
}
