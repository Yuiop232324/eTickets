import {
    isTabularPreviewFileName,
    tabularPreviewFileExtension,
} from './tabular-preview-file';

describe('tabular preview file eligibility', () => {
    it('accepts only the tabular formats supported by the shared preview parser', () => {
        for (const extension of ['csv', 'txt', 'xls', 'xlsx', 'xlsb']) {
            expect(isTabularPreviewFileName(`sample.${extension}`)).withContext(extension).toBeTrue();
        }
    });

    it('normalizes upper-case extensions for SharePoint and device files', () => {
        expect(tabularPreviewFileExtension('Quarterly Report.XLSX')).toBe('xlsx');
        expect(tabularPreviewFileExtension('Extract.CSV')).toBe('csv');
    });

    it('does not broaden preview support to other spreadsheet or document formats', () => {
        for (const fileName of ['macro.xlsm', 'sheet.ods', 'document.docx', 'image.png']) {
            expect(isTabularPreviewFileName(fileName)).withContext(fileName).toBeFalse();
        }
    });
});
