export const TABULAR_PREVIEW_EXTENSIONS = ['csv', 'txt', 'xls', 'xlsx', 'xlsb'] as const;
export const TABULAR_PREVIEW_FORMAT_LABEL = 'CSV, TXT, XLS, XLSX, or XLSB';
export const TABULAR_PREVIEW_MAX_BYTES = 10 * 1024 * 1024;

const TABULAR_PREVIEW_EXTENSION_SET = new Set<string>(TABULAR_PREVIEW_EXTENSIONS);

export type TabularPreviewExtension = typeof TABULAR_PREVIEW_EXTENSIONS[number];

export function tabularPreviewFileExtension(fileName: string): TabularPreviewExtension | null {
    const trimmed = fileName.trim();
    const separator = trimmed.lastIndexOf('.');
    if (separator < 0 || separator === trimmed.length - 1) return null;

    const extension = trimmed.slice(separator + 1).toLowerCase();
    return TABULAR_PREVIEW_EXTENSION_SET.has(extension)
        ? extension as TabularPreviewExtension
        : null;
}

export function isTabularPreviewFileName(fileName: string): boolean {
    return tabularPreviewFileExtension(fileName) !== null;
}
