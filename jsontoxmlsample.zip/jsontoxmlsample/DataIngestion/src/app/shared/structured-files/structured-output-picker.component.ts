import { Component, ElementRef, EventEmitter, HostListener, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';
import {
  StructuredFilePreview,
  StructuredFileSection,
  structuredNodeDisplayLabel,
  structuredNodeHierarchyLabel,
} from './structured-file.models';

interface StructuredOutputOption extends StructuredFileSection {
  display: string;
}

interface StructuredHierarchyNode extends StructuredOutputOption {
  children: StructuredHierarchyNode[];
}

@Component({
  selector: 'app-structured-output-picker',
  templateUrl: './structured-output-picker.component.html',
  styleUrl: './structured-output-picker.component.css',
  standalone: false,
})
export class StructuredOutputPickerComponent implements OnChanges {
  @Input() preview: StructuredFilePreview | null = null;
  @Input() busy = false;
  @Output() tableChange = new EventEmitter<string>();

  structureOpen = false;
  dropdownOpen = false;
  searchTerm = '';
  readonly expandedPaths = new Set<string>();
  @ViewChild('tableSearch') tableSearch?: ElementRef<HTMLInputElement>;

  readonly tableLabel = structuredNodeDisplayLabel;
  readonly tablePath = structuredNodeHierarchyLabel;

  get options(): StructuredOutputOption[] {
    return (this.preview?.sections ?? []).map(section => ({
      ...section,
      display: `${this.tableLabel(section.path)} (${section.recordCount})`,
    }));
  }

  get filteredOptions(): StructuredOutputOption[] {
    const query = this.searchTerm.trim().toLowerCase();
    if (!query) return this.options;
    return this.options.filter(option => option.display.toLowerCase().includes(query)
      || option.path.toLowerCase().includes(query));
  }

  get selectedOption(): StructuredOutputOption | undefined {
    return this.options.find(option => option.path === this.preview?.selectedSection);
  }

  get hierarchyTree(): StructuredHierarchyNode[] {
    const allOptions = this.options;
    const options = allOptions.filter(option => option.path === this.preview?.selectedSection
      || allOptions.some(candidate => this.isDescendant(candidate.path, option.path)));
    const nodes = options.map(option => ({ ...option, children: [] } as StructuredHierarchyNode));
    const roots: StructuredHierarchyNode[] = [];

    for (const node of nodes) {
      const parent = nodes
        .filter(candidate => this.isDescendant(node.path, candidate.path))
        .sort((left, right) => this.pathSegments(right.path).length - this.pathSegments(left.path).length)[0];
      if (parent) parent.children.push(node);
      else roots.push(node);
    }
    return roots;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['preview']) this.expandSelectedPath();
  }

  changeTable(value: string | null): void {
    if (value && value !== this.preview?.selectedSection) this.tableChange.emit(value);
  }

  toggleDropdown(): void {
    if (this.busy) return;
    this.dropdownOpen = !this.dropdownOpen;
    if (this.dropdownOpen) {
      this.searchTerm = '';
      setTimeout(() => this.tableSearch?.nativeElement.focus());
    }
  }

  selectOption(option: StructuredOutputOption): void {
    this.changeTable(option.path);
    this.dropdownOpen = false;
    this.searchTerm = '';
  }

  selectFirstMatch(event: Event): void {
    event.preventDefault();
    const first = this.filteredOptions[0];
    if (first) this.selectOption(first);
  }

  closeDropdownIfFocusLeaves(event: FocusEvent): void {
    const next = event.relatedTarget as Node | null;
    const current = event.currentTarget as HTMLElement;
    if (!next || !current.contains(next)) this.dropdownOpen = false;
  }

  openStructure(): void {
    this.expandSelectedPath();
    this.structureOpen = true;
  }

  closeStructure(): void {
    this.structureOpen = false;
  }

  @HostListener('document:keydown.escape')
  closeOnEscape(): void {
    this.dropdownOpen = false;
    this.closeStructure();
  }

  toggleNode(path: string): void {
    if (this.expandedPaths.has(path)) this.expandedPaths.delete(path);
    else this.expandedPaths.add(path);
  }

  isExpanded(path: string): boolean {
    return this.expandedPaths.has(path);
  }

  expandAll(): void {
    this.visitNodes(this.hierarchyTree, node => {
      if (node.children.length) this.expandedPaths.add(node.path);
    });
  }

  collapseAll(): void {
    this.expandedPaths.clear();
  }

  private expandSelectedPath(): void {
    const selected = this.preview?.selectedSection;
    if (!selected) return;
    for (const option of this.options) {
      if (option.path === selected || this.isDescendant(selected, option.path)) {
        this.expandedPaths.add(option.path);
      }
    }
  }

  private visitNodes(nodes: StructuredHierarchyNode[], visit: (node: StructuredHierarchyNode) => void): void {
    for (const node of nodes) {
      visit(node);
      this.visitNodes(node.children, visit);
    }
  }

  private pathSegments(path: string): string[] {
    const value = path.replace(/^(json|xml):/i, '').trim();
    if (!value || value === '$' || value === '/') return [];
    if (!value.startsWith('$')) return value.split('/').filter(Boolean);

    const segments: string[] = [];
    const tokenPattern = /(?:^|\.)([^.\[\]]+)|\[(?:"((?:\\.|[^"])*)"|'((?:\\.|[^'])*)'|([^\]]*))\]/g;
    let match: RegExpExecArray | null;
    while ((match = tokenPattern.exec(value.slice(1))) !== null) {
      const token = (match[1] ?? match[2] ?? match[3] ?? match[4] ?? '').trim();
      if (token && !/^\d+$/.test(token)) segments.push(token);
    }
    return segments;
  }

  private isDescendant(candidatePath: string, parentPath: string): boolean {
    const candidate = this.pathSegments(candidatePath);
    const parent = this.pathSegments(parentPath);
    return candidate.length > parent.length && parent.every((segment, index) => candidate[index] === segment);
  }
}
