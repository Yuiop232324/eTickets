import { isTabularPreviewFileName, TABULAR_PREVIEW_MAX_BYTES, tabularPreviewFileExtension } from '../tabular-preview-file';

export const STRUCTURED_PREVIEW_EXTENSIONS = ['json', 'xml'] as const;
export const STRUCTURED_PREVIEW_MAX_BYTES = 100 * 1024 * 1024;
export const STRUCTURED_NODE_MAX_LENGTH = 100;
export const SAMPLE_PREVIEW_FORMAT_LABEL = 'CSV, TXT, XLS, XLSX, XLSB, JSON, or XML';
export type StructuredPreviewExtension = typeof STRUCTURED_PREVIEW_EXTENSIONS[number];

export function structuredPreviewFileExtension(fileName?: string | null): StructuredPreviewExtension | null {
  const extension = fileName?.trim().split('.').pop()?.toLowerCase();
  return STRUCTURED_PREVIEW_EXTENSIONS.includes(extension as StructuredPreviewExtension)
    ? extension as StructuredPreviewExtension : null;
}

export function isStructuredPreviewFileName(fileName?: string | null): boolean {
  return structuredPreviewFileExtension(fileName) !== null;
}

export function isSamplePreviewFileName(fileName: string): boolean {
  return isTabularPreviewFileName(fileName) || isStructuredPreviewFileName(fileName);
}

export function samplePreviewFileExtension(fileName: string): string | null {
  return tabularPreviewFileExtension(fileName) ?? structuredPreviewFileExtension(fileName);
}

export function samplePreviewMaxBytes(fileName: string): number {
  return isStructuredPreviewFileName(fileName) ? STRUCTURED_PREVIEW_MAX_BYTES : TABULAR_PREVIEW_MAX_BYTES;
}
