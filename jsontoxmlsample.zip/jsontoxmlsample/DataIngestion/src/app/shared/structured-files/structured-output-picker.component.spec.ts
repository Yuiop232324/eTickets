import { StructuredFilePreview } from './structured-file.models';
import { StructuredOutputPickerComponent } from './structured-output-picker.component';

describe('StructuredOutputPickerComponent', () => {
  const preview: StructuredFilePreview = {
    format: 'json',
    sections: [
      { path: 'json:$.organizationCatalog', recordCount: 1 },
      { path: 'json:$.organizationCatalog.countries', recordCount: 3 },
      { path: 'json:$.organizationCatalog.countries.companies', recordCount: 8 },
    ],
    selectedSection: 'json:$.organizationCatalog.countries.companies',
    fields: [],
    rows: [],
    totalRecords: 8,
    truncated: false,
    warnings: [],
  };

  it('provides searchable labels without changing section paths', () => {
    const component = new StructuredOutputPickerComponent();
    component.preview = preview;

    expect(component.options).toEqual([
      { path: 'json:$.organizationCatalog', recordCount: 1, display: 'organizationCatalog (1)' },
      { path: 'json:$.organizationCatalog.countries', recordCount: 3, display: 'countries (3)' },
      { path: 'json:$.organizationCatalog.countries.companies', recordCount: 8, display: 'companies (8)' },
    ]);
  });

  it('creates an expandable parent-child tree and preserves the selected output', () => {
    const component = new StructuredOutputPickerComponent();
    component.preview = preview;

    expect(component.hierarchyTree[0].display).toBe('organizationCatalog (1)');
    expect(component.hierarchyTree[0].children[0].display).toBe('countries (3)');
    expect(component.hierarchyTree[0].children[0].children[0].display).toBe('companies (8)');
    expect(component.hierarchyTree[0].children[0].children[0].display)
      .toBe('companies (8)');
  });

  it('expands and collapses individual branches and the full tree', () => {
    const component = new StructuredOutputPickerComponent();
    component.preview = preview;

    component.expandAll();
    expect(component.isExpanded('json:$.organizationCatalog')).toBeTrue();
    expect(component.isExpanded('json:$.organizationCatalog.countries')).toBeTrue();

    component.toggleNode('json:$.organizationCatalog.countries');
    expect(component.isExpanded('json:$.organizationCatalog.countries')).toBeFalse();

    component.collapseAll();
    expect(component.expandedPaths.size).toBe(0);
  });

  it('emits only a changed output table', () => {
    const component = new StructuredOutputPickerComponent();
    component.preview = preview;
    spyOn(component.tableChange, 'emit');

    component.changeTable(preview.selectedSection);
    component.changeTable('json:$.organizationCatalog.countries');

    expect(component.tableChange.emit).toHaveBeenCalledOnceWith('json:$.organizationCatalog.countries');
  });

  it('filters values and handles a clickable option row', () => {
    const component = new StructuredOutputPickerComponent();
    component.preview = preview;
    component.dropdownOpen = true;
    component.searchTerm = 'countries (3)';
    spyOn(component.tableChange, 'emit');

    expect(component.filteredOptions.map(option => option.display)).toEqual(['countries (3)']);
    component.selectOption(component.filteredOptions[0]);

    expect(component.tableChange.emit).toHaveBeenCalledOnceWith('json:$.organizationCatalog.countries');
    expect(component.dropdownOpen).toBeFalse();
  });
});
