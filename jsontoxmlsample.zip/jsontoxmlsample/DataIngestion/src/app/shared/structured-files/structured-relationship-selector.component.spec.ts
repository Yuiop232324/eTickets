import { StructuredRelationshipSelectorComponent } from './structured-relationship-selector.component';
import { StructuredFilePreview } from './structured-file.models';

describe('StructuredRelationshipSelectorComponent', () => {
  const preview = (selections: Array<{ parentPath: string; sourceField: string; outputColumn: string }> = []) => ({
    format: 'json',
    sections: [{ path: 'json:$.companies[].departments[].employees', recordCount: 4 }],
    selectedSection: 'json:$.companies[].departments[].employees',
    fields: [{ name: 'employeeId', dataType: 'string' }],
    rows: [],
    totalRecords: 4,
    truncated: false,
    warnings: [],
    ancestorNodes: [
      {
        path: 'json:$.companies[].departments',
        fields: [{ sourceField: 'departmentCode', dataType: 'string', outputColumn: 'department_code' }],
        selections: selections.filter(item => item.parentPath.endsWith('departments')),
      },
      {
        path: 'json:$.companies',
        fields: [{ sourceField: 'companyCode', dataType: 'string', outputColumn: 'company_code' }],
        selections: selections.filter(item => item.parentPath.endsWith('companies')),
      },
    ],
  } as StructuredFilePreview);

  it('shows parents from the direct parent upward with clear level labels', () => {
    const component = new StructuredRelationshipSelectorComponent();
    component.preview = preview();

    expect(component.ancestorsNearestFirst.map(node => node.path)).toEqual([
      'json:$.companies[].departments',
      'json:$.companies',
    ]);
    expect(component.levelLabel(0)).toBe('Direct parent');
    expect(component.levelLabel(1)).toBe("Parent's parent");
  });

  it('allows a grandparent column without selecting the immediate parent', () => {
    const component = new StructuredRelationshipSelectorComponent();
    component.preview = preview();
    spyOn(component.selectionsChange, 'emit');

    component.toggleField('json:$.companies', 'companyCode', 'company_code', true);

    expect(component.selectionsChange.emit).toHaveBeenCalledOnceWith([{
      parentPath: 'json:$.companies',
      sourceField: 'companyCode',
      outputColumn: 'company_code',
    }]);
  });

  it('removes one relationship level without removing another', () => {
    const department = {
      parentPath: 'json:$.companies[].departments',
      sourceField: 'departmentCode',
      outputColumn: 'department_code',
    };
    const company = {
      parentPath: 'json:$.companies',
      sourceField: 'companyCode',
      outputColumn: 'company_code',
    };
    const component = new StructuredRelationshipSelectorComponent();
    component.preview = preview([department, company]);
    spyOn(component.selectionsChange, 'emit');

    component.toggleField(department.parentPath, department.sourceField, department.outputColumn, false);

    expect(component.selectionsChange.emit).toHaveBeenCalledOnceWith([company]);
  });
});
