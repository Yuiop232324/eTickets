export type StructuredFileFormat = 'json' | 'xml';

export interface StructuredFileSection {
  path: string;
  recordCount: number;
}

export interface StructuredFileField {
  name: string;
  dataType: string;
}

export interface StructuredParentFieldOption {
  sourceField: string;
  dataType: string;
  outputColumn: string;
}

export interface StructuredParentFieldSelection {
  parentPath: string;
  sourceField: string;
  outputColumn: string;
}

export interface StructuredParentNode {
  path: string;
  fields: StructuredParentFieldOption[];
  selection: StructuredParentFieldSelection | null;
}

export interface StructuredAncestorNode {
  path: string;
  fields: StructuredParentFieldOption[];
  selections: StructuredParentFieldSelection[];
}

export interface StructuredFilePreview {
  format: StructuredFileFormat;
  sections: StructuredFileSection[];
  selectedSection: string;
  fields: StructuredFileField[];
  rows: Record<string, unknown>[];
  totalRecords: number;
  truncated: boolean;
  warnings: string[];
  parentNode?: StructuredParentNode | null;
  ancestorNodes?: StructuredAncestorNode[];
}

function structuredNodeHierarchySegments(path: string | null | undefined): string[] {
  const value = (path ?? '').replace(/^(json|xml):/i, '').trim();
  if (!value || value === '$' || value === '/') return [];

  if (!value.startsWith('$')) {
    return value.split('/').map(segment => segment.trim()).filter(Boolean).map(structuredFieldDisplayLabel);
  }

  const segments: string[] = [];
  const tokenPattern = /(?:^|\.)([^.\[\]]+)|\[(?:"((?:\\.|[^"])*)"|'((?:\\.|[^'])*)'|([^\]]*))\]/g;
  const pathWithoutRoot = value.slice(1);
  let match: RegExpExecArray | null;
  while ((match = tokenPattern.exec(pathWithoutRoot)) !== null) {
    const token = (match[1] ?? match[2] ?? match[3] ?? match[4] ?? '').trim();
    if (token && !/^\d+$/.test(token)) segments.push(structuredFieldDisplayLabel(token));
  }
  return segments;
}

export function structuredNodeDisplayLabel(path: string | null | undefined): string {
  const segments = structuredNodeHierarchySegments(path);
  return segments.at(-1) || 'Document level';
}

export function structuredFieldDisplayLabel(fieldName: string | null | undefined): string {
  const label = (fieldName ?? '')
    .replace(/^@+/, '')
    .replace(/[.$\[\]\/]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return label || 'Parent ID';
}

export function structuredNodeHierarchyLabel(path: string | null | undefined): string {
  return `Path: ${(path ?? '').trim() || 'Root'}`;
}

export function structuredParentHierarchyLabel(parentPath: string | null | undefined,
  sourceField?: string | null): string {
  const path = (parentPath ?? '').trim() || 'Root';
  return sourceField ? `Path: ${path} · Column: ${sourceField}` : `Path: ${path}`;
}

export function structuredPreviewColumnDisplayLabel(fieldName: string,
  selections: StructuredParentFieldSelection | StructuredParentFieldSelection[] | null | undefined): string {
  const selection = (Array.isArray(selections) ? selections : selections ? [selections] : [])
    .find(item => fieldName.toLowerCase() === item.outputColumn.toLowerCase());
  return selection
    ? structuredFieldDisplayLabel(selection.sourceField)
    : fieldName;
}

export function serializeStructuredParentSelection(selection: StructuredParentFieldSelection | null | undefined): string | null {
  return selection ? JSON.stringify(selection) : null;
}

export function parseStructuredParentSelection(value: unknown): StructuredParentFieldSelection | null {
  return parseStructuredParentSelections(value)[0] ?? null;
}

export function serializeStructuredParentSelections(
  selections: StructuredParentFieldSelection[] | null | undefined): string | null {
  if (!selections?.length) return null;
  return JSON.stringify(selections.length === 1 ? selections[0] : selections);
}

export function parseStructuredParentSelections(value: unknown): StructuredParentFieldSelection[] {
  if (!value) return [];
  try {
    const candidate = typeof value === 'string' ? JSON.parse(value) : value;
    const entries = Array.isArray(candidate) ? candidate : [candidate];
    return entries.filter(item => typeof item?.parentPath === 'string' && typeof item?.sourceField === 'string'
      && typeof item?.outputColumn === 'string').map(item => ({
        parentPath: item.parentPath,
        sourceField: item.sourceField,
        outputColumn: item.outputColumn,
      }));
  } catch {
    return [];
  }
}
