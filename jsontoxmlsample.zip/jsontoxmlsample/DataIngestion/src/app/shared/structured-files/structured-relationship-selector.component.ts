import { Component, EventEmitter, Input, Output } from '@angular/core';
import {
  structuredFieldDisplayLabel,
  StructuredAncestorNode,
  StructuredFilePreview,
  structuredNodeDisplayLabel,
  structuredNodeHierarchyLabel,
  StructuredParentFieldSelection,
  structuredParentHierarchyLabel,
} from './structured-file.models';

@Component({
  selector: 'app-structured-relationship-selector',
  templateUrl: './structured-relationship-selector.component.html',
  styleUrl: './structured-relationship-selector.component.css',
  standalone: false,
})
export class StructuredRelationshipSelectorComponent {
  @Input() preview: StructuredFilePreview | null = null;
  @Input() busy = false;
  @Input() compact = false;
  @Input() showOutputPicker = true;
  @Output() tableChange = new EventEmitter<string>();
  @Output() selectionsChange = new EventEmitter<StructuredParentFieldSelection[]>();

  readonly tableLabel = structuredNodeDisplayLabel;
  readonly tablePath = structuredNodeHierarchyLabel;
  readonly fieldLabel = structuredFieldDisplayLabel;
  readonly fieldPath = structuredParentHierarchyLabel;

  get ancestorsNearestFirst(): StructuredAncestorNode[] {
    return this.preview?.ancestorNodes ?? [];
  }

  get selections(): StructuredParentFieldSelection[] {
    return this.preview?.ancestorNodes?.flatMap(node => node.selections ?? [])
      ?? (this.preview?.parentNode?.selection ? [this.preview.parentNode.selection] : []);
  }

  selectedCount(path: string): number {
    return this.selections.filter(selection => selection.parentPath === path).length;
  }

  isSelected(path: string, sourceField: string): boolean {
    return this.selections.some(selection => selection.parentPath === path
      && selection.sourceField === sourceField);
  }

  levelLabel(index: number): string {
    if (index === 0) return 'Direct parent';
    if (index === 1) return "Parent's parent";
    return `Parent level ${index + 1}`;
  }

  relationshipText(index: number, ancestor: StructuredAncestorNode): string {
    const output = this.tableLabel(this.preview?.selectedSection);
    const ancestorName = this.tableLabel(ancestor.path);
    if (ancestorName === 'Document level') {
      return `Top-level file values that can be copied into each ${output} row.`;
    }
    if (!ancestor.fields.length) {
      return `${output} is inside the ${ancestorName} container.`;
    }
    if (index === 0) return `Each ${output} row belongs to ${ancestorName}.`;
    const child = this.tableLabel(this.ancestorsNearestFirst[index - 1]?.path);
    return `${ancestorName} is the parent of ${child}.`;
  }

  changeTable(value: string): void {
    if (value && value !== this.preview?.selectedSection) this.tableChange.emit(value);
  }

  toggleField(parentPath: string, sourceField: string, outputColumn: string, checked: boolean): void {
    const next = this.selections.filter(selection => !(selection.parentPath === parentPath
      && selection.sourceField === sourceField));
    if (checked) next.push({ parentPath, sourceField, outputColumn });
    this.selectionsChange.emit(next);
  }
}
