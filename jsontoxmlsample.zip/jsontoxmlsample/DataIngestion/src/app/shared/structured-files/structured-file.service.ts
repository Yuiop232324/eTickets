import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable, timeout } from 'rxjs';
import { environment } from '../../environments/environment';
import { StructuredFilePreview, StructuredParentFieldSelection } from './structured-file.models';

@Injectable({ providedIn: 'root' })
export class StructuredFileService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = `${environment.apiEndpoint.replace(/\/$/, '')}/api/structured-files`;

  preview(file: File, section?: string, maxRows = 50,
    parentSelections?: StructuredParentFieldSelection[] | null): Observable<StructuredFilePreview> {
    return this.http.post<StructuredFilePreview>(`${this.baseUrl}/preview`, this.form(file, section, maxRows, parentSelections), {
      headers: this.headers(),
    }).pipe(timeout(60000));
  }

  normalize(file: File, section?: string, parentSelections?: StructuredParentFieldSelection[] | null): Observable<Blob> {
    return this.http.post(`${this.baseUrl}/normalize`, this.form(file, section, undefined, parentSelections), {
      headers: this.headers(), responseType: 'blob',
    }).pipe(timeout(120000));
  }

  private form(file: File, section?: string, maxRows?: number,
    parentSelections?: StructuredParentFieldSelection[] | null): FormData {
    const form = new FormData();
    form.append('file', file, file.name);
    if (section) form.append('section', section);
    if (parentSelections?.length) form.append('parentSelection', JSON.stringify(
      parentSelections.length === 1 ? parentSelections[0] : parentSelections));
    if (maxRows) form.append('maxRows', `${maxRows}`);
    return form;
  }

  private headers(): HttpHeaders {
    return new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('DIApiToken') ?? ''}`,
      'x-tpdi-api-version': '4.1',
      'x-tpdi-api-sg': sessionStorage.getItem('GUID') ?? '',
    });
  }
}
