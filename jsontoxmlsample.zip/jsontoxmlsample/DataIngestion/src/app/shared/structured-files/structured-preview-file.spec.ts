import {
  parseStructuredParentSelection,
  parseStructuredParentSelections,
  serializeStructuredParentSelection,
  serializeStructuredParentSelections,
  structuredFieldDisplayLabel,
  structuredNodeDisplayLabel,
  structuredNodeHierarchyLabel,
  structuredParentHierarchyLabel,
  structuredPreviewColumnDisplayLabel,
} from './structured-file.models';
import { isSamplePreviewFileName, samplePreviewMaxBytes, STRUCTURED_PREVIEW_MAX_BYTES, structuredPreviewFileExtension } from './structured-preview-file';

describe('structured preview files', () => {
  it('recognizes JSON and XML without changing tabular support', () => {
    expect(structuredPreviewFileExtension('sample.JSON')).toBe('json');
    expect(isSamplePreviewFileName('sample.xml')).toBeTrue();
    expect(isSamplePreviewFileName('sample.xlsx')).toBeTrue();
    expect(isSamplePreviewFileName('sample.pdf')).toBeFalse();
    expect(structuredPreviewFileExtension(undefined)).toBeNull();
  });

  it('uses the isolated 100MB structured-file limit', () => {
    expect(samplePreviewMaxBytes('sample.json')).toBe(STRUCTURED_PREVIEW_MAX_BYTES);
  });

  it('round-trips one parent field and treats invalid persisted data as opt-out', () => {
    const selection = { parentPath: 'json:$.items', sourceField: 'id', outputColumn: 'parent_id' };
    expect(parseStructuredParentSelection(serializeStructuredParentSelection(selection))).toEqual(selection);
    expect(parseStructuredParentSelection('{bad-json}')).toBeNull();
  });

  it('round-trips multiple ancestor context columns while accepting the legacy object', () => {
    const selections = [
      { parentPath: 'json:$.companies[].departments', sourceField: 'name', outputColumn: 'department_name' },
      { parentPath: 'json:$.companies', sourceField: 'name', outputColumn: 'company_name' },
    ];
    expect(parseStructuredParentSelections(serializeStructuredParentSelections(selections))).toEqual(selections);
    expect(parseStructuredParentSelections(JSON.stringify(selections[0]))).toEqual([selections[0]]);
  });

  it('formats node paths for display without changing their raw values', () => {
    const jsonPath = 'json:$.company.departments[].employees';
    const xmlPath = 'xml:/dataset/record/id';

    expect(structuredNodeDisplayLabel(jsonPath)).toBe('employees');
    expect(structuredNodeDisplayLabel(xmlPath)).toBe('id');
    expect(structuredNodeDisplayLabel('json:$')).toBe('Document level');
    expect(structuredFieldDisplayLabel('@')).toBe('Parent ID');
    expect(jsonPath).toBe('json:$.company.departments[].employees');
  });

  it('shows technical paths only in hover tooltips', () => {
    expect(structuredNodeHierarchyLabel('json:$.company.departments[].employees'))
      .toBe('Path: json:$.company.departments[].employees');
    expect(structuredNodeHierarchyLabel('json:$["a.b"].items'))
      .toBe('Path: json:$["a.b"].items');
    expect(structuredNodeHierarchyLabel('xml:/dataset/record/id'))
      .toBe('Path: xml:/dataset/record/id');
    expect(structuredParentHierarchyLabel('xml:/company/department', '@name'))
      .toBe('Path: xml:/company/department · Column: @name');
  });

  it('shows the selected parent field name over its generated output column', () => {
    const selection = { parentPath: 'xml:/company/department', sourceField: '@name', outputColumn: 'parent_name' };

    expect(structuredFieldDisplayLabel(selection.sourceField)).toBe('name');
    expect(structuredPreviewColumnDisplayLabel('parent_name', selection)).toBe('name');
    expect(structuredPreviewColumnDisplayLabel('employee_id', selection)).toBe('employee_id');
    expect(selection.outputColumn).toBe('parent_name');
  });
});
