import { FormBuilder } from '@angular/forms';
import { of } from 'rxjs';
import { DiParserService } from '../core/services/di-parser.service';
import { configurationUploadFile, FileUploadComponent, importApiEndpointForFile } from './file-upload.component';

describe('FileUploadComponent structured files', () => {
  [
    ['sample.csv', 'ProcessCsvFile'],
    ['sample.txt', 'ProcessTxtFile'],
    ['sample.xlsx', 'ProcessExcelFile'],
    ['sample.JSON', 'ProcessJsonFile'],
    ['sample.XML', 'ProcessXmlFile'],
  ].forEach(([fileName, endpoint]) => {
    it(`routes ${fileName} to ${endpoint}`, () => {
      expect(importApiEndpointForFile(fileName)).toBe(endpoint);
    });
  });

  it('routes from the original structured source after preview normalization', () => {
    expect(importApiEndpointForFile('sample.csv', 'sample.JSON')).toBe('ProcessJsonFile');
    expect(importApiEndpointForFile('sample.csv', 'sample.XML')).toBe('ProcessXmlFile');
  });

  it('uploads the original structured file instead of the normalized preview CSV', () => {
    const normalized = new File(['id\r\n1'], 'sample.csv');
    const original = new File(['{"id":1}'], 'sample.json');

    expect(configurationUploadFile(normalized, original)).toBe(original);
    expect(configurationUploadFile(normalized, null)).toBe(normalized);
  });

  it('displays the selected parent field over its generated preview column', () => {
    const component: any = Object.create(FileUploadComponent.prototype);
    component.columnNameDisplayMode = 'FileColumnName';
    component.structuredPreview = {
      parentNode: {
        selection: { parentPath: 'xml:/company/department', sourceField: '@name', outputColumn: 'parent_name' },
      },
    };

    expect(component.getHeaderDisplayName({ ColumnName: 'PARENT_NAME', DbColumnName: 'PARENT_NAME' })).toBe('name');
  });

  it('clears the parent choice and balances the loader when the node changes', async () => {
    const component: any = Object.create(FileUploadComponent.prototype);
    component.isSelectedExistingProcess = false;
    component.structuredSourceFile = new File(['{}'], 'sample.json');
    component.structuredPreviewLoading = false;
    component.dataSource = 1;
    component.busyService = jasmine.createSpyObj('busyService', ['busy', 'idle']);
    component.toastr = jasmine.createSpyObj('toastr', ['error']);
    component.prepareStructuredFile = jasmine.createSpy('prepareStructuredFile').and.resolveTo();
    component.prepopForm = jasmine.createSpy('prepopForm');
    component.onPreview = jasmine.createSpy('onPreview').and.resolveTo(true);
    component.config = {};

    await component.onStructuredSectionChange('json:$.items');

    expect(component.prepareStructuredFile).toHaveBeenCalledWith(component.structuredSourceFile, 'json:$.items', []);
    expect(component.busyService.busy).toHaveBeenCalledTimes(1);
    expect(component.busyService.idle).toHaveBeenCalledTimes(1);
    expect(component.structuredPreviewLoading).toBeFalse();
  });

  it('refreshes with selected context columns from ancestor tables', async () => {
    const component: any = Object.create(FileUploadComponent.prototype);
    component.structuredPreview = {
      selectedSection: 'json:$.groups[].items',
      parentNode: {
        path: 'json:$.groups',
        fields: [{ sourceField: 'id', dataType: 'string', outputColumn: 'parent_id' }],
        selection: null,
      },
    };
    component.refreshStructuredPreview = jasmine.createSpy('refreshStructuredPreview').and.resolveTo();

    const selections = [{
      parentPath: 'json:$.groups',
      sourceField: 'id',
      outputColumn: 'parent_id',
    }];
    await component.onStructuredParentFieldChange(selections);

    expect(component.refreshStructuredPreview).toHaveBeenCalledOnceWith('json:$.groups[].items', selections);
  });

  it('parses every normalized row after the parent column is appended', async () => {
    const parser = new DiParserService({} as any);
    const csv = [
      '_ID,FIRSTNAME,LASTNAME,ROLE,SKILLS,parent_name',
      'E101,Jane,Doe,Senior Developer,"<skills><skill>Java</skill></skills>",Engineering',
      'E102,John,Smith,Systems Architect,"<skills><skill>AWS</skill></skills>",Engineering',
      'D201,Alice,Jones,UX Researcher,"<skills><skill>Figma</skill></skills>",Design',
    ].join('\r\n');

    const result = await parser.asyncParseCSVTXT(new File([csv], 'company_directory.csv'), {
      delimiter: ',',
      hasHeader: true,
      skipEmptyLines: true,
      quoteCharacter: '"',
      worker: true,
      useOnlyRomanNumerals: false,
      useOnlyEnglishLetters: false,
      englishOnlyCharacters: [],
    });

    expect(result.meta.fields).toEqual(['_ID', 'FIRSTNAME', 'LASTNAME', 'ROLE', 'SKILLS', 'PARENT_NAME']);
    expect(result.data.length).toBe(3);
    expect(result.data.map((row: Record<string, string>) => row['PARENT_NAME']))
      .toEqual(['Engineering', 'Engineering', 'Design']);
  });

  it('rebuilds only a structured mapping when a parent column changes its schema', () => {
    const component: any = Object.create(FileUploadComponent.prototype);
    const existing = ['_ID', 'FIRSTNAME', 'LASTNAME', 'ROLE', 'SKILLS']
      .map(ColumnName => ({ ColumnName }));
    const withParent = [...existing.map(column => column.ColumnName), 'PARENT_NAME'];

    component.structuredSourceFile = new File(['{}'], 'sample.json');
    expect(component.columnMappingsMatch(existing, withParent)).toBeFalse();

    component.structuredSourceFile = null;
    expect(component.columnMappingsMatch(existing, withParent)).toBeTrue();
  });

  for (const format of ['json', 'xml'] as const) {
    it(`accepts and normalizes a ${format.toUpperCase()} local upload`, async () => {
      const preview = {
        format,
        sections: [{ path: format === 'json' ? '$.orders' : '/root/orders', recordCount: 1 }],
        selectedSection: format === 'json' ? '$.orders' : '/root/orders',
        fields: [{ name: 'id', dataType: 'integer' }], rows: [{ id: 1 }], totalRecords: 1,
        truncated: false, warnings: [],
      };
      const structured = {
        preview: jasmine.createSpy().and.returnValue(of(preview)),
        normalize: jasmine.createSpy().and.returnValue(of(new Blob(['id\r\n1'], { type: 'text/csv' }))),
      };
      const configService = { logUploadedFile: () => of(null) };
      const toastr = jasmine.createSpyObj('ToastrService', ['error']);
      const component = new FileUploadComponent(
        new FormBuilder(), {} as any, {} as any, configService as any, toastr,
        {} as any, {} as any, { idle: () => undefined } as any, { dataSource: 1 } as any,
        {} as any, {} as any, {} as any, {} as any, structured as any,
      );
      component.initializeForm();
      spyOn(component, 'onPreview').and.resolveTo(true);
      const file = new File([format === 'json' ? '{"orders":[{"id":1}]}' : '<root><orders><id>1</id></orders></root>'], `sample.${format}`);

      await component.onFileChange({ target: { files: [file] } });

      expect(toastr.error).not.toHaveBeenCalled();
      expect(component.structuredPreview).toEqual(preview);
      expect(component.file.name).toBe('sample.csv');
      expect(component.fileType).toBe('csv');
      expect(component.onPreview).toHaveBeenCalled();
    });
  }
});

describe('Landing Layer structured batch validation', () => {
  function componentWith(files: File[]) {
    const component: any = Object.create(FileUploadComponent.prototype);
    component.selectedFiles = files.map(File => ({ File, status: 'valid' }));
    component.toastr = jasmine.createSpyObj('toastr', ['error']);
    component.structuredFileService = {
      preview: jasmine.createSpy().and.returnValue(of({
        format: 'json', selectedSection: 'json:$.items', sections: [], fields: [], rows: []
      }))
    };
    return component;
  }

  it('validates every file against the selected node and retains original uploads', async () => {
    const files = [new File(['{}'], 'a.json'), new File(['{}'], 'b.json')];
    const component = componentWith(files);
    await component.prepareLandingStructuredFiles('json:$.items');
    expect(component.structuredFileService.preview.calls.count()).toBe(2);
    expect(component.structuredFileService.preview.calls.allArgs().every(args => args[1] === 'json:$.items')).toBeTrue();
    expect(component.selectedFiles.map(item => item.File)).toEqual(files);
    expect(component.landingStructuredError).toBe('');
  });

  it('blocks a mixed-format batch before submission', async () => {
    const component = componentWith([new File(['{}'], 'a.json'), new File(['<r/>'], 'b.xml')]);
    await component.prepareLandingStructuredFiles();
    expect(component.landingStructuredError).toContain('one JSON/XML format');
    expect(component.structuredFileService.preview).not.toHaveBeenCalled();
  });

  it('retains an existing process node when all files are removed', async () => {
    const component = componentWith([]);
    component.isSelectedExistingProcess = true;
    component.structuredPreview = { selectedSection: 'json:$.items' };
    await component.prepareLandingStructuredFiles();
    expect(component.structuredPreview.selectedSection).toBe('json:$.items');
    component.selectedFiles = [{ File: new File(['id'], 'a.csv') }];
    await component.prepareLandingStructuredFiles();
    expect(component.landingStructuredError).toContain('matching');
  });

  it('opens Modify Settings after a SharePoint Landing Layer batch completes', async () => {
    const component: any = Object.create(FileUploadComponent.prototype);
    component.dataSource = 3;
    component.showSharepoint = true;
    component.sharepointToPreviewLoading = false;
    component.sharepointSelectionQueue = Promise.resolve();
    component.onFileChange = jasmine.createSpy('onFileChange').and.resolveTo();
    component.modifySettingsOpen = jasmine.createSpy('modifySettingsOpen');
    const files = [new File(['id'], 'sample.csv')];

    component.onSharepointFilesSelected(files);
    await component.sharepointSelectionQueue;

    expect(component.onFileChange).toHaveBeenCalledOnceWith({ target: { files }, fromSharepoint: true });
    expect(component.showSharepoint).toBeFalse();
    expect(component.modifySettingsOpen).toHaveBeenCalledTimes(1);
  });

  it('opens Modify Settings after a Google Drive Landing Layer batch completes', async () => {
    const component: any = Object.create(FileUploadComponent.prototype);
    component.dataSource = 3;
    component.showGoogleDrive = true;
    component.googleDriveToPreviewLoading = false;
    component.googleDriveSelectionQueue = Promise.resolve();
    component.onFileChange = jasmine.createSpy('onFileChange').and.resolveTo();
    component.modifySettingsOpen = jasmine.createSpy('modifySettingsOpen');
    const files = [new File(['id'], 'sample.csv')];

    component.onGoogleDriveFilesSelected(files);
    await component.googleDriveSelectionQueue;

    expect(component.onFileChange).toHaveBeenCalledOnceWith({ target: { files }, fromGoogleDrive: true });
    expect(component.showGoogleDrive).toBeFalse();
    expect(component.modifySettingsOpen).toHaveBeenCalledTimes(1);
  });
});
