import { fakeAsync, tick, flushMicrotasks } from '@angular/core/testing';
import { FileUploadComponent } from './file-upload.component';

describe('File First loading feedback', () => {
  it('starts immediately and remains visible until preview preparation completes', fakeAsync(() => {
    const component: any = Object.create(FileUploadComponent.prototype);
    let finish!: () => void;
    component.processSelectedFile = jasmine.createSpy().and.returnValue(new Promise<void>(resolve => finish = resolve));
    const event = { target: { files: [new File(['id'], 'sample.csv')] } };
    component.onFileChange(event);
    expect(component.fileSelectionLoading).toBeTrue();
    expect(component.processSelectedFile).not.toHaveBeenCalled();
    tick(17);
    expect(component.processSelectedFile).toHaveBeenCalledOnceWith(event);
    expect(component.fileSelectionLoading).toBeTrue();
    finish(); flushMicrotasks();
    expect(component.fileSelectionLoading).toBeFalse();
  }));

  it('clears the loader when preview preparation fails', fakeAsync(() => {
    const component: any = Object.create(FileUploadComponent.prototype);
    component.processSelectedFile = jasmine.createSpy().and.callFake(() => Promise.reject(new Error('Preview failed')));
    let error: Error | undefined;
    component.onFileChange({ target: { files: [new File(['bad'], 'sample.json')] } }).catch((value: Error) => error = value);
    tick(17); flushMicrotasks();
    expect(error?.message).toBe('Preview failed');
    expect(component.fileSelectionLoading).toBeFalse();
  }));

  it('does not start processing when the file picker is cancelled', async () => {
    const component: any = Object.create(FileUploadComponent.prototype);
    component.fileSelectionLoading = false;
    component.processSelectedFile = jasmine.createSpy();
    await component.onFileChange({ target: { files: [] } });
    expect(component.fileSelectionLoading).toBeFalse();
    expect(component.processSelectedFile).not.toHaveBeenCalled();
  });
});
