import { HttpRequest } from '@angular/common/http';
import { resolveGuestMock } from './guest-mock.data';

describe('local guest connector pagination', () => {
  const page = (pageNumber: number) => resolveGuestMock(new HttpRequest(
    'GET',
    `https://localhost:7146/api/workspace-connect/tenants?pageNumber=${pageNumber}&pageSize=1&connector=all&status=all&profile=all`,
  )) as any;

  it('returns only the requested page and preserves total counts', () => {
    const first = page(1).data;
    const second = page(2).data;

    expect(first.pageNumber).toBe(1);
    expect(first.applications.length).toBe(1);
    expect(first.tenants.length).toBe(0);
    expect(second.pageNumber).toBe(2);
    expect(second.applications.length).toBe(0);
    expect(second.tenants.length).toBe(1);
    expect(second.filteredCount).toBe(2);
    expect(second.totalCount).toBe(2);
  });

  it('clamps an out-of-range page number', () => {
    expect(page(99).data.pageNumber).toBe(2);
  });
});
