import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { TokenService } from '../services/token.service';
import { GUEST_GROUP_ID, GUEST_TOKEN, isGuestSession } from './guest.util';

@Injectable({ providedIn: 'root' })
export class LocalGuestSessionService {
  readonly accessPermissions = ['ruleset-list', 'profiling', 'eib'].map(component => ({ component }));

  constructor(private tokenService: TokenService) { }

  start(): void {
    if (environment.production) return;

    localStorage.setItem('DIApiToken', GUEST_TOKEN);
    localStorage.setItem('access_token', GUEST_TOKEN);
    localStorage.setItem('token_expiry', String(Date.now() + 60 * 60 * 1000));
    sessionStorage.setItem('isGuestLogin', 'true');
    sessionStorage.setItem('GUID', GUEST_GROUP_ID);
    sessionStorage.setItem('UserDefaultGroup', 'Product Development');
    sessionStorage.setItem('username', 'guest');
    sessionStorage.setItem('userFullName', 'Local Guest');
    sessionStorage.setItem('FullName', 'Local Guest');
    sessionStorage.setItem('emailID', 'guest@local.dev');
    sessionStorage.setItem('Upn', 'guest@local.dev');
    sessionStorage.setItem('upn', 'guest');
    sessionStorage.setItem('fullUPN', 'guest@local.dev');
    sessionStorage.setItem('userId', 'guest');
    sessionStorage.setItem('JobTitle', 'Local Testing');
    sessionStorage.setItem('tokenTime', new Date().toString());
    environment.userId = 'guest';
    environment.userFullName = 'Local Guest';
    environment.isAdmin = 'true';
    this.tokenService.setToken(GUEST_TOKEN);
  }

  restore(): boolean {
    if (environment.production || !isGuestSession()) return false;
    this.start();
    return true;
  }
}
