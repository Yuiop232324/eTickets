import { HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';
import { firstValueFrom, of } from 'rxjs';
import { GUEST_TOKEN } from '../guest/guest.util';
import { GuestInterceptor } from './guest.interceptor';

describe('GuestInterceptor live APIs', () => {
  afterEach(() => {
    localStorage.removeItem('DIApiToken');
    sessionStorage.removeItem('isGuestLogin');
  });

  it('passes Blob responses from structured-file endpoints through unchanged', async () => {
    localStorage.setItem('DIApiToken', GUEST_TOKEN);
    const body = new Blob(['id\r\n1'], { type: 'text/csv' });
    const next = jasmine.createSpyObj<HttpHandler>('HttpHandler', ['handle']);
    next.handle.and.returnValue(of(new HttpResponse({ status: 200, body })));
    const request = new HttpRequest('POST', 'https://localhost:7146/api/structured-files/normalize', new FormData(), {
      responseType: 'blob',
    });

    const response = await firstValueFrom(new GuestInterceptor().intercept(request, next));

    expect(next.handle).toHaveBeenCalledOnceWith(request);
    expect((response as HttpResponse<Blob>).body).toBe(body);
  });

  const liveRequests: Array<['GET' | 'POST', string]> = [
    ['GET', 'https://localhost:7146/api/applications?includeInactive=true'],
    ['POST', 'https://localhost:7146/api/applications/validate-external-site'],
    ['GET', 'https://localhost:7146/api/workspace-connect/tenants?pageNumber=1&pageSize=8'],
    ['GET', 'https://localhost:7146/api/GoogleDrive/tenants?includeInactive=true'],
  ];

  liveRequests.forEach(([method, url]) => {
    it(`passes ${method} ${url} to the real API`, async () => {
      localStorage.setItem('DIApiToken', GUEST_TOKEN);
      const next = jasmine.createSpyObj<HttpHandler>('HttpHandler', ['handle']);
      next.handle.and.returnValue(of(new HttpResponse({ status: 200, body: { success: true } })));
      const request = method === 'GET'
        ? new HttpRequest('GET', url)
        : new HttpRequest('POST', url, {});

      await firstValueFrom(new GuestInterceptor().intercept(request, next));

      expect(next.handle).toHaveBeenCalledOnceWith(request);
    });
  });
});
