import JSZip from 'jszip';
import { DiParserService } from './di-parser.service';

describe('DiParserService namespace-prefixed XLSX', () => {
  it('reads cells whose spreadsheet XML uses a namespace prefix', async () => {
    const zip = new JSZip();
    zip.file('[Content_Types].xml', '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');
    zip.file('_rels/.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    zip.file('xl/workbook.xml', '<?xml version="1.0"?><x:workbook xmlns:x="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><x:sheets><x:sheet name="Data" sheetId="1" r:id="rId1"/></x:sheets></x:workbook>');
    zip.file('xl/_rels/workbook.xml.rels', '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>');
    zip.file('xl/worksheets/sheet1.xml', '<?xml version="1.0"?><x:worksheet xmlns:x="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><x:dimension ref="A1:B2"/><x:sheetData><x:row r="1"><x:c r="A1" t="str"><x:v>Name</x:v></x:c><x:c r="B1" t="str"><x:v>Count</x:v></x:c></x:row><x:row r="2"><x:c r="A2" t="str"><x:v>Alpha</x:v></x:c><x:c r="B2" t="n"><x:v>0</x:v></x:c></x:row></x:sheetData></x:worksheet>');
    const file = new File([await zip.generateAsync({ type: 'blob' })], 'prefixed.xlsx');
    const parser = new DiParserService({ busy: () => undefined, idle: () => undefined } as any);

    const result = await parser.asyncParseExcel(file, 1, 0, true);

    expect(result[0].sheetName).toBe('Data');
    expect(result[0].workBook).toEqual([['Name', 'Count'], ['Alpha', '0']]);
  });
});
