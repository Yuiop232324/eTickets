import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { map, Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { LoginService } from '../services/login.service';
import { environment } from '../../environments/environment';
import { isGuestSession } from '../guest/guest.util';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard  {

  constructor(private loginService : LoginService, private router: Router){}
  
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      if (!environment.production && isGuestSession()) return true;
      return this.loginService.currentUser$.pipe(
        map(auth =>
          {
            if(auth?.isAdmin) {
              return true;
            }
            else{
              this.router.navigate(['/configuration'],{queryParams : {returnUrl: state.url}});
              return false;
            }
          })
      );
    }
  
}
  
