import { CommonModule } from '@angular/common';
import { Component, EventEmitter, inject, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FormGroup, FormsModule } from '@angular/forms';
import { firstValueFrom, Subscription } from 'rxjs';
import { googleDriveEffectiveFileName } from '../../workspace-connect/core/google-drive-file-eligibility';
import { GoogleDriveItem, GoogleDriveTenant, GoogleDriveTenantFolder } from '../../workspace-connect/core/google-drive-workspace.types';
import { WorkspaceConnectTenantHierarchyComponent } from '../../workspace-connect/core/workspace-connect-tenant-hierarchy.component';
import { WC_IMAGES } from '../../workspace-connect/core/workspace-connect.assets';
import {
  emptyTenantHierarchySelection,
  SharePointTenantHierarchySelection,
  tenantFilterFromClientInfo,
} from '../../workspace-connect/core/workspace-connect.tenant';
import { formatFileSize } from '../../workspace-connect/core/workspace-connect.utils';
import { GoogleDriveWorkspaceComponent } from '../../workspace-connect/google-drive-workspace/google-drive-workspace.component';
import { GoogleDriveApiService } from '../../workspace-connect/services/google-drive-api.service';
import { googleDriveTenantMatchesHierarchy } from './google-drive-file-first-scope';

@Component({
  selector: 'app-file-first-google-drive-attach',
  standalone: true,
  imports: [CommonModule, FormsModule, GoogleDriveWorkspaceComponent, WorkspaceConnectTenantHierarchyComponent],
  templateUrl: './file-first-google-drive-attach.component.html',
  styleUrl: './file-first-google-drive-attach.component.css',
  host: {
    '[class.ff-gd-viewer-open]': 'viewerOpen',
  },
})
export class FileFirstGoogleDriveAttachComponent implements OnInit, OnChanges, OnDestroy {
  private readonly api = inject(GoogleDriveApiService);

  @Input() clientInfoForm: FormGroup | null = null;
  @Input() allowAllFileTypes = false;
  @Input() externalBusy = false;
  @Output() fileSelected = new EventEmitter<File>();
  @Output() filesSelected = new EventEmitter<File[]>();
  @Output() back = new EventEmitter<void>();

  @ViewChild(GoogleDriveWorkspaceComponent)
  protected workspace?: GoogleDriveWorkspaceComponent;

  protected readonly driveLogo = WC_IMAGES.googleDrive;
  protected hierarchySelection = emptyTenantHierarchySelection();
  protected tenants: GoogleDriveTenant[] = [];
  protected selectedTenantId = '';
  protected selectedTenant: GoogleDriveTenant | null = null;
  protected selectedFolderId = '';
  protected selectedFolder: GoogleDriveTenantFolder | null = null;
  protected pendingSelections: GoogleDriveItem[] = [];
  protected tenantsLoading = false;
  protected fileLoading = false;
  protected batchDownloading = false;
  protected batchDownloadedCount = 0;
  protected batchTotalCount = 0;
  protected viewerOpen = false;
  protected error = '';

  private clientInfoSub?: Subscription;
  private tenantLoadGeneration = 0;

  ngOnInit(): void {
    this.initializeHierarchySelection();
    this.bindClientInfoWatch();
    void this.refreshTenants();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['clientInfoForm']) {
      this.initializeHierarchySelection();
      this.bindClientInfoWatch();
      void this.refreshTenants();
    }
  }

  ngOnDestroy(): void {
    this.clientInfoSub?.unsubscribe();
    this.tenantLoadGeneration++;
  }

  protected get accessReady(): boolean {
    return !!(
      this.hierarchySelection.regionIdent &&
      this.hierarchySelection.subRegionCode?.trim() &&
      this.hierarchySelection.clientIdent &&
      this.hierarchySelection.securityGroupId?.trim()
    );
  }

  protected get canProceedSelections(): boolean {
    return !!this.pendingSelections.length && !this.fileLoading && !this.externalBusy && !this.batchDownloading;
  }

  protected onHierarchySelectionChange(selection: SharePointTenantHierarchySelection): void {
    this.hierarchySelection = selection;
    this.clientInfoForm?.patchValue({
      RegionId: selection.regionIdent ?? '',
      SubRegionId: selection.subRegionCode ?? '',
      ClientId: selection.clientIdent ?? '',
      security_group: (selection.securityGroups ?? []).map((group) => ({
        id: group.id,
        displayName: group.name,
      })),
    }, { emitEvent: false });

    this.selectedTenantId = '';
    this.selectedTenant = null;
    this.selectedFolderId = '';
    this.selectedFolder = null;
    this.pendingSelections = [];
    this.workspace?.disconnect();
    void this.refreshTenants();
  }

  protected onTenantChange(tenantId: string): void {
    this.selectedTenantId = tenantId;
    this.selectedTenant = this.tenants.find((item) => item.tenantId === tenantId) ?? null;
    this.selectedFolderId = '';
    this.selectedFolder = null;
    this.pendingSelections = [];
    this.error = '';
    this.workspace?.disconnect();
  }

  protected onFolderChange(tenantFolderId: string): void {
    this.selectedFolderId = tenantFolderId;
    this.selectedFolder = this.selectedTenant?.folders.find((folder) => folder.tenantFolderId === tenantFolderId) ?? null;
    this.pendingSelections = [];
    this.error = '';
  }

  protected async onWorkspaceFilePicked(item: GoogleDriveItem): Promise<void> {
    if (!this.selectedFolder || item.isFolder || this.fileLoading || this.externalBusy) return;

    if (this.allowAllFileTypes) {
      if (!this.pendingSelections.some((selected) => selected.id === item.id)) {
        this.pendingSelections = [...this.pendingSelections, item];
      }
      this.workspace?.closePreview();
      return;
    }

    this.workspace?.closePreview();
    this.fileLoading = true;
    this.error = '';
    try {
      this.fileSelected.emit(await this.downloadAsFile(item));
    } catch (error) {
      console.error('[Google Drive File Pick] Could not fetch selected file', { itemId: item.id, error });
      this.error = 'Unable to download the selected Google Drive file. Please try again.';
    } finally {
      this.fileLoading = false;
    }
  }

  protected removePendingSelection(index: number): void {
    if (!this.batchDownloading) {
      this.pendingSelections = this.pendingSelections.filter((_, itemIndex) => itemIndex !== index);
    }
  }

  protected clearPendingSelections(): void {
    if (!this.batchDownloading) this.pendingSelections = [];
  }

  protected async proceedWithSelections(): Promise<void> {
    if (!this.canProceedSelections) return;

    const queue = [...this.pendingSelections];
    const files: File[] = [];
    const failed: string[] = [];
    this.batchDownloading = true;
    this.batchDownloadedCount = 0;
    this.batchTotalCount = queue.length;
    this.error = '';

    try {
      for (let index = 0; index < queue.length; index++) {
        const item = queue[index];
        try {
          files.push(await this.downloadAsFile(item));
        } catch (error) {
          console.error('[Google Drive File Pick] Could not fetch selected file in batch', { itemId: item.id, error });
          failed.push(item.name);
        } finally {
          this.batchDownloadedCount = index + 1;
        }
      }

      if (files.length) this.filesSelected.emit(files);
      if (failed.length) {
        this.error = `${failed.length} Google Drive file${failed.length === 1 ? '' : 's'} could not be downloaded.`;
      } else {
        this.pendingSelections = [];
      }
    } finally {
      this.batchDownloading = false;
    }
  }

  protected formatSize(bytes?: number | null): string {
    return formatFileSize(bytes ?? 0);
  }

  protected goBack(): void {
    this.back.emit();
  }

  private async refreshTenants(): Promise<void> {
    const generation = ++this.tenantLoadGeneration;
    this.tenants = [];
    this.selectedTenantId = '';
    this.selectedTenant = null;
    this.selectedFolderId = '';
    this.selectedFolder = null;
    this.error = '';
    if (!this.accessReady) return;

    this.tenantsLoading = true;
    try {
      const tenants = await firstValueFrom(this.api.getTenants(
        false,
        tenantFilterFromClientInfo(this.clientInfoForm?.value ?? null) ?? undefined,
      ));
      if (generation !== this.tenantLoadGeneration) return;
      this.tenants = tenants.filter((tenant) =>
        googleDriveTenantMatchesHierarchy(tenant, this.hierarchySelection));
    } catch (error) {
      if (generation !== this.tenantLoadGeneration) return;
      console.error('[Google Drive File Pick] Could not load registered tenants', error);
      this.error = 'Unable to load Google Drive tenants for this access configuration.';
    } finally {
      if (generation === this.tenantLoadGeneration) this.tenantsLoading = false;
    }
  }

  private async downloadAsFile(item: GoogleDriveItem): Promise<File> {
    const folderId = this.selectedFolder?.folderId;
    if (!folderId) throw new Error('No Google Drive tenant is selected.');
    const blob = await firstValueFrom(this.api.downloadFile(folderId, item.id));
    return new File([blob], googleDriveEffectiveFileName(item), { type: blob.type || item.mimeType || 'application/octet-stream' });
  }

  private bindClientInfoWatch(): void {
    this.clientInfoSub?.unsubscribe();
    this.clientInfoSub = this.clientInfoForm?.valueChanges.subscribe(() => {
      this.initializeHierarchySelection();
      void this.refreshTenants();
    });
  }

  private initializeHierarchySelection(): void {
    const value = this.clientInfoForm?.value ?? {};
    const formGroups = Array.isArray(value.security_group) ? value.security_group : [];
    const securityGroups = formGroups
      .map((group: { id?: string; securityGroupId?: string; displayName?: string; securityGroupName?: string }) => ({
        id: group.securityGroupId ?? group.id ?? '',
        name: group.securityGroupName ?? group.displayName ?? '',
      }))
      .filter((group: { id: string }) => !!group.id);

    if (!securityGroups.length) {
      const id = sessionStorage.getItem('GUID')?.trim();
      const name = sessionStorage.getItem('UserDefaultGroup')?.trim();
      if (id) securityGroups.push({ id, name: name || id });
    }

    const regionIdent = Number(value.RegionId);
    const clientIdent = Number(value.ClientId);
    const primaryGroup = securityGroups[0] ?? null;
    this.hierarchySelection = {
      regionIdent: Number.isFinite(regionIdent) && regionIdent > 0 ? regionIdent : null,
      regionName: value.RegionName ?? '',
      subRegionCode: value.SubRegionId ? String(value.SubRegionId) : '',
      subRegionName: value.SubRegionName ?? '',
      clientIdent: Number.isFinite(clientIdent) && clientIdent > 0 ? clientIdent : null,
      clientName: value.ClientName ?? '',
      securityGroupId: primaryGroup?.id ?? null,
      securityGroupName: primaryGroup?.name ?? '',
      securityGroups,
    };

    if (!formGroups.length && securityGroups.length) {
      this.clientInfoForm?.patchValue({
        security_group: securityGroups.map((group) => ({ id: group.id, displayName: group.name })),
      }, { emitEvent: false });
    }
  }
}
