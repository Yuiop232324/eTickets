import { GoogleDriveTenant } from '../../workspace-connect/core/google-drive-workspace.types';
import {
  SP_ALL_CLIENT_IDENT,
  SP_ALL_SECURITY_GROUP_ID,
  SP_ALL_SUBREGION_CODE,
  SharePointTenantHierarchySelection,
} from '../../workspace-connect/core/workspace-connect.tenant';

/**
 * A tenant can be narrower than the current hierarchy or can grant an
 * inherited "All" scope. Region is always the required top-level boundary.
 */
export function googleDriveTenantMatchesHierarchy(
  tenant: GoogleDriveTenant,
  selection: SharePointTenantHierarchySelection,
): boolean {
  return tenant.isActive &&
    !tenant.isDraft &&
    tenant.folders.some((folder) => folder.isActive && folder.permissionConfirmed && !!folder.folderId) &&
    tenant.regionIdent === selection.regionIdent &&
    stringScopeMatches(tenant.subRegionCode, selection.subRegionCode, SP_ALL_SUBREGION_CODE) &&
    numericScopeMatches(tenant.clientIdent, selection.clientIdent, SP_ALL_CLIENT_IDENT) &&
    securityGroupScopeMatches(tenant, selection);
}

function securityGroupScopeMatches(
  tenant: GoogleDriveTenant,
  selection: SharePointTenantHierarchySelection,
): boolean {
  const registeredIds = (tenant.securityGroups?.length
    ? tenant.securityGroups.map((group) => group.id)
    : [tenant.securityGroupId])
    .map(normalize)
    .filter(Boolean);
  if (!registeredIds.length || registeredIds.includes(normalize(SP_ALL_SECURITY_GROUP_ID))) return true;

  const selectedIds = (selection.securityGroups?.length
    ? selection.securityGroups.map((group) => group.id)
    : [selection.securityGroupId])
    .map(normalize)
    .filter(Boolean);
  return selectedIds.some((id) => registeredIds.includes(id));
}

function stringScopeMatches(
  registeredValue?: string | null,
  selectedValue?: string | null,
  allValue = 'ALL',
): boolean {
  const registered = normalize(registeredValue);
  const selected = normalize(selectedValue);
  return !registered || registered === normalize(allValue) || registered === 'all' || registered === selected;
}

function numericScopeMatches(
  registeredValue?: number | null,
  selectedValue?: number | null,
  allValue = 0,
): boolean {
  return registeredValue == null || registeredValue === allValue || registeredValue === selectedValue;
}

function normalize(value?: string | null): string {
  return (value ?? '').trim().toLocaleLowerCase();
}
