import { GoogleDriveTenant } from '../../workspace-connect/core/google-drive-workspace.types';
import { SharePointTenantHierarchySelection } from '../../workspace-connect/core/workspace-connect.tenant';
import { googleDriveTenantMatchesHierarchy } from './google-drive-file-first-scope';

describe('googleDriveTenantMatchesHierarchy', () => {
  const selectedHierarchy: SharePointTenantHierarchySelection = {
    regionIdent: 1,
    regionName: 'APAC',
    subRegionCode: 'SEA',
    subRegionName: 'Southeast Asia',
    clientIdent: 101,
    clientName: 'ABC Corporation APAC',
    securityGroupId: 'product-development',
    securityGroupName: 'Product Development',
    securityGroups: [{ id: 'product-development', name: 'Product Development' }],
  };

  const tenant = (overrides: Partial<GoogleDriveTenant> = {}): GoogleDriveTenant => ({
    tenantId: 'tenant-1',
    ownerKey: 'owner-1',
    displayName: 'Google Drive Test Folder',
    owner: 'Test User',
    regionIdent: 1,
    subRegionCode: 'ALL',
    clientIdent: 0,
    securityGroupId: '00000000-0000-0000-0000-000000000000',
    isActive: true,
    isDraft: false,
    createdOn: '2026-08-05T00:00:00Z',
    folderCount: 1,
    folders: [{
      tenantFolderId: 'tenant-folder-1',
      tenantId: 'tenant-1',
      folderId: 'folder-1',
      folderName: 'Test',
      permissionConfirmed: true,
      sortOrder: 0,
      isActive: true,
      createdOn: '2026-08-05T00:00:00Z',
    }],
    ...overrides,
  });

  it('includes an APAC All tenant for an APAC descendant hierarchy', () => {
    expect(googleDriveTenantMatchesHierarchy(tenant(), selectedHierarchy)).toBeTrue();
  });

  it('includes an exact hierarchy tenant', () => {
    expect(googleDriveTenantMatchesHierarchy(tenant({
      subRegionCode: 'SEA',
      clientIdent: 101,
      securityGroupId: 'product-development',
    }), selectedHierarchy)).toBeTrue();
  });

  it('excludes a tenant from another region', () => {
    expect(googleDriveTenantMatchesHierarchy(tenant({ regionIdent: 2 }), selectedHierarchy)).toBeFalse();
  });

  it('excludes a different explicit sub-region', () => {
    expect(googleDriveTenantMatchesHierarchy(tenant({ subRegionCode: 'ANZ' }), selectedHierarchy)).toBeFalse();
  });

  it('matches when the tenant belongs to any selected security group', () => {
    const selection = {
      ...selectedHierarchy,
      securityGroupId: 'group-one',
      securityGroups: [
        { id: 'group-one', name: 'Group One' },
        { id: 'group-two', name: 'Group Two' },
      ],
    };
    expect(googleDriveTenantMatchesHierarchy(tenant({
      securityGroupId: 'group-two',
      securityGroups: [{ id: 'group-two', name: 'Group Two' }],
    }), selection)).toBeTrue();
  });

  it('excludes a tenant when none of its security groups are selected', () => {
    expect(googleDriveTenantMatchesHierarchy(tenant({
      securityGroupId: 'another-group',
      securityGroups: [{ id: 'another-group', name: 'Another Group' }],
    }), selectedHierarchy)).toBeFalse();
  });
});
