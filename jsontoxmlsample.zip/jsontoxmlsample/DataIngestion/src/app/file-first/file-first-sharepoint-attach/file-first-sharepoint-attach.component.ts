import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  inject,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { firstValueFrom, Subscription } from 'rxjs';
import { WorkspaceConnectTenantHierarchyComponent } from '../../workspace-connect/core/workspace-connect-tenant-hierarchy.component';
import { SP_INTEGRATION } from '../../workspace-connect/core/workspace-connect.messages';
import {
  emptyTenantHierarchySelection,
  SharePointTenantHierarchyFilter,
  SharePointTenantHierarchySelection,
  tenantFilterFromClientInfo,
  tenantFiltersEqual,
} from '../../workspace-connect/core/workspace-connect.tenant';
import { SharePointItemDto } from '../../workspace-connect/core/workspace-connect.types';
import { WorkspaceConnectIconComponent } from '../../workspace-connect/core/workspace-connect.ui';
import { formatFileSize } from '../../workspace-connect/core/workspace-connect.utils';
import { SharePointApiService } from '../../workspace-connect/services/sharepoint-api.service';
import { SharePointUserApiService, SharePointUserAuthService } from '../../workspace-connect/services/sharepoint-user.service';
import { SharepointWorkspaceComponent } from '../../workspace-connect/sharepoint-workspace/sharepoint-workspace.component';

@Component({
  selector: 'app-file-first-sharepoint-attach',
  standalone: true,
  imports: [
    CommonModule,
    SharepointWorkspaceComponent,
    WorkspaceConnectIconComponent,
    WorkspaceConnectTenantHierarchyComponent,
  ],
  templateUrl: './file-first-sharepoint-attach.component.html',
  styleUrls: [
    '../../workspace-connect/workspace-connect-shell.css',
    './file-first-sharepoint-attach.component.css',
    '../../workspace-connect/workspace-connect.styles.css',
  ],
  host: {
    '[class.ff-viewer-open]': 'viewerOpen',
  },
})
export class FileFirstSharepointAttachComponent implements OnInit, OnChanges, OnDestroy {
  private readonly api = inject(SharePointApiService);
  private readonly userApi = inject(SharePointUserApiService);
  private readonly auth = inject(SharePointUserAuthService);

  readonly m = SP_INTEGRATION.fileFirst;

  @Input() clientInfoForm: FormGroup | null = null;
  @Input() allowAllFileTypes = false;
  @Input() externalBusy = false;
  @Output() fileSelected = new EventEmitter<File>();
  @Output() filesSelected = new EventEmitter<File[]>();
  @Output() back = new EventEmitter<void>();

  @ViewChild(SharepointWorkspaceComponent)
  protected workspace!: SharepointWorkspaceComponent;

  protected hierarchyFilter: SharePointTenantHierarchyFilter | null = null;
  protected hierarchySelection = emptyTenantHierarchySelection();
  protected fileLoading = false;
  protected batchDownloading = false;
  protected batchDownloadedCount = 0;
  protected batchTotalCount = 0;
  protected pendingSelections: SharePointItemDto[] = [];
  protected error = '';
  private _viewerOpen = false;
  private clientInfoSub?: Subscription;

  async ngOnInit(): Promise<void> {
    if (this.auth.isConfigured) await this.auth.initialize();
    this.initializeHierarchySelection();
    this.syncHierarchyFilter();
    this.bindClientInfoWatch();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['clientInfoForm']) {
      this.bindClientInfoWatch();
      this.syncHierarchyFilter();
    }
  }

  ngOnDestroy(): void {
    this.clientInfoSub?.unsubscribe();
  }

  protected get accessReady(): boolean {
    return !!(
      this.hierarchySelection.regionIdent &&
      this.hierarchySelection.subRegionCode?.trim() &&
      this.hierarchySelection.clientIdent &&
      this.hierarchySelection.securityGroupId?.trim()
    );
  }

  protected onHierarchySelectionChange(selection: SharePointTenantHierarchySelection): void {
    this.hierarchySelection = selection;
    this.clientInfoForm?.patchValue({
      RegionId: selection.regionIdent ?? '',
      SubRegionId: selection.subRegionCode ?? '',
      ClientId: selection.clientIdent ?? '',
      security_group: (selection.securityGroups ?? []).map((group) => ({
        id: group.id,
        displayName: group.name,
      })),
    }, { emitEvent: false });
    this.syncHierarchyFilter();
  }

  protected get selectedItem(): SharePointItemDto | null {
    return this.workspace?.selectedItem ?? null;
  }

  protected get hasFileSelected(): boolean {
    const item = this.selectedItem;
    return item != null && !item.isFolder && !this.fileLoading && !this.externalBusy;
  }

  protected get landingLayerMultiSelectMode(): boolean {
    return this.allowAllFileTypes;
  }

  protected get canAddCurrentSelection(): boolean {
    const item = this.selectedItem;
    if (!item || item.isFolder) return false;
    if (this.fileLoading || this.externalBusy || this.batchDownloading) return false;
    const path = item.path ?? item.name;
    return !this.pendingSelections.some((x) => (x.path ?? x.name) === path);
  }

  protected get canProceedSelections(): boolean {
    return this.pendingSelections.length > 0 && !this.fileLoading && !this.externalBusy && !this.batchDownloading;
  }

  protected get viewerOpen(): boolean {
    return this._viewerOpen;
  }

  protected onViewerOpenChange(open: boolean): void {
    this._viewerOpen = open;
  }

  protected formatSize(bytes: number): string {
    return formatFileSize(bytes);
  }

  protected async useSelectedFile(): Promise<void> {
    const item = this.workspace?.selectedItem;
    if (!item || item.isFolder) return;

    if (this.landingLayerMultiSelectMode) {
      this.addCurrentSelection();
      this.workspace?.closeViewer();
      return;
    }

    if (this.fileLoading || this.externalBusy) return;

    this.workspace?.closeViewer();
    this.fileLoading = true;
    this.error = '';

    const filePath = item.path ?? item.name;

    try {
      const blob = await this.fetchSelectedFileBlob(filePath);
      this.fileSelected.emit(new File([blob], item.name, {
        type: blob.type || 'application/octet-stream',
      }));
    } catch (error: unknown) {
      console.error('[SharePoint File Pick] Could not fetch selected file', { filePath, error });
      this.error = this.m.downloadFailed;
    } finally {
      this.fileLoading = false;
    }
  }

  protected goBack(): void {
    this.back.emit();
  }

  protected addCurrentSelection(): void {
    if (!this.canAddCurrentSelection) return;
    const item = this.selectedItem;
    if (!item) return;
    this.pendingSelections = [...this.pendingSelections, item];
    this.error = '';
  }

  protected removePendingSelection(index: number): void {
    if (this.batchDownloading) return;
    this.pendingSelections = this.pendingSelections.filter((_, i) => i !== index);
  }

  protected clearPendingSelections(): void {
    if (this.batchDownloading) return;
    this.pendingSelections = [];
  }

  protected async proceedWithSelections(): Promise<void> {
    if (!this.canProceedSelections) return;

    const queue = [...this.pendingSelections];
    const files: File[] = [];
    const failed: string[] = [];

    this.batchDownloading = true;
    this.batchDownloadedCount = 0;
    this.batchTotalCount = queue.length;
    this.error = '';

    try {
      for (let i = 0; i < queue.length; i++) {
        const item = queue[i];
        const filePath = item.path ?? item.name;
        try {
          const blob = await this.fetchSelectedFileBlob(filePath);
          files.push(new File([blob], item.name, {
            type: blob.type || 'application/octet-stream',
          }));
        } catch (error: unknown) {
          console.error('[SharePoint File Pick] Could not fetch selected file in batch', {
            filePath,
            error,
          });
          failed.push(item.name);
        } finally {
          this.batchDownloadedCount = i + 1;
        }
      }

      if (files.length) {
        this.filesSelected.emit(files);
      }
      if (failed.length) {
        this.error = `${this.m.downloadFailed} (${failed.length} file${failed.length > 1 ? 's' : ''} failed).`;
      }
      if (!failed.length) {
        this.pendingSelections = [];
      }
    } finally {
      this.batchDownloading = false;
    }
  }

  private bindClientInfoWatch(): void {
    this.clientInfoSub?.unsubscribe();
    this.clientInfoSub = this.clientInfoForm?.valueChanges.subscribe(() => {
      this.syncHierarchyFilter();
    });
  }

  private initializeHierarchySelection(): void {
    const value = this.clientInfoForm?.value ?? {};
    const formGroups = Array.isArray(value.security_group) ? value.security_group : [];
    const securityGroups = formGroups
      .map((group: { id?: string; securityGroupId?: string; displayName?: string; securityGroupName?: string }) => ({
        id: group.securityGroupId ?? group.id ?? '',
        name: group.securityGroupName ?? group.displayName ?? '',
      }))
      .filter((group: { id: string; name: string }) => !!group.id);

    if (!securityGroups.length) {
      const id = sessionStorage.getItem('GUID')?.trim();
      const name = sessionStorage.getItem('UserDefaultGroup')?.trim();
      if (id) securityGroups.push({ id, name: name || id });
    }

    const regionIdent = Number(value.RegionId);
    const clientIdent = Number(value.ClientId);
    const primaryGroup = securityGroups[0] ?? null;
    this.hierarchySelection = {
      regionIdent: Number.isFinite(regionIdent) && regionIdent > 0 ? regionIdent : null,
      regionName: value.RegionName ?? '',
      subRegionCode: value.SubRegionId ? String(value.SubRegionId) : '',
      subRegionName: value.SubRegionName ?? '',
      clientIdent: Number.isFinite(clientIdent) && clientIdent > 0 ? clientIdent : null,
      clientName: value.ClientName ?? '',
      securityGroupId: primaryGroup?.id ?? null,
      securityGroupName: primaryGroup?.name ?? '',
      securityGroups,
    };

    if (!formGroups.length && securityGroups.length) {
      this.clientInfoForm?.patchValue({
        security_group: securityGroups.map((group) => ({ id: group.id, displayName: group.name })),
      }, { emitEvent: false });
    }
  }

  private syncHierarchyFilter(): void {
    const next = tenantFilterFromClientInfo(this.clientInfoForm?.value ?? null);
    if (tenantFiltersEqual(this.hierarchyFilter, next)) return;
    this.hierarchyFilter = next;
  }

  private async fetchSelectedFileBlob(filePath: string): Promise<Blob> {
    const fetchOnce = () => this.workspace?.isModeUser
      ? firstValueFrom(this.userApi.fetchFileBlob(this.workspace.selectedUserLibraryDriveId(), filePath))
      : firstValueFrom(this.api.fetchFileBlob(this.workspace.workspaceConnection, filePath));

    try {
      return await fetchOnce();
    } catch {
      return await fetchOnce();
    }
  }
}
