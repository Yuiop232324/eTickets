import { Component, inject } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { WorkspaceConnectIconComponent } from './workspace-connect.ui';
import { DUPLICATE_TENANT_MESSAGE } from './workspace-connect.utils';

@Component({
  selector: 'app-duplicate-tenant-modal',
  standalone: true,
  imports: [WorkspaceConnectIconComponent],
  template: `
    <section class="duplicate-modal" role="alertdialog" aria-modal="true" aria-labelledby="duplicate-modal-title" aria-describedby="duplicate-modal-message">
      <button type="button" class="duplicate-modal__close" aria-label="Close" (click)="activeModal.close()">
        <sp-icon name="x" size="sm" />
      </button>
      <span class="duplicate-modal__icon"><sp-icon name="alert" size="lg" /></span>
      <h2 id="duplicate-modal-title">Tenant already registered</h2>
      <p id="duplicate-modal-message">{{ message }}</p>
      <button type="button" class="duplicate-modal__action" (click)="activeModal.close()">Change tenant name</button>
    </section>
  `,
  styles: [`
    :host { display: block; }
    .duplicate-modal { position: relative; padding: 30px; color: #172033; text-align: center; }
    .duplicate-modal__icon { display: inline-grid; place-items: center; width: 58px; height: 58px; margin-bottom: 16px; border-radius: 50%; background: #fef2f2; color: #dc2626; }
    h2 { margin: 0 34px 10px; font-size: 21px; font-weight: 700; }
    p { margin: 0 0 24px; color: #5b6475; font-size: 14px; line-height: 1.55; }
    .duplicate-modal__close { position: absolute; top: 14px; right: 14px; display: inline-grid; place-items: center; width: 32px; height: 32px; border: 0; border-radius: 50%; background: transparent; color: #64748b; }
    .duplicate-modal__close:hover { background: #f1f5f9; }
    .duplicate-modal__action { min-width: 170px; min-height: 42px; padding: 10px 20px; border: 0; border-radius: 10px; background: #253b91; color: #fff; font-weight: 700; }
    .duplicate-modal__action:hover { background: #1e327e; }
  `],
})
export class DuplicateTenantModalComponent {
  readonly activeModal = inject(NgbActiveModal);
  readonly message = DUPLICATE_TENANT_MESSAGE;
}
