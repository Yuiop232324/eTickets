import { Injectable, inject } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DuplicateTenantModalComponent } from './duplicate-tenant-modal.component';

@Injectable({ providedIn: 'root' })
export class DuplicateTenantModalService {
  private readonly modal = inject(NgbModal);

  open(): void {
    this.modal.open(DuplicateTenantModalComponent, {
      backdrop: 'static',
      centered: true,
      keyboard: true,
      windowClass: 'workspace-connect-duplicate-modal',
    });
  }
}
