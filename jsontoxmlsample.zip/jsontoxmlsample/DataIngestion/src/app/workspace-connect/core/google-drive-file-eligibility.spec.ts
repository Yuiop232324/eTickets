import {
    googleDriveEffectiveFileName,
    isGoogleDriveDownloadableFile,
    isGoogleDriveProcessFile,
    isGoogleDriveWorkspaceItemVisible,
} from './google-drive-file-eligibility';
import { GoogleDriveItem } from './google-drive-workspace.types';

describe('Google Drive file eligibility', () => {
    const item = (overrides: Partial<GoogleDriveItem> = {}): GoogleDriveItem => ({
        id: 'file-1',
        name: 'source.csv',
        downloadName: 'source.csv',
        mimeType: 'text/csv',
        parentIds: ['root'],
        isFolder: false,
        isShortcut: false,
        isTrashed: false,
        ...overrides,
    });

    it('uses the normalized exported name for native Google files', () => {
        const sheet = item({
            name: 'Native Sheet',
            downloadName: 'Native Sheet.xlsx',
            mimeType: 'application/vnd.google-apps.spreadsheet',
        });

        expect(googleDriveEffectiveFileName(sheet)).toBe('Native Sheet.xlsx');
        expect(isGoogleDriveProcessFile(sheet)).toBeTrue();
    });

    it('rejects unsupported process file types', () => {
        expect(isGoogleDriveProcessFile(item({ name: 'photo.png', downloadName: 'photo.png', mimeType: 'image/png' }))).toBeFalse();
    });

    it('rejects shortcuts even when their names have supported extensions', () => {
        expect(isGoogleDriveProcessFile(item({ isShortcut: true }))).toBeFalse();
    });

    it('shows only structured files when the destination restriction is enabled', () => {
        expect(isGoogleDriveWorkspaceItemVisible(item(), true)).toBeTrue();
        expect(isGoogleDriveWorkspaceItemVisible(item({ name: 'document.pdf', downloadName: 'document.pdf' }), true)).toBeFalse();
        expect(isGoogleDriveWorkspaceItemVisible(item({ isFolder: true }), true)).toBeTrue();
    });

    it('adds JSON/XML only for the isolated structured sample picker', () => {
        const json = item({ name: 'records.json', downloadName: 'records.json', mimeType: 'application/json' });
        expect(isGoogleDriveWorkspaceItemVisible(json, true, true)).toBeFalse();
        expect(isGoogleDriveWorkspaceItemVisible(json, true, true, true)).toBeTrue();
    });

    it('shows all downloadable file types for Landing Layer', () => {
        expect(isGoogleDriveWorkspaceItemVisible(item({ name: 'document.pdf', downloadName: 'document.pdf' }), false, true)).toBeTrue();
        expect(isGoogleDriveWorkspaceItemVisible(item({ isShortcut: true }), false, true)).toBeFalse();
    });

    it('hides Google-native types that the Drive export API cannot download', () => {
        expect(isGoogleDriveDownloadableFile(item({ mimeType: 'application/vnd.google-apps.form' }))).toBeFalse();
        expect(isGoogleDriveWorkspaceItemVisible(item({ mimeType: 'application/vnd.google-apps.form' }), false, true)).toBeFalse();
    });
});
