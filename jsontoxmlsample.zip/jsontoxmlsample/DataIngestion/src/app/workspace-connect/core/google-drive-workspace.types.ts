export interface GoogleDriveApiEnvelope<T> {
  success: boolean;
  message: string;
  data: T;
}

export interface GoogleDriveWorkspaceConnection {
  isConnected: boolean;
  folderId: string;
  folderName: string;
  webViewLink?: string | null;
  driveId?: string | null;
  message: string;
}

export interface GoogleDriveItem {
  id: string;
  name: string;
  downloadName?: string;
  mimeType: string;
  size?: number | null;
  modifiedTime?: string | null;
  webViewLink?: string | null;
  parentIds: string[];
  isFolder: boolean;
  isShortcut: boolean;
  isTrashed: boolean;
}

export interface GoogleDriveFolderTrailItem {
  id: string;
  name: string;
}

export interface GoogleDriveConnectorInfo {
  serviceAccountEmail: string;
  connectorMode: 'Internal' | string;
  requiredPermission: string;
  permissionGuidance: string;
}

export interface GoogleDriveTenant {
  pageOrdinal?: number;
  tenantId: string;
  ownerKey: string;
  displayName: string;
  owner: string;
  ownerUpn?: string | null;
  coOwner?: string | null;
  coOwnerUpn?: string | null;
  notes?: string | null;
  regionIdent?: number | null;
  regionName?: string | null;
  subRegionCode?: string | null;
  subRegionName?: string | null;
  clientIdent?: number | null;
  clientName?: string | null;
  securityGroupId?: string | null;
  securityGroupName?: string | null;
  securityGroups?: Array<{ id: string; name: string }>;
  isActive: boolean;
  isDraft: boolean;
  createdOn: string;
  modifiedOn?: string | null;
  folderCount: number;
  folders: GoogleDriveTenantFolder[];
}

export interface GoogleDriveTenantFolder {
  tenantFolderId: string;
  tenantId: string;
  folderId: string;
  folderName: string;
  folderWebViewLink?: string | null;
  driveId?: string | null;
  permissionConfirmed: boolean;
  permissionConfirmedOn?: string | null;
  sortOrder: number;
  isActive: boolean;
  createdOn: string;
  modifiedOn?: string | null;
}

export interface SaveGoogleDriveTenantFolderRequest {
  folderUrlOrId?: string | null;
  permissionConfirmed: boolean;
}

export interface SaveGoogleDriveTenantRequest {
  tenantId?: string | null;
  ownerKey: string;
  displayName: string;
  owner: string;
  ownerUpn?: string | null;
  coOwner?: string | null;
  coOwnerUpn?: string | null;
  notes?: string | null;
  regionIdent?: number | null;
  regionName?: string | null;
  subRegionCode?: string | null;
  subRegionName?: string | null;
  clientIdent?: number | null;
  clientName?: string | null;
  securityGroupId?: string | null;
  securityGroupName?: string | null;
  securityGroups?: Array<{ id: string; name: string }>;
  isActive: boolean;
  isDraft: boolean;
  folders: SaveGoogleDriveTenantFolderRequest[];
}

export interface ValidateGoogleDriveWorkspaceRequest {
  workspaceUrlOrId: string;
}

export interface BrowseGoogleDriveTenantRequest {
  tenantFolderId: string;
  folderId?: string;
}

export interface BrowseGoogleDriveWorkspaceRequest {
  workspaceUrlOrId: string;
  folderId?: string;
}

export interface CreateGoogleDriveFolderRequest {
  workspaceUrlOrId: string;
  parentFolderId: string;
  folderName: string;
}

export interface DownloadGoogleDriveFileRequest {
  workspaceUrlOrId: string;
  fileId: string;
}

export interface MoveGoogleDriveFileRequest extends DownloadGoogleDriveFileRequest {
  destinationFolderId: string;
}

export interface DeleteGoogleDriveItemRequest {
  workspaceUrlOrId: string;
  itemId: string;
}

export type GoogleDriveDisplayMode = 'grid' | 'list';
export type GoogleDriveSortMode = 'name' | 'modified' | 'size';
