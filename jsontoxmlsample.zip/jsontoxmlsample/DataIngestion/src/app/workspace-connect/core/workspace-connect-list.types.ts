import { GoogleDriveTenant } from './google-drive-workspace.types';
import { SharePointTenantHierarchySelection } from './workspace-connect.tenant';
import { ApplicationDto } from './workspace-connect.types';

export type ConnectorListFilter = 'all' | 'sharepoint' | 'google-drive';
export type ConnectorListStatus = 'all' | 'active' | 'inactive' | 'draft';
export type ConnectorListProfile = 'all' | 'internal' | 'external' | 'user';

export interface WorkspaceConnectListQuery {
  pageNumber: number;
  pageSize: number;
  connector: ConnectorListFilter;
  status: ConnectorListStatus;
  profile: ConnectorListProfile;
  searchTerm?: string;
  hierarchy?: SharePointTenantHierarchySelection;
}

export interface WorkspaceConnectMonthlyCount {
  year: number;
  month: number;
  sharePoint: number;
  googleDrive: number;
}

export interface WorkspaceConnectTenantPage {
  applications: ApplicationDto[];
  tenants: GoogleDriveTenant[];
  pageNumber: number;
  pageSize: number;
  filteredCount: number;
  totalCount: number;
  sharePointCount: number;
  googleDriveCount: number;
  activeCount: number;
  draftCount: number;
  inactiveCount: number;
  monthlyCounts: WorkspaceConnectMonthlyCount[];
}
