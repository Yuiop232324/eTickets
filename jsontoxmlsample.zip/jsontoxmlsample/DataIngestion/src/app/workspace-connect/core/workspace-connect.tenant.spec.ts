import {
  tenantFilterFromClientInfo,
  tenantHierarchySelectionFromDto,
} from './workspace-connect.tenant';

describe('Workspace Connect tenant security groups', () => {
  it('restores every saved security group for edit', () => {
    const selection = tenantHierarchySelectionFromDto({
      securityGroupId: 'group-one',
      securityGroupName: 'Group One',
      securityGroups: [
        { id: 'group-one', name: 'Group One' },
        { id: 'group-two', name: 'Group Two' },
      ],
    });

    expect(selection.securityGroups).toEqual([
      { id: 'group-one', name: 'Group One' },
      { id: 'group-two', name: 'Group Two' },
    ]);
  });

  it('passes every selected Configuration First security group to tenant filtering', () => {
    const filter = tenantFilterFromClientInfo({
      RegionId: 1,
      SubRegionId: 'ALL',
      ClientId: 0,
      security_group: [
        { id: 'group-one', displayName: 'Group One' },
        { securityGroupId: 'group-two', securityGroupName: 'Group Two' },
      ],
    });

    expect(filter?.securityGroupIds).toEqual(['group-one', 'group-two']);
    expect(filter?.securityGroupId).toBe('group-one');
  });
});
