import { DUPLICATE_TENANT_MESSAGE, parseApiError } from './workspace-connect.utils';

describe('parseApiError', () => {
  it('shows a user-friendly tenant message for duplicate conflicts', () => {
    expect(parseApiError({ status: 409, message: 'Http failure response for /api/applications: 409 OK' }, 'Failed to save.'))
      .toBe(DUPLICATE_TENANT_MESSAGE);
    expect(parseApiError(new Error('Http failure response for /api/applications: 409 OK'), 'Failed to save.'))
      .toBe(DUPLICATE_TENANT_MESSAGE);
  });

  it('keeps an API message for non-conflict errors', () => {
    expect(parseApiError({ status: 400, error: { message: 'Select an owner.' } }, 'Failed to save.'))
      .toBe('Select an owner.');
  });
});
