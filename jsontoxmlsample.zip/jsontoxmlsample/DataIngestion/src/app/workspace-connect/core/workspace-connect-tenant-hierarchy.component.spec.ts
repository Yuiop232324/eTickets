import { SimpleChange } from '@angular/core';
import { By } from '@angular/platform-browser';
import { TestBed } from '@angular/core/testing';
import { NgSelectComponent } from '@ng-select/ng-select';
import { of } from 'rxjs';
import { SharePointTenantHierarchyService } from '../services/sharepoint-tenant-hierarchy.service';
import { WorkspaceConnectTenantHierarchyComponent } from './workspace-connect-tenant-hierarchy.component';

describe('WorkspaceConnectTenantHierarchyComponent', () => {
  it('renders hierarchy dropdown panels outside clipped configuration containers', async () => {
    await TestBed.configureTestingModule({
      imports: [WorkspaceConnectTenantHierarchyComponent],
      providers: [{
        provide: SharePointTenantHierarchyService,
        useValue: {
          loadRegions: () => of([]), loadSubRegions: () => of([]), loadClients: () => of([]), searchSecurityGroups: () => of([]),
        },
      }],
    }).compileComponents();
    const fixture = TestBed.createComponent(WorkspaceConnectTenantHierarchyComponent);
    fixture.detectChanges();

    const dropdowns = fixture.debugElement.queryAll(By.directive(NgSelectComponent));
    expect(dropdowns.length).toBe(3);
    expect(dropdowns.every(dropdown => dropdown.componentInstance.appendTo === 'body')).toBeTrue();
    expect(dropdowns.every(dropdown => dropdown.componentInstance.dropdownPosition === 'auto')).toBeTrue();
  });

  it('preserves region, sub-region, and client when security groups change', async () => {
    await TestBed.configureTestingModule({
      imports: [WorkspaceConnectTenantHierarchyComponent],
      providers: [{
        provide: SharePointTenantHierarchyService,
        useValue: {
          loadRegions: () => of([]), loadSubRegions: () => of([]), loadClients: () => of([]), searchSecurityGroups: () => of([]),
        },
      }],
    }).compileComponents();
    const fixture = TestBed.createComponent(WorkspaceConnectTenantHierarchyComponent);
    const component = fixture.componentInstance;
    component.selection = {
      regionIdent: 1, regionName: 'APAC', subRegionCode: 'SEA', subRegionName: 'Southeast Asia',
      clientIdent: 7, clientName: 'Client', securityGroupId: null, securityGroupName: 'All', securityGroups: [],
    };
    fixture.detectChanges();

    component.selectSecurityGroup({ id: 'group-1', name: 'Group 1' });
    component.removeSecurityGroup('group-1');

    expect(component.selection.regionIdent).toBe(1);
    expect(component.selection.subRegionCode).toBe('SEA');
    expect(component.selection.clientIdent).toBe(7);
  });

  it('shows the five-character search guidance and all-groups warning inline', async () => {
    await TestBed.configureTestingModule({
      imports: [WorkspaceConnectTenantHierarchyComponent],
      providers: [{
        provide: SharePointTenantHierarchyService,
        useValue: {
          loadRegions: () => of([]), loadSubRegions: () => of([]), loadClients: () => of([]), searchSecurityGroups: () => of([]),
        },
      }],
    }).compileComponents();
    const fixture = TestBed.createComponent(WorkspaceConnectTenantHierarchyComponent);
    fixture.detectChanges();

    fixture.componentInstance.onSecurityGroupSearch('four');
    fixture.detectChanges();

    const text = fixture.nativeElement.textContent;
    expect(text).toContain('Minimum of 5 characters to start searching');
    expect(text).toContain('this tenant will be available to all security groups');
  });

  it('shows a no-results message after a completed security-group search', async () => {
    await TestBed.configureTestingModule({
      imports: [WorkspaceConnectTenantHierarchyComponent],
      providers: [{
        provide: SharePointTenantHierarchyService,
        useValue: {
          loadRegions: () => of([]), loadSubRegions: () => of([]), loadClients: () => of([]), searchSecurityGroups: () => of([]),
        },
      }],
    }).compileComponents();
    const fixture = TestBed.createComponent(WorkspaceConnectTenantHierarchyComponent);
    fixture.detectChanges();

    fixture.componentInstance.onSecurityGroupSearch('missing');
    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain('No results found.');
  });

  it('does not reload sub-regions or clients for a security-group-only input change', async () => {
    const loadSubRegions = jasmine.createSpy('loadSubRegions').and.returnValue(of([]));
    const loadClients = jasmine.createSpy('loadClients').and.returnValue(of([]));
    await TestBed.configureTestingModule({
      imports: [WorkspaceConnectTenantHierarchyComponent],
      providers: [{
        provide: SharePointTenantHierarchyService,
        useValue: {
          loadRegions: () => of([]), loadSubRegions, loadClients, searchSecurityGroups: () => of([]),
        },
      }],
    }).compileComponents();
    const fixture = TestBed.createComponent(WorkspaceConnectTenantHierarchyComponent);
    const component = fixture.componentInstance;
    const previous = {
      regionIdent: 1, regionName: 'APAC', subRegionCode: 'SEA', subRegionName: 'Southeast Asia',
      clientIdent: 7, clientName: 'Client', securityGroupId: null, securityGroupName: 'All', securityGroups: [],
    };
    component.selection = previous;
    fixture.detectChanges();
    const subRegionCalls = loadSubRegions.calls.count();
    const clientCalls = loadClients.calls.count();
    const current = {
      ...previous,
      securityGroupId: 'group-1',
      securityGroupName: 'Group 1',
      securityGroups: [{ id: 'group-1', name: 'Group 1' }],
    };

    component.selection = current;
    component.ngOnChanges({ selection: new SimpleChange(previous, current, false) });

    expect(loadSubRegions.calls.count()).toBe(subRegionCalls);
    expect(loadClients.calls.count()).toBe(clientCalls);
  });
});
