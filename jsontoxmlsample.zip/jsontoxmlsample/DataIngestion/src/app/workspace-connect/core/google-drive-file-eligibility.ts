import { isTabularPreviewFileName } from '../../shared/tabular-preview-file';
import { isStructuredPreviewFileName } from '../../shared/structured-files/structured-preview-file';
import { GoogleDriveItem } from './google-drive-workspace.types';

const GOOGLE_NATIVE_MIME_PREFIX = 'application/vnd.google-apps.';
const DOWNLOADABLE_GOOGLE_NATIVE_MIME_TYPES = new Set([
    'application/vnd.google-apps.document',
    'application/vnd.google-apps.spreadsheet',
    'application/vnd.google-apps.presentation',
    'application/vnd.google-apps.drawing',
    'application/vnd.google-apps.script',
]);

export function googleDriveEffectiveFileName(item: Pick<GoogleDriveItem, 'name' | 'downloadName'>): string {
    return item.downloadName?.trim() || item.name;
}

export function isGoogleDriveProcessFile(item: GoogleDriveItem): boolean {
    if (item.isFolder || item.isShortcut || item.isTrashed) return false;
    return isTabularPreviewFileName(googleDriveEffectiveFileName(item));
}

export function isGoogleDriveDownloadableFile(item: GoogleDriveItem): boolean {
    if (item.isFolder || item.isShortcut || item.isTrashed) return false;
    const mimeType = item.mimeType?.trim().toLowerCase() ?? '';
    return !mimeType.startsWith(GOOGLE_NATIVE_MIME_PREFIX) || DOWNLOADABLE_GOOGLE_NATIVE_MIME_TYPES.has(mimeType);
}

export function isGoogleDriveWorkspaceItemVisible(
    item: GoogleDriveItem,
    restrictToProcessFiles: boolean,
    fileSelectionMode = false,
    // #region Structured JSON/XML files
    allowStructuredFiles = false,
    // #endregion
): boolean {
    if (item.isShortcut) return false;
    if (fileSelectionMode && !item.isFolder && !isGoogleDriveDownloadableFile(item)) return false;
    return !restrictToProcessFiles || item.isFolder || isGoogleDriveProcessFile(item)
        // #region Structured JSON/XML files
        || (allowStructuredFiles && isStructuredPreviewFileName(googleDriveEffectiveFileName(item)));
        // #endregion
}
