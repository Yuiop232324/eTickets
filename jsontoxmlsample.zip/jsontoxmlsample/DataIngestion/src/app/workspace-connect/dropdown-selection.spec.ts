import { Component, ViewEncapsulation } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { NgxSelectDropdownComponent, SelectDropDownModule } from 'ngx-select-dropdown';
import { SP_LIBRARY_DROPDOWN_CONFIG, SP_SITE_DROPDOWN_CONFIG } from './core/workspace-connect.utils';
import { SharepointWorkspaceComponent } from './sharepoint-workspace/sharepoint-workspace.component';

@Component({
  standalone: true,
  imports: [FormsModule, SelectDropDownModule],
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./workspace-connect.styles.css'],
  template: `<div class="sp-ngx-dropdown sp-ngx-dropdown--open">
    <ngx-select-dropdown [(ngModel)]="selected" [options]="options" [config]="config" />
  </div>`
})
class DropdownTestHost {
  options = [{ id: 'first', label: 'First' }, { id: 'second', label: 'Second' }];
  selected: any = this.options[1];
  config = SP_SITE_DROPDOWN_CONFIG;
}

describe('SharePoint dropdown current selection', () => {
  for (const [name, config] of [['Site', SP_SITE_DROPDOWN_CONFIG], ['Library', SP_LIBRARY_DROPDOWN_CONFIG]] as const) {
    it(`${name} keeps its selected row visible when reopened and after a change`, async () => {
      await TestBed.configureTestingModule({ imports: [DropdownTestHost] }).compileComponents();
      const fixture = TestBed.createComponent(DropdownTestHost);
      fixture.componentInstance.config = config;
      fixture.detectChanges();
      await fixture.whenStable();
      fixture.detectChanges();
      const dropdown = fixture.debugElement.query(By.directive(NgxSelectDropdownComponent)).componentInstance as NgxSelectDropdownComponent;
      for (let attempt = 0; attempt < 2; attempt++) {
        dropdown.openSelectDropdown(); fixture.detectChanges();
        const row = fixture.nativeElement.querySelector('.selected-item') as HTMLElement;
        expect(row?.textContent).toContain('Second');
        expect(getComputedStyle(row.parentElement!).display).not.toBe('none');
        expect(row.getBoundingClientRect().height).toBeGreaterThan(0);
        dropdown.closeSelectDropdown(); fixture.detectChanges();
      }
      dropdown.openSelectDropdown(); fixture.detectChanges();
      (fixture.nativeElement.querySelector('.available-item') as HTMLElement).click();
      fixture.detectChanges(); await fixture.whenStable();
      dropdown.openSelectDropdown(); fixture.detectChanges();
      expect(fixture.nativeElement.querySelector('.selected-item')?.textContent).toContain('First');
    });
  }
});

describe('SharePoint process configuration dropdown clears', () => {
  function workspace(): any {
    const component: any = Object.create(SharepointWorkspaceComponent.prototype);
    component.processConfigMode = true;
    component.filePickMode = true;
    component.workspaceConnection = { applicationId: 'app', libraryName: 'Documents' };
    component.notifyProcessConfigSelectionChange = jasmine.createSpy('notifyProcessConfigSelectionChange');
    component.refreshView = jasmine.createSpy('refreshView');
    component.disconnectWorkspace = jasmine.createSpy('disconnectWorkspace').and.callFake(() => {
      component.workspaceConnection = {};
    });
    component.rebuildFilePickSiteDropdownOptions = jasmine.createSpy('rebuildFilePickSiteDropdownOptions');
    return component;
  }

  it('emits an invalid selection when Application or Site is cleared', () => {
    const application = workspace();
    application.selectedFilePickAppId = 'app';
    application.selectedFilePickSiteIndex = 0;
    application.onFilePickAppSelect(null);
    expect(application.notifyProcessConfigSelectionChange).toHaveBeenCalled();

    const site = workspace();
    site.selectedFilePickSiteIndex = 0;
    site.onFilePickSiteSelect(null);
    expect(site.notifyProcessConfigSelectionChange).toHaveBeenCalled();
  });

  it('clears the stored library and emits an invalid selection when Library is cleared', () => {
    const component = workspace();
    component.selectedLibraryDropdown = { id: 'Documents' };
    component.items = [{}];
    component.currentPath = 'folder';
    component.breadcrumbs = [{}];
    component.browsing = true;
    component.resetNavigationHistory = jasmine.createSpy('resetNavigationHistory');
    component.closeViewer = jasmine.createSpy('closeViewer');
    component.status = { clear: jasmine.createSpy('clear') };

    component.onFilePickLibraryDropdownModelChange(null);

    expect(component.workspaceConnection.libraryName).toBe('');
    expect(component.notifyProcessConfigSelectionChange).toHaveBeenCalled();
  });

  it('does not produce a process selection without a selected Site', () => {
    const component = workspace();
    component.workspaceConnected = true;
    component.selectedFilePickSite = () => undefined;
    expect(component.processConfigurationSelection()).toBeNull();
  });
});
