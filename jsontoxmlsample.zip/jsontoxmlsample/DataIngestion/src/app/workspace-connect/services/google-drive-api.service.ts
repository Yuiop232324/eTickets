import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable, switchMap, take, timeout } from 'rxjs';
import { TokenService } from '../../core/services/token.service';
import { environment } from '../../environments/environment';
import {
  BrowseGoogleDriveTenantRequest,
  BrowseGoogleDriveWorkspaceRequest,
  CreateGoogleDriveFolderRequest,
  DeleteGoogleDriveItemRequest,
  DownloadGoogleDriveFileRequest,
  GoogleDriveApiEnvelope,
  GoogleDriveConnectorInfo,
  GoogleDriveItem,
  GoogleDriveTenant,
  GoogleDriveTenantFolder,
  SaveGoogleDriveTenantRequest,
  GoogleDriveWorkspaceConnection,
  MoveGoogleDriveFileRequest,
  ValidateGoogleDriveWorkspaceRequest,
} from '../core/google-drive-workspace.types';
import { CONNECTOR_HTTP, GOOGLE_DRIVE_API } from '../core/workspace-connect.messages';
import type { SharePointTenantHierarchyFilter } from '../core/workspace-connect.tenant';

@Injectable({ providedIn: 'root' })
export class GoogleDriveApiService {
  private readonly http = inject(HttpClient);
  private readonly tokenService = inject(TokenService);
  private readonly baseUrl = `${environment.apiEndpoint.replace(/\/$/, '')}/api/GoogleDrive`;

  validateWorkspace(workspaceUrlOrId: string): Observable<GoogleDriveWorkspaceConnection> {
    const request: ValidateGoogleDriveWorkspaceRequest = { workspaceUrlOrId };
    return this.withToken((headers) =>
      this.http.post<GoogleDriveApiEnvelope<GoogleDriveWorkspaceConnection>>(
          `${this.baseUrl}/validate`,
          request,
          { headers: this.jsonHeaders(headers) },
        )
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  getConnectorInfo(): Observable<GoogleDriveConnectorInfo> {
    return this.withToken((headers) =>
      this.http.get<GoogleDriveApiEnvelope<GoogleDriveConnectorInfo>>(`${this.baseUrl}/connector-info`, { headers })
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  getTenants(includeInactive = true, filter?: SharePointTenantHierarchyFilter): Observable<GoogleDriveTenant[]> {
    const params: Record<string, string | boolean | number> = { includeInactive };
    if (filter?.regionIdent) params['regionIdent'] = filter.regionIdent;
    if (filter?.subRegionCode) params['subRegionCode'] = filter.subRegionCode;
    if (filter?.clientIdent) params['clientIdent'] = filter.clientIdent;
    if (filter?.securityGroupId) params['securityGroupId'] = filter.securityGroupId;
    if (filter?.securityGroupIds?.length) params['securityGroupIds'] = filter.securityGroupIds.join(',');
    return this.withToken((headers) =>
      this.http.get<GoogleDriveApiEnvelope<GoogleDriveTenant[]>>(
          `${this.baseUrl}/tenants`,
          { headers, params },
        )
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  saveTenant(request: SaveGoogleDriveTenantRequest): Observable<GoogleDriveTenant> {
    return this.withToken((headers) =>
      this.http.post<GoogleDriveApiEnvelope<GoogleDriveTenant>>(
          `${this.baseUrl}/tenants`,
          request,
          { headers: this.jsonHeaders(headers) },
        )
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  getTenant(tenantId: string): Observable<GoogleDriveTenant> {
    return this.withToken((headers) =>
      this.http.get<GoogleDriveApiEnvelope<GoogleDriveTenant>>(`${this.baseUrl}/tenants/${tenantId}`, { headers })
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  deactivateTenant(tenantId: string): Observable<boolean> {
    return this.withToken((headers) =>
      this.http.delete<GoogleDriveApiEnvelope<boolean>>(`${this.baseUrl}/tenants/${tenantId}`, { headers })
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  browseTenantFolder(tenantId: string, folder: GoogleDriveTenantFolder, folderId?: string): Observable<GoogleDriveItem[]> {
    const request: BrowseGoogleDriveTenantRequest = {
      tenantFolderId: folder.tenantFolderId,
      folderId: folderId || undefined,
    };
    return this.withToken((headers) =>
      this.http.post<GoogleDriveApiEnvelope<GoogleDriveItem[]>>(
          `${this.baseUrl}/tenants/${tenantId}/browse`,
          request,
          { headers: this.jsonHeaders(headers) },
        )
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  browseFolder(workspaceUrlOrId: string, folderId?: string): Observable<GoogleDriveItem[]> {
    const request: BrowseGoogleDriveWorkspaceRequest = { workspaceUrlOrId, folderId: folderId || undefined };
    return this.withToken((headers) =>
      this.http.post<GoogleDriveApiEnvelope<GoogleDriveItem[]>>(
          `${this.baseUrl}/browse`,
          request,
          { headers: this.jsonHeaders(headers) },
        )
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  createFolder(workspaceUrlOrId: string, parentFolderId: string, folderName: string): Observable<GoogleDriveItem> {
    const request: CreateGoogleDriveFolderRequest = { workspaceUrlOrId, parentFolderId, folderName };
    return this.withToken((headers) =>
      this.http.post<GoogleDriveApiEnvelope<GoogleDriveItem>>(
          `${this.baseUrl}/createfolder`,
          request,
          { headers: this.jsonHeaders(headers) },
        )
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  uploadFile(workspaceUrlOrId: string, parentFolderId: string, file: File): Observable<GoogleDriveItem> {
    const payload = new FormData();
    payload.append(GOOGLE_DRIVE_API.workspaceReferenceField, workspaceUrlOrId);
    payload.append(GOOGLE_DRIVE_API.parentFolderIdField, parentFolderId);
    payload.append(GOOGLE_DRIVE_API.fileField, file, file.name);

    return this.withToken((headers) =>
      this.http.post<GoogleDriveApiEnvelope<GoogleDriveItem>>(`${this.baseUrl}/uploadfile`, payload, { headers })
        .pipe(timeout(180000), map((response) => this.unwrap(response))),
    );
  }

  downloadFile(workspaceUrlOrId: string, fileId: string): Observable<Blob> {
    const request: DownloadGoogleDriveFileRequest = { workspaceUrlOrId, fileId };
    return this.withToken((headers) =>
      this.http.post(
        `${this.baseUrl}/downloadfile`,
        request,
        { headers: this.jsonHeaders(headers), responseType: 'blob' },
      ),
    );
  }

  moveFile(workspaceUrlOrId: string, fileId: string, destinationFolderId: string): Observable<GoogleDriveItem> {
    const request: MoveGoogleDriveFileRequest = { workspaceUrlOrId, fileId, destinationFolderId };
    return this.withToken((headers) =>
      this.http.post<GoogleDriveApiEnvelope<GoogleDriveItem>>(
          `${this.baseUrl}/movefile`,
          request,
          { headers: this.jsonHeaders(headers) },
        )
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  deleteItem(workspaceUrlOrId: string, itemId: string): Observable<GoogleDriveItem> {
    const request: DeleteGoogleDriveItemRequest = { workspaceUrlOrId, itemId };
    return this.withToken((headers) =>
      this.http.post<GoogleDriveApiEnvelope<GoogleDriveItem>>(
          `${this.baseUrl}/deleteitem`,
          request,
          { headers: this.jsonHeaders(headers) },
        )
        .pipe(timeout(30000), map((response) => this.unwrap(response))),
    );
  }

  private withToken<T>(request: (headers: HttpHeaders) => Observable<T>): Observable<T> {
    const availableToken = this.tokenService.getToken();
    if (availableToken) return request(this.authorizationHeaders(availableToken));

    return this.tokenService.tokenReady$.pipe(
      take(1),
      switchMap((token) => request(this.authorizationHeaders(token))),
    );
  }

  private authorizationHeaders(token: string): HttpHeaders {
    return new HttpHeaders({
      [CONNECTOR_HTTP.authorizationHeader]: `${CONNECTOR_HTTP.bearerScheme} ${token}`,
      [CONNECTOR_HTTP.apiVersionHeader]: CONNECTOR_HTTP.apiVersion,
    });
  }

  private jsonHeaders(headers: HttpHeaders): HttpHeaders {
    return headers.set(CONNECTOR_HTTP.contentTypeHeader, CONNECTOR_HTTP.jsonContentType);
  }

  private unwrap<T>(response: GoogleDriveApiEnvelope<T>): T {
    if (!response?.success) {
      throw new Error(response?.message || GOOGLE_DRIVE_API.requestFailed);
    }
    return response.data;
  }
}
