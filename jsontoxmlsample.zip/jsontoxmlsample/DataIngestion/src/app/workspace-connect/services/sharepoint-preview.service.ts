/// <reference types="vite/client" />
import { inject, Injectable } from '@angular/core';
import type { PDFDocumentProxy } from 'pdfjs-dist';
import { SP_PREVIEW } from '../core/workspace-connect.messages';
import type { RichPreviewMode } from '../core/workspace-connect.types';
import { GoogleDrivePreviewService } from './google-drive-preview.service';

type PdfJsModule = typeof import('pdfjs-dist');

export type PreviewPageReadyCallback = () => void;

const MAX_PDF_PREVIEW_PAGES = 50;

@Injectable({ providedIn: 'root' })
export class SharePointFilePreviewService {
  private static pdfWorkerConfigured = false;
  private static pdfJsModule: PdfJsModule | null = null;

  private readonly officePreview = inject(GoogleDrivePreviewService);
  private readonly objectUrls = new Set<string>();
  private renderGeneration = 0;

  revokeObjectUrls(): void {
    for (const u of this.objectUrls) {
      URL.revokeObjectURL(u);
    }
    this.objectUrls.clear();
  }

  teardown(): void {
    this.renderGeneration++;
    this.revokeObjectUrls();
    this.officePreview.teardown();
  }

  async validateBlob(blob: Blob, kind: RichPreviewMode): Promise<void> {
    if (!blob?.size) {
      throw new Error(SP_PREVIEW.emptyFile);
    }

    const type = (blob.type || '').toLowerCase();
    if (type.includes('json') || (type.includes('text') && !type.includes('csv'))) {
      const snippet = await blob.slice(0, 300).text();
      if (snippet.trimStart().startsWith('{')) {
        try {
          const j = JSON.parse(snippet) as { message?: string };
          throw new Error(j.message ?? snippet.slice(0, 120));
        } catch (e) {
          if (e instanceof Error && e.message !== snippet.slice(0, 120)) throw e;
          throw new Error(SP_PREVIEW.serverErrorResponse);
        }
      }
    }

    if (kind === 'pdf') {
      const head = await blob.slice(0, 5).text();
      if (!head.startsWith('%PDF')) {
        throw new Error(SP_PREVIEW.invalidPdf);
      }
    }

    if (kind === 'pptx') {
      const sig = new Uint8Array(await blob.slice(0, 2).arrayBuffer());
      if (sig[0] !== 0x50 || sig[1] !== 0x4b) {
        throw new Error(SP_PREVIEW.invalidPptx);
      }
    }
  }

  async renderPdf(
    container: HTMLElement,
    blob: Blob,
    onFirstPageReady?: PreviewPageReadyCallback,
  ): Promise<void> {
    const generation = this.renderGeneration;
    await this.validateBlob(blob, 'pdf');
    const { getDocument } = await this.loadPdfJs();
    container.innerHTML = '';
    const viewer = document.createElement('div');
    viewer.className = 'sp-pdf-viewer';
    container.appendChild(viewer);

    const data = await blob.arrayBuffer();
    if (generation !== this.renderGeneration) return;

    const pdf = await getDocument({ data, useSystemFonts: true }).promise;
    if (generation !== this.renderGeneration) return;

    const pageCount = pdf.numPages;
    const pagesToRender = Math.min(pageCount, MAX_PDF_PREVIEW_PAGES);
    const width = Math.max(container.clientWidth - 48, 320);

    for (let pageNum = 1; pageNum <= pagesToRender; pageNum++) {
      if (generation !== this.renderGeneration) return;
      await this.renderPdfPage(pdf, pageNum, width, viewer);
      if (pageNum === 1) onFirstPageReady?.();
    }

    if (generation !== this.renderGeneration) return;

    if (pageCount > pagesToRender) {
      const note = document.createElement('p');
      note.className = 'sp-pdf-more';
      note.textContent = SP_PREVIEW.pdfPageLimit(pagesToRender, pageCount);
      viewer.appendChild(note);
    }
  }

  async renderPptx(container: HTMLElement, blob: Blob): Promise<void> {
    await this.officePreview.render(container, blob, 'pptx');
  }

  async renderDocx(container: HTMLElement, blob: Blob): Promise<void> {
    await this.officePreview.render(container, blob, 'docx');
  }

  async renderExcelTable(container: HTMLElement, blob: Blob): Promise<void> {
    await this.officePreview.render(container, blob, 'excel');
  }

  async renderCsvTable(container: HTMLElement, text: string): Promise<void> {
    await this.officePreview.render(container, new Blob([text], { type: 'text/csv' }), 'csv');
  }

  private async loadPdfJs(): Promise<PdfJsModule> {
    if (!SharePointFilePreviewService.pdfJsModule) {
      SharePointFilePreviewService.pdfJsModule = await import('pdfjs-dist');
      if (!SharePointFilePreviewService.pdfWorkerConfigured) {
        SharePointFilePreviewService.pdfJsModule.GlobalWorkerOptions.workerSrc = 'assets/pdfjs/pdf.worker.min.mjs';
        SharePointFilePreviewService.pdfWorkerConfigured = true;
      }
    }
    return SharePointFilePreviewService.pdfJsModule;
  }

  private async renderPdfPage(
    pdf: PDFDocumentProxy,
    pageNum: number,
    containerWidth: number,
    viewer: HTMLElement,
  ): Promise<void> {
    const page = await pdf.getPage(pageNum);
    const base = page.getViewport({ scale: 1 });
    const scale = containerWidth / base.width;
    const viewport = page.getViewport({ scale });

    const canvas = document.createElement('canvas');
    canvas.className = 'sp-pdf-page';
    canvas.setAttribute('data-page', String(pageNum));
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error(SP_PREVIEW.pdfOpenFailed);

    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);

    await page.render({ canvas, viewport }).promise;
    viewer.appendChild(canvas);
  }

}
