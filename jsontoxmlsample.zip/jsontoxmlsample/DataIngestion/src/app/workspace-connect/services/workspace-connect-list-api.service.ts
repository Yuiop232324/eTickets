import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable, timeout } from 'rxjs';
import { WorkspaceConnectListQuery, WorkspaceConnectTenantPage } from '../core/workspace-connect-list.types';
import { CONNECTOR_HTTP, WORKSPACE_CONNECT_LIST_MESSAGES } from '../core/workspace-connect.messages';
import { SP_ALL_SECURITY_GROUP_ID } from '../core/workspace-connect.tenant';
import { ApiEnvelope, SHAREPOINT_ENV } from '../core/workspace-connect.types';
import { unwrapApiEnvelope } from '../core/workspace-connect.utils';

@Injectable({ providedIn: 'root' })
export class WorkspaceConnectListApiService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = inject(SHAREPOINT_ENV).apiBaseUrl.replace(/\/$/, '');

  getPage(query: WorkspaceConnectListQuery): Observable<WorkspaceConnectTenantPage> {
    const params = new URLSearchParams({
      pageNumber: String(query.pageNumber),
      pageSize: String(query.pageSize),
      connector: query.connector,
      status: query.status,
      profile: query.profile,
    });
    if (query.searchTerm?.trim()) params.set('searchTerm', query.searchTerm.trim());
    const hierarchy = query.hierarchy;
    if (hierarchy?.regionIdent) params.set('regionIdent', String(hierarchy.regionIdent));
    if (hierarchy?.subRegionCode) params.set('subRegionCode', hierarchy.subRegionCode);
    if (hierarchy?.clientIdent) params.set('clientIdent', String(hierarchy.clientIdent));
    const securityGroupIds = [...new Set((hierarchy?.securityGroups ?? [])
      .map((group) => group.id?.trim() ?? '')
      .filter((id) => !!id && id !== SP_ALL_SECURITY_GROUP_ID))];
    if (securityGroupIds.length) params.set('securityGroupIds', securityGroupIds.join(','));
    if (hierarchy?.securityGroupId && hierarchy.securityGroupId !== SP_ALL_SECURITY_GROUP_ID) {
      params.set('securityGroupId', hierarchy.securityGroupId);
    }
    const headers = new HttpHeaders({ [CONNECTOR_HTTP.apiVersionHeader]: CONNECTOR_HTTP.apiVersion });
    return this.http.get<ApiEnvelope<WorkspaceConnectTenantPage>>(`${this.baseUrl}/workspace-connect/tenants?${params}`, { headers })
      .pipe(timeout(30000), map(response => unwrapApiEnvelope(response, WORKSPACE_CONNECT_LIST_MESSAGES.tenantLoadFailed)));
  }
}
