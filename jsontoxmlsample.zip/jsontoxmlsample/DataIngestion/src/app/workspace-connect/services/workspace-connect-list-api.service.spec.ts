import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { SHAREPOINT_ENV } from '../core/workspace-connect.types';
import { WorkspaceConnectListApiService } from './workspace-connect-list-api.service';

describe('WorkspaceConnectListApiService', () => {
  it('requests only the selected page using API version 4.1', () => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
        { provide: SHAREPOINT_ENV, useValue: { apiBaseUrl: 'https://localhost:7146/api' } },
      ],
    });
    const service = TestBed.inject(WorkspaceConnectListApiService);
    const http = TestBed.inject(HttpTestingController);

    service.getPage({ pageNumber: 2, pageSize: 8, connector: 'all', status: 'active', profile: 'all' }).subscribe();

    const request = http.expectOne(req => req.url.includes('/workspace-connect/tenants'));
    expect(request.request.headers.get('x-tpdi-api-version')).toBe('4.1');
    expect(request.request.urlWithParams).toContain('pageNumber=2');
    expect(request.request.urlWithParams).toContain('pageSize=8');
    request.flush({ success: true, message: '', data: {
      applications: [], tenants: [], pageNumber: 2, pageSize: 8, filteredCount: 0, totalCount: 0,
      sharePointCount: 0, googleDriveCount: 0, activeCount: 0, draftCount: 0, inactiveCount: 0, monthlyCounts: [],
    } });
    http.verify();
  });
});
