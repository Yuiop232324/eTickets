import { Injectable } from '@angular/core';
import { renderAsync } from 'docx-preview';
import Papa from 'papaparse';
import { init as initPptxPreview } from 'pptx-preview';
import * as XLSX from 'xlsx';
import { GOOGLE_DRIVE_WORKSPACE_MESSAGES } from '../core/workspace-connect.messages';

export type GoogleDriveOfficePreviewKind = 'excel' | 'csv' | 'docx' | 'pptx';

const MAX_PREVIEW_ROWS = 5000;
const MESSAGES = GOOGLE_DRIVE_WORKSPACE_MESSAGES;

@Injectable({ providedIn: 'root' })
export class GoogleDrivePreviewService {
  private pptxDestroy: (() => void) | null = null;
  private generation = 0;

  teardown(): void {
    this.generation++;
    if (this.pptxDestroy) {
      try {
        this.pptxDestroy();
      } catch {}
      this.pptxDestroy = null;
    }
  }

  async render(host: HTMLElement, blob: Blob, kind: GoogleDriveOfficePreviewKind): Promise<void> {
    const generation = this.generation;
    host.innerHTML = '';

    if (!blob.size) throw new Error(MESSAGES.previewFileEmpty);
    if (kind === 'excel') await this.renderExcel(host, blob);
    else if (kind === 'csv') this.renderCsv(host, await blob.text());
    else if (kind === 'docx') await this.renderDocx(host, blob);
    else await this.renderPptx(host, blob);

    if (generation !== this.generation) host.innerHTML = '';
  }

  private async renderExcel(host: HTMLElement, blob: Blob): Promise<void> {
    const workbook = XLSX.read(await blob.arrayBuffer(), { type: 'array', cellDates: true });
    const sheetName = workbook.SheetNames[0];
    if (!sheetName) throw new Error(MESSAGES.worksheetMissing);
    const sheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, raw: false, defval: '' });
    host.appendChild(this.buildSpreadsheet(rows, sheetName));
  }

  private renderCsv(host: HTMLElement, text: string): void {
    const parsed = Papa.parse<string[]>(text, { skipEmptyLines: true });
    if (parsed.errors.length && !parsed.data.length) throw new Error(parsed.errors[0].message);
    host.appendChild(this.buildSpreadsheet(parsed.data as string[][], MESSAGES.csvPreviewLabel));
  }

  private async renderDocx(host: HTMLElement, blob: Blob): Promise<void> {
    await renderAsync(blob, host, undefined, {
      className: 'gd-docx-preview',
      inWrapper: true,
    });
  }

  private async renderPptx(host: HTMLElement, blob: Blob): Promise<void> {
    const signature = new Uint8Array(await blob.slice(0, 2).arrayBuffer());
    if (signature[0] !== 0x50 || signature[1] !== 0x4b) throw new Error(MESSAGES.powerPointInvalid);
    const width = Math.max(host.clientWidth - 48, 720);
    const previewer = initPptxPreview(host, { width, height: Math.round((width * 9) / 16) });
    this.pptxDestroy = () => previewer.destroy();
    await previewer.preview(await blob.arrayBuffer());
  }

  private buildSpreadsheet(rows: unknown[][], label: string): HTMLElement {
    if (!rows.length) throw new Error(MESSAGES.spreadsheetEmpty);

    const wrap = document.createElement('div');
    wrap.className = 'gd-sheet-preview';

    const ribbon = document.createElement('div');
    ribbon.className = 'gd-sheet-preview__ribbon';
    ribbon.innerHTML = `<strong>${this.escapeHtml(label)}</strong><span>${MESSAGES.rowCount(rows.length)}</span>`;
    wrap.appendChild(ribbon);

    const grid = document.createElement('div');
    grid.className = 'gd-sheet-preview__grid';
    const table = document.createElement('table');
    table.className = 'gd-sheet-preview__table';

    const limited = rows.slice(0, MAX_PREVIEW_ROWS);
    const columnCount = limited.reduce((max, row) => Math.max(max, Array.isArray(row) ? row.length : 0), 0);
    const thead = document.createElement('thead');
    const letters = document.createElement('tr');
    letters.className = 'gd-sheet-preview__letters';
    letters.appendChild(document.createElement('th'));
    for (let column = 0; column < columnCount; column++) {
      const cell = document.createElement('th');
      cell.textContent = this.columnLetter(column);
      letters.appendChild(cell);
    }
    thead.appendChild(letters);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');
    limited.forEach((row, rowIndex) => {
      const tr = document.createElement('tr');
      const rowNumber = document.createElement('th');
      rowNumber.textContent = String(rowIndex + 1);
      tr.appendChild(rowNumber);
      for (let column = 0; column < columnCount; column++) {
        const cell = document.createElement('td');
        cell.textContent = this.formatCell(Array.isArray(row) ? row[column] : '');
        if (rowIndex === 0) cell.className = 'gd-sheet-preview__header-cell';
        tr.appendChild(cell);
      }
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    grid.appendChild(table);
    wrap.appendChild(grid);

    if (rows.length > MAX_PREVIEW_ROWS) {
      const note = document.createElement('p');
      note.className = 'gd-sheet-preview__note';
      note.textContent = MESSAGES.previewRowLimit(MAX_PREVIEW_ROWS, rows.length);
      wrap.appendChild(note);
    }
    return wrap;
  }

  private formatCell(value: unknown): string {
    if (value == null) return '';
    if (value instanceof Date) return value.toLocaleString();
    return String(value);
  }

  private columnLetter(index: number): string {
    let value = index;
    let result = '';
    do {
      result = String.fromCharCode(65 + (value % 26)) + result;
      value = Math.floor(value / 26) - 1;
    } while (value >= 0);
    return result;
  }

  private escapeHtml(value: string): string {
    return value.replace(/[&<>'"]/g, (character) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
    })[character] || character);
  }
}
