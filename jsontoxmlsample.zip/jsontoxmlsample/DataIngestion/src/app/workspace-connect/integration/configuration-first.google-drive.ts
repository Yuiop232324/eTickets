export const GOOGLE_DRIVE_PROCESS_TYPE_ID = 7;
export const GOOGLE_DRIVE_SETTINGS_TAB_ID = 'google-drive-settings-tab';
export const GOOGLE_DRIVE_SETTINGS_TAB_PANE_ID = 'google-drive-settings-tab-pane';
export const SOURCE_LOCATION_GOOGLE_DRIVE = 5;

export interface ProcessConfigGoogleDriveSelection {
  googleDriveTenantFolderId: string;
}

export function isGoogleDriveProcessType(processType: unknown): boolean {
  return Number(processType) === GOOGLE_DRIVE_PROCESS_TYPE_ID;
}

export function googleDriveFileProcessFields(
  selection: ProcessConfigGoogleDriveSelection | null | undefined,
): ProcessConfigGoogleDriveSelection {
  return { googleDriveTenantFolderId: selection?.googleDriveTenantFolderId ?? '' };
}

export function activateGoogleDriveSettingsTab(): void {
  document.getElementById(GOOGLE_DRIVE_SETTINGS_TAB_ID)?.click();
}
