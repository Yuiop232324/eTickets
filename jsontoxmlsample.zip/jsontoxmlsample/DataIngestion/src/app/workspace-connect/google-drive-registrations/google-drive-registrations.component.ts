import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Subject, Subscription, debounceTime, distinctUntilChanged, firstValueFrom } from 'rxjs';
import { DuplicateTenantModalService } from '../core/duplicate-tenant-modal.service';
import {
  GoogleDriveConnectorInfo,
  GoogleDriveTenant,
  GoogleDriveTenantFolder,
  GoogleDriveWorkspaceConnection,
  SaveGoogleDriveTenantRequest,
} from '../core/google-drive-workspace.types';
import { WorkspaceConnectTenantHierarchyComponent } from '../core/workspace-connect-tenant-hierarchy.component';
import { GOOGLE_DRIVE_REGISTRATION_MESSAGES } from '../core/workspace-connect.messages';
import {
  SP_ALL_SECURITY_GROUP_ID,
  SharePointTenantHierarchySelection,
  emptyTenantHierarchySelection,
  normalizeTenantHierarchyForSave,
  tenantHierarchySelectionFromDto,
  tenantHierarchySelectionValid,
} from '../core/workspace-connect.tenant';
import { WorkspaceDirectoryUserDto } from '../core/workspace-connect.types';
import {
  GoogleDriveLogoComponent,
  SharepointLogoComponent,
  WorkspaceConnectIconComponent,
  WorkspaceConnectStatusAlertsComponent,
} from '../core/workspace-connect.ui';
import { DUPLICATE_TENANT_MESSAGE, parseApiError } from '../core/workspace-connect.utils';
import { GoogleDriveApiService } from '../services/google-drive-api.service';
import { SharePointApiService } from '../services/sharepoint-api.service';

interface WorkspaceDirectoryUserOption {
  id: string;
  label: string;
  name: string;
  upn: string;
  mail: string;
  avatarSrc: string;
}

interface GoogleDriveTenantFolderForm {
  folderUrlOrId: string;
  permissionConfirmed: boolean;
  validatedFolder: GoogleDriveWorkspaceConnection | null;
}

interface GoogleDriveTenantForm {
  tenantId: string | null;
  displayName: string;
  owner: string;
  ownerUpn: string;
  coOwner: string;
  coOwnerUpn: string;
  notes: string;
  folders: GoogleDriveTenantFolderForm[];
  tenantHierarchy: SharePointTenantHierarchySelection;
}

interface GoogleDriveMonthBucket {
  label: string;
  count: number;
}

@Component({
  selector: 'app-google-drive-tenants',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    WorkspaceConnectTenantHierarchyComponent,
    WorkspaceConnectIconComponent,
    SharepointLogoComponent,
    GoogleDriveLogoComponent,
    WorkspaceConnectStatusAlertsComponent,
  ],
  templateUrl: './google-drive-registrations.component.html',
  styleUrls: ['./google-drive-registrations.component.css', '../workspace-connect.styles.css'],
})
export class GoogleDriveTenantsComponent implements OnInit, OnDestroy {
  private readonly api = inject(GoogleDriveApiService);
  private readonly sharePointApi = inject(SharePointApiService);
  private readonly duplicateTenantModal = inject(DuplicateTenantModalService);
  private readonly messages = GOOGLE_DRIVE_REGISTRATION_MESSAGES;

  private static readonly tenantNamePattern = /^[A-Za-z -]+$/;
  readonly notesMaxLength = 400;
  readonly maxFolders = 10;

  @Input() startInForm = false;
  @Output() navigateHome = new EventEmitter<void>();
  @Output() openSharePointRegistration = new EventEmitter<void>();
  @Output() browseFolder = new EventEmitter<GoogleDriveTenantFolder>();
  @Output() registrationSaved = new EventEmitter<void>();
  @Output() viewChange = new EventEmitter<{ view: 'list' | 'form' }>();

  readonly allSecurityGroupId = '00000000-0000-0000-0000-000000000000';

  view: 'list' | 'form' = 'list';
  connectorInfo: GoogleDriveConnectorInfo | null = null;
  tenants: GoogleDriveTenant[] = [];
  form: GoogleDriveTenantForm = this.emptyForm();
  searchTerm = '';
  statusFilter: 'all' | 'active' | 'inactive' = 'all';
  typeFilter: 'all' | 'internal' | 'draft' = 'all';
  displayMode: 'cards' | 'table' = 'cards';
  listHierarchyFilterOpen = false;
  listHierarchySelection: SharePointTenantHierarchySelection = emptyTenantHierarchySelection();
  loading = true;
  saving = false;
  validating = false;
  copied = false;
  errorMessage = '';
  successMessage = '';
  ownerUserOptions: WorkspaceDirectoryUserOption[] = [];
  coOwnerUserOptions: WorkspaceDirectoryUserOption[] = [];
  ownerUserSearchLoading = false;
  coOwnerUserSearchLoading = false;
  ownerUserSearchOpen = false;
  coOwnerUserSearchOpen = false;
  private readonly ownerSearchTerms$ = new Subject<string>();
  private readonly coOwnerSearchTerms$ = new Subject<string>();
  private readonly userSearchSubscriptions = new Subscription();
  private ownerSearchSeq = 0;
  private coOwnerSearchSeq = 0;

  async ngOnInit(): Promise<void> {
    this.userSearchSubscriptions.add(
      this.ownerSearchTerms$
        .pipe(debounceTime(260), distinctUntilChanged())
        .subscribe((term) => { void this.searchWorkspaceUsers('owner', term); }),
    );
    this.userSearchSubscriptions.add(
      this.coOwnerSearchTerms$
        .pipe(debounceTime(260), distinctUntilChanged())
        .subscribe((term) => { void this.searchWorkspaceUsers('coOwner', term); }),
    );
    await Promise.all([this.loadConnectorInfo(), this.loadTenants()]);
    if (this.startInForm) this.showForm();
  }

  ngOnDestroy(): void {
    this.userSearchSubscriptions.unsubscribe();
  }

  get filteredTenants(): GoogleDriveTenant[] {
    const term = this.searchTerm.trim().toLocaleLowerCase();
    return this.tenants.filter((item) => {
      const statusMatches = this.statusFilter === 'all'
        || (this.statusFilter === 'active' && item.isActive && !item.isDraft)
        || (this.statusFilter === 'inactive' && !item.isActive && !item.isDraft);
      const typeMatches = this.typeFilter === 'all'
        || (this.typeFilter === 'internal' && !item.isDraft)
        || (this.typeFilter === 'draft' && item.isDraft);
      const scopeMatches = (!this.listHierarchySelection.regionIdent || item.regionIdent === this.listHierarchySelection.regionIdent)
        && (!this.listHierarchySelection.subRegionCode || item.subRegionCode === this.listHierarchySelection.subRegionCode)
        && (!this.listHierarchySelection.clientIdent || item.clientIdent === this.listHierarchySelection.clientIdent)
        && (!this.listHierarchySelection.securityGroupId || item.securityGroupId === this.listHierarchySelection.securityGroupId);
      if (!statusMatches || !typeMatches || !scopeMatches) return false;
      if (!term) return true;
      return [item.displayName, item.owner, item.regionName, item.subRegionName, item.clientName, ...item.folders.map((folder) => folder.folderName)]
        .some((value) => value?.toLocaleLowerCase().includes(term));
    });
  }

  get monthlyTenantBuckets(): GoogleDriveMonthBucket[] {
    const today = new Date();
    return Array.from({ length: 6 }, (_, index) => {
      const date = new Date(today.getFullYear(), today.getMonth() - (5 - index), 1);
      const count = this.tenants.filter((item) => {
        const created = new Date(item.createdOn);
        return !Number.isNaN(created.getTime())
          && created.getFullYear() === date.getFullYear()
          && created.getMonth() === date.getMonth();
      }).length;
      return {
        label: date.toLocaleDateString(undefined, { month: 'short', year: '2-digit' }),
        count,
      };
    });
  }

  get listHierarchyConfigured(): boolean {
    const selection = this.listHierarchySelection;
    return !!(selection.regionIdent || selection.subRegionCode || selection.clientIdent || selection.securityGroupId);
  }

  get listHierarchySummary(): string {
    const selection = this.listHierarchySelection;
    return selection.clientName || selection.subRegionName || selection.regionName || selection.securityGroupName || this.messages.setScope;
  }

  get activeCount(): number {
    return this.tenants.filter((item) => item.isActive && !item.isDraft).length;
  }

  get draftCount(): number {
    return this.tenants.filter((item) => item.isDraft).length;
  }

  get inactiveCount(): number {
    return this.tenants.filter((item) => !item.isActive && !item.isDraft).length;
  }

  monthlyBarHeight(count: number): number {
    const maximum = Math.max(1, ...this.monthlyTenantBuckets.map((bucket) => bucket.count));
    return count ? Math.max(14, Math.round((count / maximum) * 72)) : 0;
  }

  setDisplayMode(mode: 'cards' | 'table'): void {
    this.displayMode = mode;
  }

  onListHierarchyChange(selection: SharePointTenantHierarchySelection): void {
    this.listHierarchySelection = selection;
  }

  toggleListHierarchyFilter(): void {
    this.listHierarchyFilterOpen = !this.listHierarchyFilterOpen;
  }

  clearListHierarchyFilter(): void {
    this.listHierarchySelection = emptyTenantHierarchySelection();
    this.listHierarchyFilterOpen = false;
  }

  clearListFilters(): void {
    this.searchTerm = '';
    this.statusFilter = 'all';
    this.typeFilter = 'all';
    this.clearListHierarchyFilter();
  }

  get canRegister(): boolean {
    return this.isTenantNameValid
      && !!this.form.owner.trim()
      && !!this.form.ownerUpn.trim()
      && this.form.folders.length > 0
      && this.form.folders.some((folder) => !!folder.folderUrlOrId.trim() && folder.permissionConfirmed)
      && tenantHierarchySelectionValid(this.form.tenantHierarchy);
  }

  get isTenantNameValid(): boolean {
    const value = this.form.displayName.trim();
    return !!value && value.length <= 90 && GoogleDriveTenantsComponent.tenantNamePattern.test(value);
  }

  get tenantNameError(): string {
    if (!this.form.displayName.trim()) return this.messages.tenantNameRequired;
    if (this.form.displayName.trim().length > 90) return this.messages.tenantNameMaximumLength;
    return this.messages.tenantNameCharacters;
  }

  get showOwnerUserDropdown(): boolean {
    const query = this.form.owner.trim();
    return this.ownerUserSearchOpen && query.length >= 2;
  }

  get showCoOwnerUserDropdown(): boolean {
    const query = this.form.coOwner.trim();
    return this.coOwnerUserSearchOpen && query.length >= 2;
  }

  get verifiedFolderCount(): number {
    return this.form.folders.filter((folder) => !!folder.validatedFolder).length;
  }

  get canAddFolder(): boolean {
    return this.form.folders.length < this.maxFolders;
  }

  get notesLength(): number {
    return this.form.notes.length;
  }

  get notesRemaining(): number {
    return this.notesMaxLength - this.notesLength;
  }

  showForm(tenant?: GoogleDriveTenant): void {
    this.clearMessages();
    this.resetUserSearchState();
    if (tenant) {
      const owner = (tenant.owner ?? '').trim() || this.resolveDefaultOwnerName();
      const coOwner = (tenant.coOwner ?? '').trim();
      this.form = {
        tenantId: tenant.tenantId,
        displayName: tenant.displayName,
        owner,
        ownerUpn: this.resolveTenantOwnerUpn(tenant),
        coOwner,
        coOwnerUpn: this.resolveTenantCoOwnerUpn(tenant),
        notes: tenant.notes ?? '',
        folders: tenant.folders.map((folder) => ({
          folderUrlOrId: folder.folderId,
          permissionConfirmed: folder.permissionConfirmed,
          validatedFolder: folder.isActive && folder.permissionConfirmed ? {
            isConnected: true,
            folderId: folder.folderId,
            folderName: folder.folderName,
            webViewLink: folder.folderWebViewLink,
            driveId: folder.driveId,
            message: this.messages.savedFolder,
          } : null,
        })),
        tenantHierarchy: tenantHierarchySelectionFromDto(tenant),
      };
      if (!this.form.folders.length) this.form.folders = [this.emptyFolder()];
    } else {
      this.form = this.emptyForm();
      this.applyDefaultSecurityGroup();
    }
    this.view = 'form';
    this.emitViewChange();
  }

  private applyDefaultSecurityGroup(): void {
    const current = this.form.tenantHierarchy;
    if (current.securityGroupId) return;

    const securityGroupId = sessionStorage.getItem('GUID')?.trim() || '';
    if (!securityGroupId || securityGroupId === SP_ALL_SECURITY_GROUP_ID) return;

    const securityGroupName = sessionStorage.getItem('UserDefaultGroup')?.trim() || securityGroupId;
    this.form.tenantHierarchy = {
      ...current,
      securityGroupId,
      securityGroupName,
      securityGroups: [{ id: securityGroupId, name: securityGroupName }],
    };
  }

  showList(): void {
    this.clearMessages();
    this.resetUserSearchState();
    this.form = this.emptyForm();
    this.validating = false;
    this.saving = false;
    this.copied = false;
    this.view = 'list';
    this.emitViewChange();
  }

  onDisplayNameInput(value: string): void {
    const sanitized = value.replace(/[^A-Za-z -]/g, '').slice(0, 90);
    if (sanitized !== value) this.form.displayName = sanitized;
  }

  onTenantNameKeydown(event: KeyboardEvent): void {
    if (event.ctrlKey || event.metaKey || event.altKey) return;
    const key = event.key;
    if (key.length !== 1) return;
    if (!/^[A-Za-z -]$/.test(key)) {
      event.preventDefault();
      return;
    }
    const input = event.target as HTMLInputElement | null;
    if (!input) return;
    const hasSelection = (input.selectionStart ?? 0) !== (input.selectionEnd ?? 0);
    if (!hasSelection && input.value.length >= 90) {
      event.preventDefault();
    }
  }

  onTenantNamePaste(event: ClipboardEvent): void {
    const pasted = event.clipboardData?.getData('text') ?? '';
    const sanitized = pasted.replace(/[^A-Za-z -]/g, '');
    const input = event.target as HTMLInputElement | null;
    if (!input) return;
    event.preventDefault();

    if (!sanitized) return;

    const value = this.form.displayName ?? '';
    const start = input.selectionStart ?? value.length;
    const end = input.selectionEnd ?? start;
    const nextValue = `${value.slice(0, start)}${sanitized}${value.slice(end)}`.slice(0, 90);
    this.form.displayName = nextValue;

    const caret = Math.min(start + sanitized.length, nextValue.length);
    setTimeout(() => input.setSelectionRange(caret, caret), 0);
  }

  onOwnerInputChange(value: string): void {
    if (this.form.ownerUpn.trim()) {
      const normalizedName = this.form.owner.trim().toLowerCase();
      const normalizedUpn = this.form.ownerUpn.trim().toLowerCase();
      if (normalizedName !== normalizedUpn) this.form.ownerUpn = '';
    }
    this.queueUserSearch('owner', value);
  }

  onOwnerInputFocus(): void {
    this.ownerUserSearchOpen = true;
    this.queueUserSearch('owner', this.form.owner);
  }

  onOwnerInputBlur(): void {
    setTimeout(() => {
      this.ownerUserSearchOpen = false;
    }, 140);
  }

  selectOwnerUser(option: WorkspaceDirectoryUserOption): void {
    this.form.owner = option.name;
    this.form.ownerUpn = option.upn || option.mail;
    this.ownerUserOptions = [];
    this.ownerUserSearchOpen = false;
  }

  onCoOwnerInputChange(value: string): void {
    if (this.form.coOwnerUpn.trim()) {
      const normalizedName = this.form.coOwner.trim().toLowerCase();
      const normalizedUpn = this.form.coOwnerUpn.trim().toLowerCase();
      if (normalizedName !== normalizedUpn) this.form.coOwnerUpn = '';
    }
    this.queueUserSearch('coOwner', value);
  }

  onCoOwnerInputFocus(): void {
    this.coOwnerUserSearchOpen = true;
    this.queueUserSearch('coOwner', this.form.coOwner);
  }

  onCoOwnerInputBlur(): void {
    setTimeout(() => {
      this.coOwnerUserSearchOpen = false;
    }, 140);
  }

  selectCoOwnerUser(option: WorkspaceDirectoryUserOption): void {
    this.form.coOwner = option.name;
    this.form.coOwnerUpn = option.upn || option.mail;
    this.coOwnerUserOptions = [];
    this.coOwnerUserSearchOpen = false;
  }

  chooseSharePoint(): void {
    this.openSharePointRegistration.emit();
  }

  onHierarchyChange(selection: SharePointTenantHierarchySelection): void {
    this.form.tenantHierarchy = selection;
  }

  onFolderReferenceChange(index: number): void {
    const folder = this.form.folders[index];
    if (folder) folder.validatedFolder = null;
    this.errorMessage = '';
  }

  addFolder(): void {
    if (!this.canAddFolder) return;
    this.form.folders = [...this.form.folders, this.emptyFolder()];
  }

  removeFolder(index: number): void {
    if (this.form.folders.length === 1) {
      this.form.folders = [this.emptyFolder()];
      return;
    }
    this.form.folders = this.form.folders.filter((_, folderIndex) => folderIndex !== index);
  }

  async copyServiceEmail(): Promise<void> {
    const email = this.connectorInfo?.serviceAccountEmail;
    if (!email) return;
    await navigator.clipboard.writeText(email);
    this.copied = true;
    window.setTimeout(() => this.copied = false, 1800);
  }

  openDrive(): void {
    window.open('https://drive.google.com/drive/my-drive', '_blank', 'noopener,noreferrer');
  }

  async validateFolder(index: number): Promise<void> {
    const folder = this.form.folders[index];
    if (!folder) return;
    const reference = folder.folderUrlOrId.trim();
    if (!reference) {
      this.errorMessage = this.messages.folderReferenceRequired;
      return;
    }
    this.validating = true;
    this.clearMessages();
    try {
      folder.validatedFolder = await firstValueFrom(this.api.validateWorkspace(reference));
      this.successMessage = this.messages.folderAccessVerified(folder.validatedFolder.folderName);
    } catch (error) {
      folder.validatedFolder = null;
      this.errorMessage = this.resolveError(error, this.messages.folderAccessFailed);
    } finally {
      this.validating = false;
    }
  }

  async saveTenant(isDraft: boolean): Promise<void> {
    this.clearMessages();
    if (!this.form.displayName.trim() || !this.form.owner.trim()) {
      this.errorMessage = this.messages.tenantAndOwnerRequired;
      return;
    }
    if (!this.form.ownerUpn.trim()) {
      this.errorMessage = this.messages.ownerSelectionRequired;
      return;
    }
    if (!this.isTenantNameValid) {
      this.errorMessage = this.tenantNameError;
      return;
    }
    if (this.form.folders.length > this.maxFolders) {
      this.errorMessage = this.messages.maximumFolders(this.maxFolders);
      return;
    }
    if (!isDraft && !this.canRegister) {
      this.errorMessage = this.messages.completeRegistration;
      return;
    }

    const hierarchy = tenantHierarchySelectionValid(this.form.tenantHierarchy)
      ? normalizeTenantHierarchyForSave(this.form.tenantHierarchy)
      : null;
    const request: SaveGoogleDriveTenantRequest = {
      tenantId: this.form.tenantId,
      ownerKey: this.currentOwnerKey(),
      displayName: this.form.displayName.trim(),
      owner: this.form.owner.trim(),
      ownerUpn: this.form.ownerUpn.trim() || null,
      coOwner: this.form.coOwner.trim() || null,
      coOwnerUpn: this.form.coOwnerUpn.trim() || null,
      notes: this.form.notes.trim().slice(0, this.notesMaxLength) || null,
      regionIdent: hierarchy?.regionIdent ?? null,
      regionName: hierarchy?.regionName ?? null,
      subRegionCode: hierarchy?.subRegionCode ?? 'ALL',
      subRegionName: hierarchy?.subRegionName ?? 'All',
      clientIdent: hierarchy?.clientIdent ?? 0,
      clientName: hierarchy?.clientName ?? 'All',
      securityGroupId: hierarchy?.securityGroupId ?? this.allSecurityGroupId,
      securityGroupName: hierarchy?.securityGroupName ?? 'All',
      securityGroups: hierarchy?.securityGroups ?? [],
      isActive: !isDraft,
      isDraft,
      folders: this.form.folders
        .filter((folder) => !!folder.folderUrlOrId.trim())
        .map((folder) => ({
          folderUrlOrId: folder.folderUrlOrId.trim(),
          permissionConfirmed: folder.permissionConfirmed,
        })),
    };

    this.saving = true;
    try {
      const saved = await firstValueFrom(this.api.saveTenant(request));
      await this.loadTenants();
      this.view = 'list';
      this.emitViewChange();
      this.successMessage = isDraft
        ? this.messages.draftSaved(saved.displayName)
        : this.messages.tenantSaved(saved.displayName, saved.folderCount);
      this.registrationSaved.emit();
    } catch (error) {
      const message = this.resolveError(error, this.messages.saveFailed);
      if (message === DUPLICATE_TENANT_MESSAGE) this.duplicateTenantModal.open();
      else this.errorMessage = message;
    } finally {
      this.saving = false;
    }
  }

  async deactivate(tenant: GoogleDriveTenant): Promise<void> {
    if (!window.confirm(this.messages.deactivateConfirm(tenant.displayName))) return;
    this.clearMessages();
    try {
      await firstValueFrom(this.api.deactivateTenant(tenant.tenantId));
      await this.loadTenants();
      this.successMessage = this.messages.deactivated(tenant.displayName);
    } catch (error) {
      this.errorMessage = this.resolveError(error, this.messages.deactivateFailed);
    }
  }

  formatDate(value?: string | null): string {
    if (!value) return this.messages.notAvailable;
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? this.messages.notAvailable : date.toLocaleDateString();
  }

  private async loadConnectorInfo(): Promise<void> {
    try {
      this.connectorInfo = await firstValueFrom(this.api.getConnectorInfo());
    } catch (error) {
      this.errorMessage = this.resolveError(error, this.messages.connectorInfoLoadFailed);
    }
  }

  private async loadTenants(): Promise<void> {
    this.loading = true;
    try {
      this.tenants = await firstValueFrom(this.api.getTenants(true));
    } catch (error) {
      this.tenants = [];
      this.errorMessage = this.resolveError(error, this.messages.tenantLoadFailed);
    } finally {
      this.loading = false;
    }
  }

  private emptyForm(): GoogleDriveTenantForm {
    const owner = this.resolveDefaultOwnerName();
    const ownerUpn = this.resolveDefaultOwnerUpn();
    return {
      tenantId: null,
      displayName: '',
      owner,
      ownerUpn,
      coOwner: '',
      coOwnerUpn: '',
      notes: '',
      folders: [this.emptyFolder()],
      tenantHierarchy: emptyTenantHierarchySelection(),
    };
  }

  private emptyFolder(): GoogleDriveTenantFolderForm {
    return { folderUrlOrId: '', permissionConfirmed: false, validatedFolder: null };
  }

  private readSessionValue(...keys: string[]): string {
    for (const key of keys) {
      const value = sessionStorage.getItem(key)?.trim() || '';
      if (value) return value;
    }
    return '';
  }

  private resolveDefaultOwnerName(): string {
    return this.readSessionValue('userFullName', 'FullName') || this.messages.defaultOwner;
  }

  private resolveDefaultOwnerUpn(): string {
    const candidate = this.readSessionValue('fullUPN', 'emailID', 'Upn', 'upn');
    return candidate.includes('@') ? candidate : '';
  }

  private resolveTenantOwnerUpn(tenant: GoogleDriveTenant): string {
    const ownerUpn = (tenant.ownerUpn ?? '').trim();
    if (ownerUpn) return ownerUpn;

    const owner = (tenant.owner ?? '').trim();
    if (owner.includes('@')) return owner;

    const ownerKey = (tenant.ownerKey ?? '').trim();
    if (ownerKey.includes('@')) return ownerKey;

    return '';
  }

  private resolveTenantCoOwnerUpn(tenant: GoogleDriveTenant): string {
    const coOwnerUpn = (tenant.coOwnerUpn ?? '').trim();
    if (coOwnerUpn) return coOwnerUpn;

    const coOwner = (tenant.coOwner ?? '').trim();
    return coOwner.includes('@') ? coOwner : '';
  }

  private currentOwnerKey(): string {
    return this.readSessionValue('fullUPN', 'emailID', 'Upn', 'upn', 'GUID')
      || 'workspace-connect';
  }

  private resetUserSearchState(): void {
    this.ownerUserOptions = [];
    this.coOwnerUserOptions = [];
    this.ownerUserSearchLoading = false;
    this.coOwnerUserSearchLoading = false;
    this.ownerUserSearchOpen = false;
    this.coOwnerUserSearchOpen = false;
  }

  private queueUserSearch(target: 'owner' | 'coOwner', value: string): void {
    const term = value.trim();
    if (term.length < 2) {
      if (target === 'owner') {
        this.ownerUserOptions = [];
        this.ownerUserSearchLoading = false;
      } else {
        this.coOwnerUserOptions = [];
        this.coOwnerUserSearchLoading = false;
      }
      return;
    }

    if (target === 'owner') {
      this.ownerUserSearchLoading = true;
      this.ownerSearchTerms$.next(term);
    } else {
      this.coOwnerUserSearchLoading = true;
      this.coOwnerSearchTerms$.next(term);
    }
  }

  private async searchWorkspaceUsers(target: 'owner' | 'coOwner', term: string): Promise<void> {
    const seq = target === 'owner' ? ++this.ownerSearchSeq : ++this.coOwnerSearchSeq;
    if (target === 'owner') this.ownerUserSearchLoading = true;
    else this.coOwnerUserSearchLoading = true;

    try {
      const result = await firstValueFrom(this.sharePointApi.searchWorkspaceUsers(term, 'string'));
      const latestSeq = target === 'owner' ? this.ownerSearchSeq : this.coOwnerSearchSeq;
      if (seq !== latestSeq) return;

      const options = (result.users ?? [])
        .map((user) => this.toDirectoryUserOption(user))
        .filter((user): user is WorkspaceDirectoryUserOption => !!user);

      if (target === 'owner') {
        this.ownerUserOptions = options;
        this.ownerUserSearchLoading = false;
      } else {
        this.coOwnerUserOptions = options;
        this.coOwnerUserSearchLoading = false;
      }
    } catch {
      if (target === 'owner') {
        this.ownerUserOptions = [];
        this.ownerUserSearchLoading = false;
      } else {
        this.coOwnerUserOptions = [];
        this.coOwnerUserSearchLoading = false;
      }
    }
  }

  private toDirectoryUserOption(user: WorkspaceDirectoryUserDto): WorkspaceDirectoryUserOption | null {
    const upn = (user.userPrincipalName ?? '').trim();
    const mail = (user.mail ?? '').trim();
    const name = this.resolveDirectoryUserName(user, upn || mail);
    const label = (upn || mail) ? `${name} (${upn || mail})` : name;
    if (!label.trim()) return null;
    return {
      id: (user.id ?? upn ?? mail ?? name).trim() || name,
      label,
      name,
      upn,
      mail,
      avatarSrc: this.buildAvatarDataUrl(name || upn || mail || 'U'),
    };
  }

  private resolveDirectoryUserName(user: WorkspaceDirectoryUserDto, fallback: string): string {
    const displayName = (user.displayName ?? '').trim();
    if (displayName) return displayName;
    const fullName = `${(user.givenName ?? '').trim()} ${(user.surname ?? '').trim()}`.trim();
    return fullName || fallback || this.messages.unknownUser;
  }

  private buildAvatarDataUrl(value: string): string {
    const initials = this.initialsFromName(value);
    const hue = this.colorHue(value);
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='40' height='40' viewBox='0 0 40 40'><defs><linearGradient id='g' x1='0' x2='1' y1='0' y2='1'><stop offset='0%' stop-color='hsl(${hue},72%,56%)'/><stop offset='100%' stop-color='hsl(${(hue + 28) % 360},68%,44%)'/></linearGradient></defs><circle cx='20' cy='20' r='20' fill='url(#g)'/><text x='50%' y='54%' dominant-baseline='middle' text-anchor='middle' font-family='Segoe UI, Arial, sans-serif' font-size='14' font-weight='700' fill='white'>${initials}</text></svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }

  private initialsFromName(name: string): string {
    const parts = name.trim().split(/\s+/).filter(Boolean);
    if (!parts.length) return 'U';
    const first = parts[0][0] ?? 'U';
    const second = parts.length > 1 ? parts[parts.length - 1][0] : '';
    return `${first}${second}`.toUpperCase();
  }

  private colorHue(value: string): number {
    let hash = 0;
    for (let i = 0; i < value.length; i++) {
      hash = ((hash << 5) - hash) + value.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash) % 360;
  }

  private clearMessages(): void {
    this.errorMessage = '';
    this.successMessage = '';
  }

  private emitViewChange(): void {
    this.viewChange.emit({ view: this.view });
  }

  private resolveError(error: unknown, fallback: string): string {
    return parseApiError(error, fallback);
  }
}
