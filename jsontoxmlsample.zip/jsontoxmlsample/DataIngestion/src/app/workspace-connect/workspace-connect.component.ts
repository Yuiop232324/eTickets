import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { BusyService } from '../core/services/busy.service';
import { GoogleDriveTenant, GoogleDriveTenantFolder } from './core/google-drive-workspace.types';
import { ConnectorListFilter } from './core/workspace-connect-list.types';
import { MODULE_BRANDING } from './core/workspace-connect.messages';
import { ApplicationDto } from './core/workspace-connect.types';
import {
  WcModuleBreadcrumbId,
  WcModuleBreadcrumbItem,
  WorkspaceConnectBreadcrumbComponent,
} from './core/workspace-connect.ui';
import { fireAndForget } from './core/workspace-connect.utils';
import { GoogleDriveTenantsComponent } from './google-drive-registrations/google-drive-registrations.component';
import { GoogleDriveWorkspaceComponent } from './google-drive-workspace/google-drive-workspace.component';
import { SharePointApiService } from './services/sharepoint-api.service';
import { SharePointUserAuthService } from './services/sharepoint-user.service';
import { SharepointWorkspaceComponent } from './sharepoint-workspace/sharepoint-workspace.component';
import { WorkspaceConnectConnectorsComponent } from './workspace-connect-connectors/workspace-connect-connectors.component';
import { WorkspaceConnectGuidedRegistrationComponent } from './workspace-connect-guided-registration/workspace-connect-guided-registration.component';
import { WorkspaceConnectHomeComponent } from './workspace-connect-home/workspace-connect-home.component';
import { WorkspaceConnectUnifiedListComponent } from './workspace-connect-unified-list/workspace-connect-unified-list.component';

type WcView = 'home' | 'connectors' | 'guided-registration' | 'sharepoint-workspace' | 'google-drive-connections' | 'google-drive-workspace';

@Component({
  selector: 'app-workspace-connect',
  standalone: true,
  imports: [
    CommonModule,
    WorkspaceConnectHomeComponent,
    WorkspaceConnectConnectorsComponent,
    WorkspaceConnectUnifiedListComponent,
    WorkspaceConnectGuidedRegistrationComponent,
    SharepointWorkspaceComponent,
    GoogleDriveTenantsComponent,
    GoogleDriveWorkspaceComponent,
    WorkspaceConnectBreadcrumbComponent,
  ],
  templateUrl: './workspace-connect.component.html',
  styleUrls: ['./workspace-connect-shell.css', './workspace-connect.styles.css'],
})
export class WorkspaceConnectComponent implements OnInit {
  private readonly auth = inject(SharePointUserAuthService);
  private readonly api = inject(SharePointApiService);
  private readonly busyService = inject(BusyService);
  readonly branding = MODULE_BRANDING;

  @ViewChild(WorkspaceConnectConnectorsComponent) private connectorsRef?: WorkspaceConnectConnectorsComponent;
  @ViewChild(GoogleDriveTenantsComponent) private googleDriveTenantsRef?: GoogleDriveTenantsComponent;

  view: WcView = 'home';
  pendingApplicationId: string | null = null;
  pendingGoogleDriveFolder: GoogleDriveTenantFolder | null = null;
  googleDriveStartInForm = false;
  googleDriveSubView: 'list' | 'form' = 'list';
  connectorsSubView: 'list' | 'form' = 'list';
  connectorsFormTitle = '';
  unifiedConnectorFilter: 'all' | 'sharepoint' | 'google-drive' = 'all';
  connectorsListSuccessMessage = '';

  async ngOnInit(): Promise<void> {
    if (this.auth.isConfigured) {
      this.busyService.busy();
      try {
        await this.auth.initialize();
      } finally {
        this.busyService.idle();
      }
    }
    const params = new URLSearchParams(window.location.search);
    const registration = params.get('register');
    if (registration === 'sharepoint') this.goRegister();
    else if (registration === 'google-drive') this.goGoogleDriveRegister();
    else if (params.get('view') === 'connectors') {
      const connector = params.get('connector');
      this.view = 'connectors';
      this.unifiedConnectorFilter = connector === 'sharepoint' || connector === 'google-drive' ? connector : 'all';
      this.resetPageScroll();
    }
  }

  get moduleBreadcrumbs(): WcModuleBreadcrumbItem[] {
    const root: WcModuleBreadcrumbItem = { id: 'home', label: this.branding.breadcrumbRoot };
    switch (this.view) {
      case 'home':
        return [root];
      case 'connectors': {
        const items: WcModuleBreadcrumbItem[] = [
          root,
          { id: 'connectors', label: 'Connectors' },
        ];
        if (this.connectorsSubView === 'form') {
          items.push({
            id: 'connector-register',
            label: this.connectorsFormTitle || this.branding.connectorRegisterNavTitle,
          });
        }
        return items;
      }
      case 'guided-registration':
        return [root, { id: 'guided-register', label: this.branding.guidedRegisterNavTitle }];
      case 'sharepoint-workspace':
        return [root, { id: 'sharepoint-workspace', label: this.branding.browseNavTitle }];
      case 'google-drive-connections':
        return this.googleDriveSubView === 'form'
          ? [
            root,
            { id: 'connectors', label: 'Connectors' },
            { id: 'connector-register', label: this.branding.connectorRegisterNavTitle },
          ]
          : [
            root,
            { id: 'connectors', label: 'Connectors' },
            { id: 'google-drive-connections', label: 'Google Drive' },
          ];
      case 'google-drive-workspace':
        return [
          root,
          { id: 'google-drive-connections', label: 'Google Drive' },
          { id: 'google-drive-workspace', label: 'Google Drive workspace' },
        ];
      default:
        return [root];
    }
  }

  onBreadcrumbNavigate(id: WcModuleBreadcrumbId): void {
    switch (id) {
      case 'home':
        this.goHome();
        break;
      case 'connectors':
      case 'connector-sharepoint':
        this.goConnectors();
        break;
      case 'connector-register':
        this.goRegister();
        break;
      case 'guided-register':
        this.goGuidedRegister();
        break;
      case 'sharepoint-workspace':
        this.goSharepointWorkspace();
        break;
      case 'google-drive-connections':
        this.goGoogleDriveConnections();
        break;
      case 'google-drive-workspace':
        this.goGoogleDriveWorkspace();
        break;
      default:
        break;
    }
  }

  onConnectorsViewChange(event: { view: 'list' | 'form'; formTitle?: string; successMessage?: string }): void {
    this.connectorsSubView = event.view;
    this.connectorsFormTitle = event.formTitle ?? '';
    this.connectorsListSuccessMessage = event.view === 'list' ? (event.successMessage?.trim() ?? '') : '';
    this.setRegistrationRoute(
      event.view === 'form' ? 'sharepoint' : undefined,
      event.view === 'list' ? this.unifiedConnectorFilter : undefined,
    );
    if (event.view === 'list') this.resetPageScroll();
  }

  onGoogleDriveViewChange(event: { view: 'list' | 'form' }): void {
    this.googleDriveSubView = event.view;
    this.setRegistrationRoute(
      event.view === 'form' ? 'google-drive' : undefined,
      event.view === 'list' ? 'google-drive' : undefined,
    );
    if (event.view === 'list') this.resetPageScroll();
  }

  goHome(): void {
    this.setRegistrationRoute();
    this.view = 'home';
    this.pendingApplicationId = null;
    this.connectorsSubView = 'list';
    this.connectorsFormTitle = '';
    this.connectorsListSuccessMessage = '';
    this.unifiedConnectorFilter = 'all';
    this.pendingGoogleDriveFolder = null;
    this.googleDriveStartInForm = false;
    this.googleDriveSubView = 'list';
  }

  goConnectors(successMessage = ''): void {
    this.setRegistrationRoute(undefined, 'all');
    this.view = 'connectors';
    this.pendingApplicationId = null;
    this.connectorsSubView = 'list';
    this.connectorsFormTitle = '';
    this.connectorsListSuccessMessage = successMessage.trim();
    this.unifiedConnectorFilter = 'all';
    this.googleDriveStartInForm = false;
    this.googleDriveSubView = 'list';
    this.resetPageScroll();
  }

  goRegister(): void {
    this.setRegistrationRoute('sharepoint');
    this.view = 'connectors';
    this.pendingApplicationId = null;
    this.unifiedConnectorFilter = 'sharepoint';
    this.connectorsSubView = 'form';
    this.connectorsFormTitle = '';
    this.connectorsListSuccessMessage = '';
    this.googleDriveStartInForm = false;
    this.googleDriveSubView = 'list';
    this.openSharePointRegisterForm();
  }

  goGuidedRegister(): void {
    this.view = 'guided-registration';
    this.pendingApplicationId = null;
    this.connectorsSubView = 'list';
    this.connectorsFormTitle = '';
    this.connectorsListSuccessMessage = '';
  }

  goSharepointWorkspace(): void {
    this.view = 'sharepoint-workspace';
    this.connectorsListSuccessMessage = '';
  }

  goGoogleDriveConnections(): void {
    this.setRegistrationRoute(undefined, 'google-drive');
    this.view = 'connectors';
    this.connectorsSubView = 'list';
    this.connectorsListSuccessMessage = '';
    this.unifiedConnectorFilter = 'google-drive';
    this.pendingGoogleDriveFolder = null;
    this.googleDriveStartInForm = false;
    this.googleDriveSubView = 'list';
    this.resetPageScroll();
  }

  goGoogleDriveRegister(): void {
    this.setRegistrationRoute('google-drive');
    this.view = 'google-drive-connections';
    this.pendingGoogleDriveFolder = null;
    this.connectorsListSuccessMessage = '';
    this.googleDriveStartInForm = true;
    this.googleDriveSubView = 'form';
    setTimeout(() => this.googleDriveTenantsRef?.showForm(), 0);
  }

  onUnifiedConnectorFilterChange(filter: ConnectorListFilter): void {
    this.unifiedConnectorFilter = filter;
    this.setRegistrationRoute(undefined, filter);
  }

  goSharePointEdit(application: ApplicationDto): void {
    this.view = 'connectors';
    this.unifiedConnectorFilter = 'sharepoint';
    this.connectorsSubView = 'form';
    this.connectorsFormTitle = '';
    this.connectorsListSuccessMessage = '';
    setTimeout(() => {
      this.connectorsRef?.showForm();
      this.connectorsRef?.editApplication(application);
    }, 0);
  }

  goGoogleDriveEdit(tenant: GoogleDriveTenant): void {
    this.view = 'google-drive-connections';
    this.connectorsListSuccessMessage = '';
    this.googleDriveStartInForm = false;
    this.googleDriveSubView = 'form';
    setTimeout(() => this.googleDriveTenantsRef?.showForm(tenant), 0);
  }

  goGoogleDriveWorkspace(folder: GoogleDriveTenantFolder | null = null): void {
    this.pendingGoogleDriveFolder = folder;
    this.view = 'google-drive-workspace';
  }

  onUseApplication(app: ApplicationDto): void {
    this.pendingApplicationId = app.applicationId;
    this.view = 'sharepoint-workspace';
    this.connectorsListSuccessMessage = '';
    const account = this.auth.account();
    fireAndForget(this.api.recordApplicationUsage(app.applicationId, {
      displayName: app.displayName,
      usedByUpn: account?.username,
      usedByDisplayName: account?.name,
    }));
  }

  onLaunchApplicationConsumed(): void {
    this.pendingApplicationId = null;
  }

  private openSharePointRegisterForm(retries = 8): void {
    if (this.connectorsRef) {
      this.connectorsRef.showForm();
      return;
    }
    if (retries <= 0) return;
    setTimeout(() => this.openSharePointRegisterForm(retries - 1), 30);
  }

  private resetPageScroll(): void {
    requestAnimationFrame(() => {
      const page = document.getElementById('pageContent');
      page ? page.scrollTo({ top: 0, left: 0, behavior: 'auto' }) : window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
    });
  }

  private setRegistrationRoute(
    connector?: 'sharepoint' | 'google-drive',
    listFilter?: ConnectorListFilter,
  ): void {
    const url = new URL(window.location.href);
    if (connector) {
      url.searchParams.set('register', connector);
      url.searchParams.delete('view');
      url.searchParams.delete('connector');
    } else {
      url.searchParams.delete('register');
      if (listFilter) {
        url.searchParams.set('view', 'connectors');
        listFilter === 'all'
          ? url.searchParams.delete('connector')
          : url.searchParams.set('connector', listFilter);
      } else {
        url.searchParams.delete('view');
        url.searchParams.delete('connector');
      }
    }
    window.history.replaceState(null, '', `${url.pathname}${url.search}${url.hash}`);
  }
}
