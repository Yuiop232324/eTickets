import { fakeAsync, flushMicrotasks, tick } from '@angular/core/testing';
import { Subject } from 'rxjs';
import { WorkspaceConnectConnectorsComponent } from './workspace-connect-connectors.component';

describe('Tenant edit verification before save', () => {
  function setup() {
    const component: any = Object.create(WorkspaceConnectConnectorsComponent.prototype);
    component.applicationForm = { applicationId: 12, isActive: false, hostName: 'example.sharepoint.com', sites: [{ siteName: ' sites/test ' }] };
    component.activeSiteIndex = 0;
    component.siteConnectivityByIndex = new Map();
    component.siteLibrariesByIndex = new Map();
    component.sitePreviewByIndex = new Map();
    component.availableLibraries = [];
    for (const key of ['isFormValid', 'needsConnectivityTest', 'canTestConnectivity']) {
      Object.defineProperty(component, key, { value: true, configurable: true });
    }
    component.status = { clear: () => {}, setApiErrorMessage: jasmine.createSpy() };
    for (const name of ['syncFieldsToActiveSite', 'clearConnectivityGlimpses', 'startVerifyPhaseCycle',
      'stopVerifyPhaseCycle', 'syncConnectivityView', 'scheduleConnectivityGlimpses', 'queueGlimpse',
      'applyLibrariesFromProbe', 'loadConnectivityPreview']) component[name] = jasmine.createSpy(name);
    component.buildConnectivityRequest = () => ({});
    component.persistApplication = jasmine.createSpy().and.resolveTo();
    const response = new Subject<any>();
    component.api = { validateSiteConnectivity: jasmine.createSpy().and.returnValue(response) };
    return { component, response };
  }

  for (const connected of [true, false]) {
    it(`waits for fresh verification and saves ${connected ? 'Active' : 'Inactive'}`, fakeAsync(() => {
      const { component, response } = setup();
      component.saveApplication();
      expect(component.checkingConnectivity).toBeTrue();
      expect(component.persistApplication).not.toHaveBeenCalled();
      component.saveApplication();
      expect(component.api.validateSiteConnectivity).toHaveBeenCalledTimes(1);
      response.next({ isConnected: connected }); response.complete();
      flushMicrotasks(); tick(5000); flushMicrotasks();
      expect(component.persistApplication).toHaveBeenCalledOnceWith(connected);
      expect(component.checkingConnectivity).toBeFalse();
    }));
  }

  it('saves Inactive after a verification error', fakeAsync(() => {
    const { component, response } = setup();
    component.saveApplication();
    response.error(new Error('Connection failed'));
    flushMicrotasks(); tick(5000); flushMicrotasks();
    expect(component.persistApplication).toHaveBeenCalledOnceWith(false);
  }));

  it('does not save when required verification details are missing', async () => {
    const { component } = setup();
    Object.defineProperty(component, 'canTestConnectivity', { value: false });
    component.connectivityValidationMessage = () => 'Missing details';
    await component.saveApplication();
    expect(component.status.setApiErrorMessage).toHaveBeenCalledWith('Missing details');
    expect(component.persistApplication).not.toHaveBeenCalled();
  });
});
