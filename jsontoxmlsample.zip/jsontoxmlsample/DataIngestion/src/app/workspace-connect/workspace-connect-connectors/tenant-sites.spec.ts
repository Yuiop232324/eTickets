import { WorkspaceConnectConnectorsComponent } from './workspace-connect-connectors.component';

describe('Tenant site limits and summaries', () => {
  function setup(count: number): any {
    const c: any = Object.create(WorkspaceConnectConnectorsComponent.prototype);
    c.maxTenantSites = 10;
    c.applicationForm = { sites: Array.from({ length: count }, (_, i) => ({ siteName: `sites/Site${i + 1}` })) };
    for (const name of ['saveActiveSiteConnectivity', 'syncFieldsToActiveSite', 'syncFieldsFromActiveSite',
      'loadActiveSiteConnectivity', 'resetConnectivityTest']) c[name] = () => {};
    c.cdr = { markForCheck: () => {} };
    c.status = { setApiErrorMessage: jasmine.createSpy() };
    return c;
  }

  it('allows the tenth site and blocks an eleventh without changing the selection', () => {
    const c = setup(9);
    c.addSite();
    expect(c.applicationForm.sites.length).toBe(10);
    expect(c.activeSiteIndex).toBe(9);
    c.addSite();
    expect(c.applicationForm.sites.length).toBe(10);
    expect(c.activeSiteIndex).toBe(9);
  });

  it('rejects an oversized form before saving, including drafts', async () => {
    const c = setup(11);
    await c.persistApplication(false, true);
    expect(c.status.setApiErrorMessage).toHaveBeenCalledWith('A tenant can have a maximum of 10 sites.');
    expect(c.savingApplication).toBeUndefined();
  });

  it('keeps all ten full names for the tooltip while shortening the displayed summary', () => {
    const c = setup(10);
    c.applicationForm.sites[0].siteName = 'sites/' + 'LongName'.repeat(20);
    const names = c.tenantSiteNames(c.applicationForm);
    expect(names.length).toBe(10);
    expect(names[0]).toBe(c.applicationForm.sites[0].siteName);
    expect(c.tenantSiteSummary(c.applicationForm)).toBe(names[0].slice(0, 32) + '… (+9 more)');
  });

  it('supports legacy single-site and empty tenants', () => {
    const c = setup(0);
    expect(c.tenantSiteNames({ siteName: 'sites/Legacy' })).toEqual(['sites/Legacy']);
    expect(c.tenantSiteSummary({})).toBe('—');
  });
});
