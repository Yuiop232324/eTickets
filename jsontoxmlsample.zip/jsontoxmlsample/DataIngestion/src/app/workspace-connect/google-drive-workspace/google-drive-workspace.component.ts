import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, ElementRef, EventEmitter, Input, OnDestroy, Output, ViewChild, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { firstValueFrom } from 'rxjs';
import { googleDriveEffectiveFileName, isGoogleDriveWorkspaceItemVisible } from '../core/google-drive-file-eligibility';
import {
  GoogleDriveDisplayMode,
  GoogleDriveFolderTrailItem,
  GoogleDriveItem,
  GoogleDriveSortMode,
  GoogleDriveTenantFolder,
  GoogleDriveWorkspaceConnection,
} from '../core/google-drive-workspace.types';
import { WC_IMAGES } from '../core/workspace-connect.assets';
import { GOOGLE_DRIVE_WORKSPACE_MESSAGES } from '../core/workspace-connect.messages';
import { GoogleDriveApiService } from '../services/google-drive-api.service';
import { GoogleDriveOfficePreviewKind, GoogleDrivePreviewService } from '../services/google-drive-preview.service';

interface GoogleDriveNavigationEntry {
  folderId: string;
  trail: GoogleDriveFolderTrailItem[];
}

type GoogleDrivePreviewKind = GoogleDriveOfficePreviewKind | 'pdf' | 'image' | 'video' | 'audio' | 'text' | 'unsupported';

@Component({
  selector: 'app-google-drive-workspace',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './google-drive-workspace.component.html',
  styleUrl: './google-drive-workspace.component.css',
})
export class GoogleDriveWorkspaceComponent implements OnDestroy {
  private readonly api = inject(GoogleDriveApiService);
  private readonly previewService = inject(GoogleDrivePreviewService);
  private readonly sanitizer = inject(DomSanitizer);
  private readonly cdr = inject(ChangeDetectorRef);
  readonly messages = GOOGLE_DRIVE_WORKSPACE_MESSAGES;

  @Output() navigateHome = new EventEmitter<void>();
  @Output() pickFile = new EventEmitter<GoogleDriveItem>();
  @Output() viewerOpenChange = new EventEmitter<boolean>();
  @Input() filePickMode = false;
  @Input() allowAllFileTypes = false;
  // #region Workspace Connect - Google Drive Process First
  @Input() processConfigMode = false;
  // #endregion
  // #region Structured JSON/XML files
  @Input() structuredFilePickMode = false;
  // #endregion
  @Input() pickFileBusy = false;
  @Input() set initialFolder(value: GoogleDriveTenantFolder | null) {
    if (!value?.folderId) {
      if ((this.filePickMode || this.processConfigMode) && this.workspaceUrlOrId) this.disconnect();
      return;
    }
    if (!value?.folderId || value.folderId === this.workspaceUrlOrId) return;
    this.workspaceInput = value.folderId;
    queueMicrotask(() => void this.connectWorkspace());
  }
  @ViewChild('fileInput') private fileInput?: ElementRef<HTMLInputElement>;
  @ViewChild('previewHost') private previewHost?: ElementRef<HTMLElement>;

  readonly driveLogo = WC_IMAGES.googleDrive;
  readonly skeletonRows = [0, 1, 2, 3, 4, 5];

  workspaceInput = '';
  workspaceUrlOrId = '';
  connection: GoogleDriveWorkspaceConnection | null = null;
  items: GoogleDriveItem[] = [];
  folderTrail: GoogleDriveFolderTrailItem[] = [];
  navigationHistory: GoogleDriveNavigationEntry[] = [];
  navigationIndex = -1;
  searchTerm = '';
  displayMode: GoogleDriveDisplayMode = 'list';
  sortMode: GoogleDriveSortMode = 'name';
  loading = false;
  loadingLabel: string = this.messages.readingFolderContents;
  actionBusy = false;
  errorMessage = '';
  successMessage = '';
  sidebarCollapsed = false;

  previewOpen = false;
  previewLoading = false;
  previewError = '';
  previewText = '';
  previewKind: GoogleDrivePreviewKind = 'unsupported';
  previewUrl: SafeResourceUrl | null = null;
  selectedItem: GoogleDriveItem | null = null;

  createFolderOpen = false;
  newFolderName = '';
  moveTarget: GoogleDriveItem | null = null;
  moveDestinationId = '';
  deleteTarget: GoogleDriveItem | null = null;

  private loadingStartedAt = 0;
  private previewStartedAt = 0;
  private previewGeneration = 0;
  previewObjectUrl = '';

  get currentFolder(): GoogleDriveFolderTrailItem | null {
    return this.folderTrail.length ? this.folderTrail[this.folderTrail.length - 1] : null;
  }

  get canNavigateUp(): boolean {
    return !!this.connection && this.folderTrail.length > 1;
  }

  get canNavigateBack(): boolean {
    return this.navigationIndex > 0;
  }

  get canNavigateForward(): boolean {
    return this.navigationIndex >= 0 && this.navigationIndex < this.navigationHistory.length - 1;
  }

  get visibleItems(): GoogleDriveItem[] {
    const query = this.searchTerm.trim().toLocaleLowerCase();
    const fileSelectionMode = this.filePickMode || this.processConfigMode;
    const restrictToProcessFiles = fileSelectionMode && !this.allowAllFileTypes;
    const eligible = this.items.filter((item) =>
      isGoogleDriveWorkspaceItemVisible(item, restrictToProcessFiles, fileSelectionMode, this.structuredFilePickMode));
    const filtered = query
      ? eligible.filter((item) => item.name.toLocaleLowerCase().includes(query))
      : eligible;

    return filtered.sort((left, right) => {
      if (left.isFolder !== right.isFolder) return left.isFolder ? -1 : 1;
      switch (this.sortMode) {
        case 'modified':
          return this.toTimestamp(right.modifiedTime) - this.toTimestamp(left.modifiedTime);
        case 'size':
          return (right.size ?? 0) - (left.size ?? 0);
        default:
          return left.name.localeCompare(right.name, undefined, { numeric: true, sensitivity: 'base' });
      }
    });
  }

  get isFileTypeRestrictedInPicker(): boolean {
    const fileSelectionMode = this.filePickMode || this.processConfigMode;
    return fileSelectionMode && !this.allowAllFileTypes;
  }

  get isOfficePreview(): boolean {
    return ['excel', 'csv', 'docx', 'pptx'].includes(this.previewKind);
  }

  ngOnDestroy(): void {
    this.previewGeneration++;
    this.revokePreviewUrl();
    this.previewService.teardown();
  }

  async connectWorkspace(): Promise<void> {
    const value = this.workspaceInput.trim();
    if (!value) {
      this.setError(this.messages.folderReferenceRequired);
      return;
    }

    this.beginLoading(this.messages.verifyingAccess);
    this.clearMessages();
    try {
      const connection = await firstValueFrom(this.api.validateWorkspace(value));
      if (!connection.isConnected) throw new Error(connection.message || this.messages.connectionFailed);

      this.connection = connection;
      this.workspaceUrlOrId = value;
      const rootTrail = [{ id: connection.folderId, name: connection.folderName || this.messages.connectedFolder }];
      this.folderTrail = rootTrail;
      this.resetNavigationHistory(rootTrail);
      this.loadingLabel = this.messages.opening(rootTrail[0].name);
      await this.loadFolder(connection.folderId, false);
      this.successMessage = connection.message || this.messages.connected;
    } catch (error) {
      this.connection = null;
      this.items = [];
      this.folderTrail = [];
      this.setError(this.resolveError(error, this.messages.connectFailed));
    } finally {
      await this.finishLoading();
    }
  }

  async openFolder(item: GoogleDriveItem): Promise<void> {
    if (!item.isFolder || this.loading) return;
    this.beginLoading(this.messages.opening(item.name));
    this.clearMessages();
    try {
      await this.loadFolder(item.id, false);
      const nextTrail = [...this.folderTrail, { id: item.id, name: item.name }];
      this.folderTrail = nextTrail;
      this.recordNavigation(nextTrail);
    } catch (error) {
      this.setError(this.resolveError(error, this.messages.openFailed(item.name)));
    } finally {
      await this.finishLoading();
    }
  }

  async navigateToTrail(index: number): Promise<void> {
    const destination = this.folderTrail[index];
    if (!destination || index === this.folderTrail.length - 1 || this.loading) return;
    this.beginLoading(this.messages.opening(destination.name));
    this.clearMessages();
    try {
      await this.loadFolder(destination.id, false);
      const nextTrail = this.folderTrail.slice(0, index + 1);
      this.folderTrail = nextTrail;
      this.recordNavigation(nextTrail);
    } catch (error) {
      this.setError(this.resolveError(error, this.messages.openFailed(destination.name)));
    } finally {
      await this.finishLoading();
    }
  }

  async refresh(): Promise<void> {
    if (!this.currentFolder || this.loading) return;
    this.beginLoading(this.messages.refreshingFolder);
    this.clearMessages();
    try {
      await this.loadFolder(this.currentFolder.id, false);
      this.successMessage = this.messages.refreshed;
    } catch (error) {
      this.setError(this.resolveError(error, this.messages.refreshFailed));
    } finally {
      await this.finishLoading();
    }
  }

  async navigateUp(): Promise<void> {
    if (!this.canNavigateUp) return;
    await this.navigateToTrail(this.folderTrail.length - 2);
  }

  async navigateRoot(): Promise<void> {
    if (!this.connection || this.folderTrail.length < 2) return;
    await this.navigateToTrail(0);
  }

  async navigateBack(): Promise<void> {
    await this.navigateHistory(this.navigationIndex - 1);
  }

  async navigateForward(): Promise<void> {
    await this.navigateHistory(this.navigationIndex + 1);
  }

  async navigateToFolderId(folderId: string): Promise<void> {
    const index = this.folderTrail.findIndex((folder) => folder.id === folderId);
    if (index >= 0) await this.navigateToTrail(index);
  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  openCreateFolder(): void {
    this.clearMessages();
    this.newFolderName = '';
    this.createFolderOpen = true;
  }

  async createFolder(): Promise<void> {
    const name = this.newFolderName.trim();
    if (!name) {
      this.setError(this.messages.folderNameRequired);
      return;
    }
    if (!this.currentFolder) return;

    this.actionBusy = true;
    this.clearMessages();
    try {
      await firstValueFrom(this.api.createFolder(this.workspaceUrlOrId, this.currentFolder.id, name));
      this.createFolderOpen = false;
      await this.loadFolder(this.currentFolder.id, false);
      this.successMessage = this.messages.folderCreated(name);
    } catch (error) {
      this.setError(this.resolveWriteError(error, this.messages.folderCreateFailed));
    } finally {
      this.actionBusy = false;
    }
  }

  chooseUpload(): void {
    this.clearMessages();
    this.fileInput?.nativeElement.click();
  }

  async uploadSelected(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file || !this.currentFolder) return;

    this.actionBusy = true;
    this.clearMessages();
    try {
      await firstValueFrom(this.api.uploadFile(this.workspaceUrlOrId, this.currentFolder.id, file));
      await this.loadFolder(this.currentFolder.id, false);
      this.successMessage = this.messages.uploaded(file.name);
    } catch (error) {
      this.setError(this.resolveWriteError(error, this.messages.uploadFailed(file.name)));
    } finally {
      this.actionBusy = false;
      input.value = '';
    }
  }

  async openItem(item: GoogleDriveItem): Promise<void> {
    if (item.isFolder) {
      await this.openFolder(item);
      return;
    }
    await this.previewFile(item);
  }

  async previewFile(item: GoogleDriveItem): Promise<void> {
    if (item.isFolder || this.previewLoading) return;

    const generation = ++this.previewGeneration;
    this.previewService.teardown();
    this.revokePreviewUrl();
    this.clearPreviewHost();
    this.selectedItem = item;
    this.previewKind = this.detectPreviewKind(item);
    this.previewError = '';
    this.previewText = '';
    this.previewOpen = true;
    this.viewerOpenChange.emit(true);
    this.previewLoading = true;
    this.previewStartedAt = performance.now();
    this.cdr.detectChanges();

    if (this.previewKind === 'unsupported') {
      this.previewError = this.messages.unsupportedPreview;
      await this.finishPreviewLoading(generation);
      return;
    }

    try {
      const blob = await firstValueFrom(this.api.downloadFile(this.workspaceUrlOrId, item.id));
      if (generation !== this.previewGeneration) return;

      if (this.isOfficePreview) {
        await this.waitForPreviewHost();
        const host = this.previewHost?.nativeElement;
        if (!host) throw new Error(this.messages.previewStartFailed);
        await this.previewService.render(host, blob, this.previewKind as GoogleDriveOfficePreviewKind);
      } else if (this.previewKind === 'text') {
        this.previewText = await blob.text();
      } else {
        this.previewObjectUrl = URL.createObjectURL(blob);
        this.previewUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.previewObjectUrl);
      }
    } catch (error) {
      this.previewError = this.resolveError(error, this.messages.previewFailed(item.name));
    } finally {
      await this.finishPreviewLoading(generation);
    }
  }

  closePreview(): void {
    this.previewGeneration++;
    this.previewOpen = false;
    this.viewerOpenChange.emit(false);
    this.previewLoading = false;
    this.previewError = '';
    this.previewText = '';
    this.previewKind = 'unsupported';
    this.selectedItem = null;
    this.revokePreviewUrl();
    this.clearPreviewHost();
    this.previewService.teardown();
  }

  downloadSelected(): void {
    if (this.selectedItem) void this.download(this.selectedItem);
  }

  selectPreviewFile(): void {
    if (!this.filePickMode || !this.selectedItem || this.selectedItem.isFolder || this.pickFileBusy) return;
    this.pickFile.emit(this.selectedItem);
  }

  onPreviewMediaError(): void {
    this.previewLoading = false;
    this.previewError = this.messages.mediaPreviewFailed;
  }

  previewTypeLabel(): string {
    switch (this.previewKind) {
      case 'excel': return this.messages.previewType.excel;
      case 'csv': return this.messages.previewType.csv;
      case 'docx': return this.messages.previewType.docx;
      case 'pptx': return this.messages.previewType.pptx;
      case 'pdf': return this.messages.previewType.pdf;
      case 'image': return this.messages.previewType.image;
      case 'video': return this.messages.previewType.video;
      case 'audio': return this.messages.previewType.audio;
      case 'text': return this.messages.previewType.text;
      default: return this.messages.previewType.file;
    }
  }

  async download(item: GoogleDriveItem): Promise<void> {
    if (item.isFolder || this.actionBusy) return;
    this.actionBusy = true;
    this.clearMessages();
    try {
      const blob = await firstValueFrom(this.api.downloadFile(this.workspaceUrlOrId, item.id));
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = googleDriveEffectiveFileName(item);
      anchor.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      this.successMessage = this.messages.downloaded(item.name);
    } catch (error) {
      this.setError(this.resolveError(error, this.messages.downloadFailed(item.name)));
    } finally {
      this.actionBusy = false;
    }
  }

  openMove(item: GoogleDriveItem): void {
    this.clearMessages();
    this.moveTarget = item;
    this.moveDestinationId = this.connection?.folderId ?? '';
  }

  async moveItem(): Promise<void> {
    const destinationId = this.moveDestinationId.trim();
    if (!this.moveTarget || !destinationId) {
      this.setError(this.messages.destinationRequired);
      return;
    }

    this.actionBusy = true;
    this.clearMessages();
    const itemName = this.moveTarget.name;
    try {
      await firstValueFrom(this.api.moveFile(this.workspaceUrlOrId, this.moveTarget.id, destinationId));
      this.moveTarget = null;
      if (this.currentFolder) await this.loadFolder(this.currentFolder.id, false);
      this.successMessage = this.messages.moved(itemName);
    } catch (error) {
      this.setError(this.resolveWriteError(error, this.messages.moveFailed(itemName)));
    } finally {
      this.actionBusy = false;
    }
  }

  requestDelete(item: GoogleDriveItem): void {
    this.clearMessages();
    this.deleteTarget = item;
  }

  async deleteItem(): Promise<void> {
    if (!this.deleteTarget) return;
    this.actionBusy = true;
    this.clearMessages();
    const itemName = this.deleteTarget.name;
    try {
      await firstValueFrom(this.api.deleteItem(this.workspaceUrlOrId, this.deleteTarget.id));
      this.deleteTarget = null;
      if (this.currentFolder) await this.loadFolder(this.currentFolder.id, false);
      this.successMessage = this.messages.movedToTrash(itemName);
    } catch (error) {
      this.setError(this.resolveWriteError(error, this.messages.deleteFailed(itemName)));
    } finally {
      this.actionBusy = false;
    }
  }

  openInDrive(item?: GoogleDriveItem): void {
    const url = item?.webViewLink || this.connection?.webViewLink;
    if (url) window.open(url, '_blank', 'noopener,noreferrer');
  }

  disconnect(): void {
    this.connection = null;
    this.workspaceUrlOrId = '';
    this.items = [];
    this.folderTrail = [];
    this.navigationHistory = [];
    this.navigationIndex = -1;
    this.searchTerm = '';
    this.clearMessages();
  }

  itemIcon(item: GoogleDriveItem): string {
    if (item.isFolder) return 'folder';
    const mime = item.mimeType.toLocaleLowerCase();
    const name = googleDriveEffectiveFileName(item);
    if (mime.includes('spreadsheet') || mime.includes('excel') || /\.(xlsx?|csv)$/i.test(name)) return 'table_view';
    if (mime.includes('presentation') || /\.(pptx?)$/i.test(name)) return 'slideshow';
    if (mime.includes('pdf')) return 'picture_as_pdf';
    if (mime.includes('image')) return 'image';
    if (mime.includes('video')) return 'movie';
    if (mime.includes('audio')) return 'audio_file';
    if (mime.includes('document') || mime.includes('word') || /\.(docx?|txt)$/i.test(name)) return 'description';
    if (mime.includes('zip') || mime.includes('compressed')) return 'folder_zip';
    return 'draft';
  }

  itemTypeLabel(item: GoogleDriveItem): string {
    if (item.isFolder) return 'Folder';
    const parts = googleDriveEffectiveFileName(item).split('.');
    return parts.length > 1 ? `${parts.pop()?.toLocaleUpperCase()} file` : 'File';
  }

  formatSize(size?: number | null): string {
    if (size == null) return '—';
    if (size === 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    const index = Math.min(Math.floor(Math.log(size) / Math.log(1024)), units.length - 1);
    return `${(size / 1024 ** index).toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
  }

  formatDate(value?: string | null): string {
    if (!value) return this.messages.notAvailable;
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return this.messages.notAvailable;
    return new Intl.DateTimeFormat(undefined, {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(parsed);
  }

  dismissMessage(): void {
    this.clearMessages();
  }

  private async loadFolder(folderId: string, manageLoading: boolean): Promise<void> {
    if (manageLoading) this.loading = true;
    try {
      this.items = await firstValueFrom(this.api.browseFolder(this.workspaceUrlOrId, folderId));
      this.searchTerm = '';
    } finally {
      if (manageLoading) this.loading = false;
    }
  }

  private resetNavigationHistory(trail: GoogleDriveFolderTrailItem[]): void {
    this.navigationHistory = [{ folderId: trail[trail.length - 1].id, trail: this.cloneTrail(trail) }];
    this.navigationIndex = 0;
  }

  private recordNavigation(trail: GoogleDriveFolderTrailItem[]): void {
    const folderId = trail[trail.length - 1].id;
    const currentEntry = this.navigationHistory[this.navigationIndex];
    if (currentEntry?.folderId === folderId) return;

    this.navigationHistory = [
      ...this.navigationHistory.slice(0, this.navigationIndex + 1),
      { folderId, trail: this.cloneTrail(trail) },
    ];
    this.navigationIndex = this.navigationHistory.length - 1;
  }

  private async navigateHistory(index: number): Promise<void> {
    const destination = this.navigationHistory[index];
    if (!destination || index === this.navigationIndex || this.loading) return;

    this.beginLoading(this.messages.opening(destination.trail[destination.trail.length - 1].name));
    this.clearMessages();
    try {
      await this.loadFolder(destination.folderId, false);
      this.folderTrail = this.cloneTrail(destination.trail);
      this.navigationIndex = index;
    } catch (error) {
      this.setError(this.resolveError(error, this.messages.requestedFolderOpenFailed));
    } finally {
      await this.finishLoading();
    }
  }

  private beginLoading(label: string): void {
    this.loadingLabel = label;
    this.loadingStartedAt = performance.now();
    this.loading = true;
  }

  private async finishLoading(): Promise<void> {
    const remaining = Math.max(0, 520 - (performance.now() - this.loadingStartedAt));
    if (remaining) await new Promise<void>((resolve) => window.setTimeout(resolve, remaining));
    this.loading = false;
  }

  private async finishPreviewLoading(generation: number): Promise<void> {
    const remaining = Math.max(0, 600 - (performance.now() - this.previewStartedAt));
    if (remaining) await new Promise<void>((resolve) => window.setTimeout(resolve, remaining));
    if (generation !== this.previewGeneration) return;
    this.previewLoading = false;
    this.cdr.detectChanges();
  }

  private detectPreviewKind(item: GoogleDriveItem): GoogleDrivePreviewKind {
    const mime = (item.mimeType || '').toLocaleLowerCase();
    const name = googleDriveEffectiveFileName(item).toLocaleLowerCase();
    if (mime.includes('pdf') || name.endsWith('.pdf')) return 'pdf';
    if (name.endsWith('.csv') || mime.includes('csv')) return 'csv';
    if (/\.(xlsx?|xlsm)$/i.test(name) || mime.includes('spreadsheet') || mime.includes('excel')) return 'excel';
    if (name.endsWith('.docx') || mime.includes('wordprocessingml')) return 'docx';
    if (name.endsWith('.pptx') || mime.includes('presentationml')) return 'pptx';
    if (mime.startsWith('image/') || /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(name)) return 'image';
    if (mime.startsWith('video/') || /\.(mp4|webm|mov|m4v)$/i.test(name)) return 'video';
    if (mime.startsWith('audio/') || /\.(mp3|wav|ogg|m4a|aac)$/i.test(name)) return 'audio';
    if (mime.startsWith('text/') || /\.(txt|md|json|xml|log|yaml|yml)$/i.test(name)) return 'text';
    return 'unsupported';
  }

  private async waitForPreviewHost(): Promise<void> {
    for (let attempt = 0; attempt < 4 && !this.previewHost?.nativeElement; attempt++) {
      this.cdr.detectChanges();
      await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
    }
  }

  private revokePreviewUrl(): void {
    if (this.previewObjectUrl) URL.revokeObjectURL(this.previewObjectUrl);
    this.previewObjectUrl = '';
    this.previewUrl = null;
  }

  private clearPreviewHost(): void {
    const host = this.previewHost?.nativeElement;
    if (host) host.innerHTML = '';
  }

  private cloneTrail(trail: GoogleDriveFolderTrailItem[]): GoogleDriveFolderTrailItem[] {
    return trail.map((folder) => ({ ...folder }));
  }

  private setError(message: string): void {
    this.successMessage = '';
    this.errorMessage = message;
  }

  private clearMessages(): void {
    this.errorMessage = '';
    this.successMessage = '';
  }

  private resolveWriteError(error: unknown, fallback: string): string {
    const resolved = this.resolveError(error, fallback);
    if (/storage quota|service account.*quota|storage limit/i.test(resolved)) {
      return `${resolved} Use a Shared Drive for service-account writes, or configure delegated user OAuth for My Drive.`;
    }
    return resolved;
  }

  private resolveError(error: unknown, fallback: string): string {
    if (error instanceof HttpErrorResponse) {
      const body = error.error;
      if (body instanceof Blob) return fallback;
      if (typeof body === 'string' && body.trim()) return body;
      if (body && typeof body.message === 'string' && body.message.trim()) return body.message;
      if (error.status === 0) return this.messages.apiUnavailable;
      if (error.status === 401) return this.messages.loginRequired;
      if (error.status === 403) return this.messages.folderPermissionDenied;
      return error.message || fallback;
    }
    if (error instanceof Error && error.message.trim()) return error.message;
    return fallback;
  }

  private toTimestamp(value?: string | null): number {
    if (!value) return 0;
    const timestamp = new Date(value).getTime();
    return Number.isNaN(timestamp) ? 0 : timestamp;
  }
}
