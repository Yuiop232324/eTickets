import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { NgApexchartsModule } from 'ng-apexcharts';
import { firstValueFrom } from 'rxjs';
import { BusyService } from '../../core/services/busy.service';
import { GoogleDriveTenant, GoogleDriveTenantFolder } from '../core/google-drive-workspace.types';
import { ConnectorListFilter, ConnectorListProfile, ConnectorListStatus } from '../core/workspace-connect-list.types';
import { WorkspaceConnectTenantHierarchyComponent } from '../core/workspace-connect-tenant-hierarchy.component';
import { WORKSPACE_CONNECT_LIST_MESSAGES } from '../core/workspace-connect.messages';
import {
  SharePointTenantHierarchySelection,
  emptyTenantHierarchySelection,
} from '../core/workspace-connect.tenant';
import { ApplicationDto } from '../core/workspace-connect.types';
import {
  GoogleDriveLogoComponent,
  SharepointLogoComponent,
  WorkspaceConnectIconComponent,
  WorkspaceConnectStatusAlertsComponent,
} from '../core/workspace-connect.ui';
import { GoogleDriveApiService } from '../services/google-drive-api.service';
import { SharePointApiService } from '../services/sharepoint-api.service';
import { WorkspaceConnectListApiService } from '../services/workspace-connect-list-api.service';

@Component({
  selector: 'app-workspace-connect-unified-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    NgbTooltipModule,
    NgApexchartsModule,
    WorkspaceConnectIconComponent,
    SharepointLogoComponent,
    GoogleDriveLogoComponent,
    WorkspaceConnectTenantHierarchyComponent,
    WorkspaceConnectStatusAlertsComponent,
  ],
  templateUrl: './workspace-connect-unified-list.component.html',
  styleUrls: ['./workspace-connect-unified-list.component.css', '../workspace-connect.styles.css'],
})
export class WorkspaceConnectUnifiedListComponent implements OnInit {
  private readonly sharePointApi = inject(SharePointApiService);
  private readonly googleDriveApi = inject(GoogleDriveApiService);
  private readonly listApi = inject(WorkspaceConnectListApiService);
  private readonly busyService = inject(BusyService);
  private readonly messages = WORKSPACE_CONNECT_LIST_MESSAGES;

  @Input() connectorFilter: ConnectorListFilter = 'all';
  @Input() set successMessage(value: string) {
    const nextMessage = (value ?? '').trim();
    if (!nextMessage || nextMessage === this.successToastMessage) return;
    this.successToastMessage = nextMessage;
  }
  @Output() connectorFilterChange = new EventEmitter<ConnectorListFilter>();
  @Output() registerSharePoint = new EventEmitter<void>();
  @Output() registerGoogleDrive = new EventEmitter<void>();
  @Output() editSharePoint = new EventEmitter<ApplicationDto>();
  @Output() editGoogleDrive = new EventEmitter<GoogleDriveTenant>();
  @Output() browseGoogleDrive = new EventEmitter<GoogleDriveTenantFolder>();
  @Output() navigateHome = new EventEmitter<void>();

  applications: ApplicationDto[] = [];
  tenants: GoogleDriveTenant[] = [];
  loading = true;
  errorMessage = '';
  successToastMessage = '';
  searchTerm = '';
  statusFilter: ConnectorListStatus = 'all';
  profileFilter: ConnectorListProfile = 'all';
  displayMode: 'cards' | 'table' = 'cards';
  readonly pageSizeOptions = [8, 16, 24];
  pageSize = this.pageSizeOptions[0];
  currentPage = 1;
  catalogTotalCount = 0;
  sharePointCount = 0;
  googleDriveCount = 0;
  filteredCount = 0;
  catalogActiveCount = 0;
  catalogDraftCount = 0;
  catalogInactiveCount = 0;
  listHierarchySelection: SharePointTenantHierarchySelection = emptyTenantHierarchySelection();
  listHierarchyFilterOpen = false;
  private searchReloadTimer?: ReturnType<typeof setTimeout>;
  private loadSequence = 0;

  async ngOnInit(): Promise<void> {
    await this.reload();
    this.resetPageScroll();
  }

  dismissSuccessMessage(): void {
    this.successToastMessage = '';
  }

  get listHierarchyConfigured(): boolean {
    return !!this.listHierarchySelection.regionIdent;
  }

  get listHierarchySummary(): string {
    if (!this.listHierarchyConfigured) return '';
    const parts = [this.listHierarchySelection.regionName];
    if (this.listHierarchySelection.subRegionCode && this.listHierarchySelection.subRegionCode !== 'ALL') parts.push(this.listHierarchySelection.subRegionName);
    if (this.listHierarchySelection.clientIdent && this.listHierarchySelection.clientIdent > 0) parts.push(this.listHierarchySelection.clientName);
    return parts.filter(Boolean).join(' / ');
  }

  get visibleCount(): number {
    return this.filteredCount;
  }

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.visibleCount / this.pageSize));
  }

  get activePage(): number {
    return Math.min(Math.max(1, this.currentPage), this.totalPages);
  }

  get pageNumbers(): number[] {
    const windowSize = Math.min(5, this.totalPages);
    const firstPage = Math.min(
      Math.max(1, this.activePage - Math.floor(windowSize / 2)),
      this.totalPages - windowSize + 1,
    );
    return Array.from({ length: windowSize }, (_, index) => firstPage + index);
  }

  get firstVisibleItem(): number {
    return this.visibleCount ? ((this.activePage - 1) * this.pageSize) + 1 : 0;
  }

  get lastVisibleItem(): number {
    return Math.min(this.activePage * this.pageSize, this.visibleCount);
  }

  get pagedItems(): Array<{ pageOrdinal: number; application?: ApplicationDto; tenant?: GoogleDriveTenant }> {
    return [
      ...this.applications.map(application => ({ pageOrdinal: application.pageOrdinal ?? 0, application })),
      ...this.tenants.map(tenant => ({ pageOrdinal: tenant.pageOrdinal ?? 0, tenant })),
    ].sort((left, right) => left.pageOrdinal - right.pageOrdinal);
  }

  get totalCount(): number {
    return this.catalogTotalCount;
  }

  get activeCount(): number {
    return this.catalogActiveCount;
  }

  get draftCount(): number {
    return this.catalogDraftCount;
  }

  get inactiveCount(): number {
    return this.catalogInactiveCount;
  }

  tenantSiteNames(app: ApplicationDto): string[] {
    const names = (app.sites ?? []).map(site => site.siteName.trim()).filter(Boolean);
    return names.length ? names : (app.siteName?.trim() ? [app.siteName.trim()] : []);
  }

  tenantSiteSummary(app: ApplicationDto): string {
    const names = this.tenantSiteNames(app);
    if (!names.length) return '—';
    if (names.length === 1) return names[0];
    const first = names[0].length > 32 ? `${names[0].slice(0, 32)}…` : names[0];
    return `${first} (+${names.length - 1} more)`;
  }

  connectorChartSeries: Array<{ name: string; data: number[] }> = [
    { name: WORKSPACE_CONNECT_LIST_MESSAGES.sharePointConnectorName, data: [0, 0, 0, 0, 0, 0] },
    { name: WORKSPACE_CONNECT_LIST_MESSAGES.googleDriveConnectorName, data: [0, 0, 0, 0, 0, 0] },
  ];

  readonly connectorChartOptions: Record<string, unknown> = {
    chart: { type: 'bar', height: 166, toolbar: { show: false }, animations: { enabled: true, easing: 'easeinout', speed: 500 }, parentHeightOffset: 0 },
    plotOptions: { bar: { borderRadius: 5, columnWidth: '64%', dataLabels: { position: 'top' } } },
    xaxis: {
      categories: this.recentMonthLabels(),
      labels: { style: { colors: '#64748b', fontSize: '11px', fontWeight: 600 } },
      axisBorder: { show: false },
      axisTicks: { show: false },
    },
    yaxis: { min: 0, forceNiceScale: true, tickAmount: 4, decimalsInFloat: 0, labels: { formatter: (value: number) => String(Math.round(value)), style: { colors: '#64748b', fontSize: '11px' } } },
    colors: ['#315bd6', '#07969a'],
    grid: { borderColor: 'rgba(226, 232, 240, 0.8)', strokeDashArray: 4, padding: { top: 12, left: 4, right: 6, bottom: -7 } },
    legend: { show: false },
    dataLabels: { enabled: true, formatter: (value: number) => value > 0 ? String(value) : '', offsetY: -18, style: { colors: ['#43516a'], fontSize: '10px', fontWeight: 700 }, background: { enabled: false } },
    tooltip: { theme: 'light', shared: true, intersect: false, y: { formatter: (value: number) => `${value} profile${value === 1 ? '' : 's'}` } },
  };

  setConnectorFilter(filter: ConnectorListFilter): void {
    this.cancelSearchReload();
    this.connectorFilter = filter;
    if (filter === 'google-drive') this.profileFilter = 'all';
    this.connectorFilterChange.emit(filter);
    this.currentPage = 1;
    void this.reload();
  }

  setSearchTerm(value: string): void {
    this.searchTerm = value;
    this.currentPage = 1;
    this.cancelSearchReload();
    this.searchReloadTimer = setTimeout(() => {
      this.searchReloadTimer = undefined;
      void this.reload();
    }, 250);
  }

  setStatusFilter(filter: ConnectorListStatus): void {
    this.cancelSearchReload();
    this.statusFilter = filter;
    this.currentPage = 1;
    void this.reload();
  }

  setProfileFilter(filter: ConnectorListProfile): void {
    this.cancelSearchReload();
    this.profileFilter = filter;
    this.currentPage = 1;
    void this.reload();
  }

  setPageSize(value: number | string): void {
    this.cancelSearchReload();
    this.pageSize = Number(value) || this.pageSizeOptions[0];
    this.currentPage = 1;
    void this.reload();
  }

  goToPage(page: number): void {
    this.cancelSearchReload();
    const nextPage = Math.min(Math.max(1, page), this.totalPages);
    if (nextPage === this.activePage) return;
    this.currentPage = nextPage;
    void this.reload();
  }

  clearFilters(): void {
    this.cancelSearchReload();
    this.searchTerm = '';
    this.statusFilter = 'all';
    this.profileFilter = 'all';
    this.currentPage = 1;
    this.listHierarchySelection = emptyTenantHierarchySelection();
    this.listHierarchyFilterOpen = false;
    void this.reload();
  }

  toggleScope(): void {
    this.listHierarchyFilterOpen = !this.listHierarchyFilterOpen;
  }

  onScopeChange(selection: SharePointTenantHierarchySelection): void {
    this.cancelSearchReload();
    this.listHierarchySelection = selection;
    this.currentPage = 1;
    void this.reload();
  }

  clearScope(): void {
    this.cancelSearchReload();
    this.listHierarchySelection = emptyTenantHierarchySelection();
    this.listHierarchyFilterOpen = false;
    this.currentPage = 1;
    void this.reload();
  }

  private cancelSearchReload(): void {
    if (!this.searchReloadTimer) return;
    clearTimeout(this.searchReloadTimer);
    this.searchReloadTimer = undefined;
  }

  private resetPageScroll(): void {
    requestAnimationFrame(() => requestAnimationFrame(() => {
      const page = document.getElementById('pageContent');
      page ? page.scrollTo({ top: 0, left: 0, behavior: 'auto' }) : window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
    }));
  }

  async editSharePointConnector(application: ApplicationDto): Promise<void> {
    try {
      this.editSharePoint.emit(await firstValueFrom(this.sharePointApi.getApplication(application.applicationId)));
    } catch (error) {
      this.errorMessage = this.errorText(error, this.messages.sharePointLoadFailed);
    }
  }

  async editGoogleDriveConnector(tenant: GoogleDriveTenant): Promise<void> {
    try {
      this.editGoogleDrive.emit(await firstValueFrom(this.googleDriveApi.getTenant(tenant.tenantId)));
    } catch (error) {
      this.errorMessage = this.errorText(error, this.messages.googleDriveLoadFailed);
    }
  }

  async deactivateGoogleDrive(tenant: GoogleDriveTenant): Promise<void> {
    if (!window.confirm(this.messages.googleDriveDeactivateConfirm(tenant.displayName))) return;
    try {
      await firstValueFrom(this.googleDriveApi.deactivateTenant(tenant.tenantId));
      await this.reload();
    } catch (error) {
      this.errorMessage = this.errorText(error, this.messages.googleDriveDeactivateFailed);
    }
  }

  async deleteSharePoint(application: ApplicationDto): Promise<void> {
    if (!window.confirm(this.messages.sharePointDeleteConfirm(application.displayName))) return;
    try {
      await firstValueFrom(this.sharePointApi.deleteApplication(application.applicationId));
      await this.reload();
    } catch (error) {
      this.errorMessage = this.errorText(error, this.messages.sharePointDeleteFailed);
    }
  }

  async reload(): Promise<void> {
    const sequence = ++this.loadSequence;
    this.loading = true;
    this.errorMessage = '';
    this.busyService.busy();
    try {
      const page = await firstValueFrom(this.listApi.getPage({
        pageNumber: this.currentPage,
        pageSize: this.pageSize,
        connector: this.connectorFilter,
        status: this.statusFilter,
        profile: this.profileFilter,
        searchTerm: this.searchTerm,
        hierarchy: this.listHierarchySelection,
      }));
      if (sequence !== this.loadSequence) return;
      this.applications = page.applications ?? [];
      this.tenants = page.tenants ?? [];
      this.currentPage = page.pageNumber;
      this.filteredCount = page.filteredCount;
      this.catalogTotalCount = page.totalCount;
      this.sharePointCount = page.sharePointCount;
      this.googleDriveCount = page.googleDriveCount;
      this.catalogActiveCount = page.activeCount;
      this.catalogDraftCount = page.draftCount;
      this.catalogInactiveCount = page.inactiveCount;
      this.connectorChartSeries = [
        { name: this.messages.sharePointConnectorName, data: page.monthlyCounts.map(bucket => bucket.sharePoint) },
        { name: this.messages.googleDriveConnectorName, data: page.monthlyCounts.map(bucket => bucket.googleDrive) },
      ];
    } catch (error) {
      if (sequence !== this.loadSequence) return;
      this.applications = [];
      this.tenants = [];
      this.filteredCount = 0;
      this.errorMessage = this.errorText(error, this.messages.tenantLoadFailed);
    } finally {
      if (sequence === this.loadSequence) this.loading = false;
      this.busyService.idle();
    }
  }

  trackPagedItem(_index: number, item: { application?: ApplicationDto; tenant?: GoogleDriveTenant }): string {
    return item.application ? `sharepoint-${item.application.applicationId}` : `google-drive-${item.tenant!.tenantId}`;
  }

  private errorText(error: unknown, fallback: string): string {
    const message = error instanceof Error ? error.message : '';
    return message || fallback;
  }

  private recentMonthLabels(): string[] {
    const now = new Date();
    return Array.from({ length: 6 }, (_, offset) => {
      const month = new Date(now.getFullYear(), now.getMonth() - (5 - offset), 1);
      return month.toLocaleDateString(undefined, { month: 'short', year: '2-digit' });
    });
  }
}
